import plotly.graph_objects as go
import plotly.io as pio

# Data for the flowchart
steps_data = {
    "steps": [
        {"id": 1, "text": "Submit APK", "type": "input", "shape": "rect"},
        {"id": 2, "text": "Validate APK", "type": "process", "shape": "diamond"},
        {"id": 3, "text": "Generate job ID", "type": "process", "shape": "rect"},
        {"id": 4, "text": "Add to queue", "type": "process", "shape": "rect"},
        {"id": 5, "text": "Worker avail?", "type": "decision", "shape": "diamond"},
        {"id": 6, "text": "Start patching", "type": "processing", "shape": "rect"},
        {"id": 7, "text": "Patch APK/AAB", "type": "processing", "shape": "rect"},
        {"id": 8, "text": "Update metrics", "type": "output", "shape": "rect"},
        {"id": 9, "text": "Job completed", "type": "output", "shape": "rect"}
    ]
}

# Define colors for different stages
colors = {
    "input": "#1FB8CD",      # Strong cyan
    "process": "#FFC185",    # Light orange
    "decision": "#ECEBD5",   # Light green
    "processing": "#5D878F", # Cyan
    "output": "#D2BA4C"      # Moderate yellow
}

# Define evenly spaced positions for each step
positions = {
    1: (0, 8),    # Start at top
    2: (0, 7),    # Validation diamond
    3: (0, 6),    # Generate ID
    4: (0, 5),    # Add to queue
    5: (0, 4),    # Worker available decision
    6: (0, 3),    # Start patching
    7: (0, 2),    # Patch APK/AAB
    8: (0, 1),    # Update metrics
    9: (0, 0),    # Job completed
    "Error": (2.5, 7)  # Error branch
}

# Create figure
fig = go.Figure()

# Add shapes and text for each step
for step in steps_data["steps"]:
    step_id = step["id"]
    x, y = positions[step_id]
    color = colors[step["type"]]
    
    if step["shape"] == "rect":
        # Add rectangle
        fig.add_shape(
            type="rect",
            x0=x-0.9, y0=y-0.35, x1=x+0.9, y1=y+0.35,
            fillcolor=color,
            line=dict(color="black", width=2)
        )
    else:  # diamond
        # Add diamond using path
        fig.add_shape(
            type="path",
            path=f"M {x} {y+0.45} L {x+0.9} {y} L {x} {y-0.45} L {x-0.9} {y} Z",
            fillcolor=color,
            line=dict(color="black", width=2)
        )
    
    # Add text
    fig.add_annotation(
        x=x, y=y,
        text=step["text"],
        showarrow=False,
        font=dict(size=12, color="black"),
        align="center"
    )

# Add Error terminal box
fig.add_shape(
    type="rect",
    x0=1.6, y0=6.65, x1=3.4, y1=7.35,
    fillcolor="#B4413C",  # Moderate red for error
    line=dict(color="black", width=2)
)
fig.add_annotation(
    x=2.5, y=7,
    text="Return Error",
    showarrow=False,
    font=dict(size=12, color="white"),
    align="center"
)

# Add main flow arrows
main_flow = [
    (1, 2), (2, 3), (3, 4), (4, 5), (5, 6), (6, 7), (7, 8), (8, 9)
]

for from_id, to_id in main_flow:
    from_pos = positions[from_id]
    to_pos = positions[to_id]
    
    # Regular downward arrow
    fig.add_annotation(
        x=to_pos[0], y=to_pos[1]+0.45,
        ax=from_pos[0], ay=from_pos[1]-0.45,
        arrowhead=2, arrowsize=1.5, arrowwidth=3, arrowcolor="black"
    )

# Add "Valid" label for validation to job creation
fig.add_annotation(
    x=0.6, y=6.5,
    text="Valid",
    showarrow=False,
    font=dict(size=12, color="black", family="Arial Black")
)

# Add "Yes" label for worker available to start patching
fig.add_annotation(
    x=0.6, y=3.5,
    text="Yes",
    showarrow=False,
    font=dict(size=12, color="black", family="Arial Black")
)

# Add validation error arrow
fig.add_annotation(
    x=1.6, y=7,
    ax=0.9, ay=7,
    arrowhead=2, arrowsize=1.5, arrowwidth=3, arrowcolor="black"
)

# Add "Invalid" label
fig.add_annotation(
    x=1.25, y=7.2,
    text="Invalid",
    showarrow=False,
    font=dict(size=12, color="black", family="Arial Black")
)

# Add wait loop arrow (worker not available)
# Create a curved path for the loop
fig.add_shape(
    type="path",
    path="M -0.9 4 Q -1.8 4.5 -1.8 5 Q -1.8 5.5 -0.9 5",
    line=dict(color="black", width=3)
)

# Add arrowhead for the loop
fig.add_annotation(
    x=-0.9, y=5,
    ax=-1.1, ay=5.1,
    arrowhead=2, arrowsize=1.5, arrowwidth=3, arrowcolor="black"
)

# Add "No (wait)" label for the loop
fig.add_annotation(
    x=-1.8, y=4.5,
    text="No<br>(wait)",
    showarrow=False,
    font=dict(size=12, color="black", family="Arial Black"),
    align="center"
)

# Update layout with better title
fig.update_layout(
    title=dict(
        text="TUI-Patcher Job Processing Flow",
        font=dict(size=18, family="Arial Black"),
        x=0.5,
        xanchor="center"
    ),
    showlegend=False,
    xaxis=dict(range=[-2.5, 4], visible=False),
    yaxis=dict(range=[-0.7, 8.7], visible=False),
    plot_bgcolor="white",
    paper_bgcolor="white"
)

# Save the chart
fig.write_image("tui_patcher_flowchart.png")
fig.show()