import plotly.graph_objects as go
import json

# Parse the data
data = {
    "components": [
        {"name": "Client/CLI", "type": "external"}, 
        {"name": "API Gateway", "type": "entry"}, 
        {"name": "Queue Manager", "type": "core"}, 
        {"name": "Rust API Core", "type": "core"}, 
        {"name": "Patching Engine", "type": "worker"}, 
        {"name": "Metrics Collector", "type": "monitoring"}, 
        {"name": "File Storage", "type": "storage"}
    ], 
    "connections": [
        {"from": "Client/CLI", "to": "API Gateway", "label": "HTTP Requests"}, 
        {"from": "API Gateway", "to": "Rust API Core", "label": "Route Commands"}, 
        {"from": "Rust API Core", "to": "Queue Manager", "label": "Job Management"}, 
        {"from": "Queue Manager", "to": "Patching Engine", "label": "Process Jobs"}, 
        {"from": "Patching Engine", "to": "File Storage", "label": "Read/Write APKs"}, 
        {"from": "Rust API Core", "to": "Metrics Collector", "label": "Performance Data"}, 
        {"from": "Metrics Collector", "to": "Prometheus", "label": "Export Metrics"}
    ]
}

# Add Prometheus to components since it's referenced in connections
data["components"].append({"name": "Prometheus", "type": "external"})

# Define positions for components in a logical flow layout
positions = {
    "Client/CLI": (0, 3),
    "API Gateway": (2, 3),
    "Rust API Core": (4, 3),
    "Queue Manager": (4, 1),
    "Patching Engine": (6, 1),
    "File Storage": (8, 1),
    "Metrics Collector": (6, 3),
    "Prometheus": (8, 3)
}

# Define colors for each component type
type_colors = {
    "external": "#1FB8CD",
    "entry": "#FFC185", 
    "core": "#ECEBD5",
    "worker": "#5D878F",
    "monitoring": "#D2BA4C",
    "storage": "#B4413C"
}

# Create the figure
fig = go.Figure()

# Add connection lines first (so they appear behind nodes)
for conn in data["connections"]:
    from_pos = positions[conn["from"]]
    to_pos = positions[conn["to"]]
    
    fig.add_trace(go.Scatter(
        x=[from_pos[0], to_pos[0]],
        y=[from_pos[1], to_pos[1]],
        mode='lines',
        line=dict(color='rgba(100,100,100,0.5)', width=2),
        showlegend=False,
        hoverinfo='skip'
    ))

# Add arrow markers at the end of each line
for conn in data["connections"]:
    from_pos = positions[conn["from"]]
    to_pos = positions[conn["to"]]
    
    # Calculate arrow position (80% along the line)
    arrow_x = from_pos[0] + 0.8 * (to_pos[0] - from_pos[0])
    arrow_y = from_pos[1] + 0.8 * (to_pos[1] - from_pos[1])
    
    fig.add_trace(go.Scatter(
        x=[arrow_x],
        y=[arrow_y],
        mode='markers',
        marker=dict(
            symbol='triangle-right',
            size=10,
            color='rgba(100,100,100,0.7)'
        ),
        showlegend=False,
        hoverinfo='skip'
    ))

# Group components by type for legend
component_types = {}
for comp in data["components"]:
    comp_type = comp["type"]
    if comp_type not in component_types:
        component_types[comp_type] = []
    component_types[comp_type].append(comp)

# Add component nodes grouped by type
for comp_type, components in component_types.items():
    x_coords = []
    y_coords = []
    hover_text = []
    
    for comp in components:
        pos = positions[comp["name"]]
        x_coords.append(pos[0])
        y_coords.append(pos[1])
        hover_text.append(comp["name"])
    
    fig.add_trace(go.Scatter(
        x=x_coords,
        y=y_coords,
        mode='markers',
        marker=dict(
            size=30,
            color=type_colors[comp_type],
            symbol='square',
            line=dict(width=2, color='white')
        ),
        name=comp_type.title(),
        hovertext=hover_text,
        hovertemplate='%{hovertext}<extra></extra>',
        cliponaxis=False
    ))

# Add component labels
for comp in data["components"]:
    pos = positions[comp["name"]]
    # Abbreviate long names to fit 15 char limit
    label = comp["name"]
    if len(label) > 15:
        if label == "Metrics Collector":
            label = "Metrics Coll."
        elif label == "Patching Engine":
            label = "Patch Engine"
        elif label == "File Storage":
            label = "File Store"
    
    fig.add_trace(go.Scatter(
        x=[pos[0]],
        y=[pos[1]],
        mode='text',
        text=[label],
        textposition='middle center',
        textfont=dict(size=10, color='black'),
        showlegend=False,
        hoverinfo='skip'
    ))

# Add connection labels
for conn in data["connections"]:
    from_pos = positions[conn["from"]]
    to_pos = positions[conn["to"]]
    
    # Calculate middle position for label
    mid_x = (from_pos[0] + to_pos[0]) / 2
    mid_y = (from_pos[1] + to_pos[1]) / 2
    
    # Abbreviate labels to fit 15 char limit
    label = conn["label"]
    if len(label) > 15:
        if label == "HTTP Requests":
            label = "HTTP Req"
        elif label == "Route Commands":
            label = "Route Cmd"
        elif label == "Job Management":
            label = "Job Mgmt"
        elif label == "Process Jobs":
            label = "Process Jobs"
        elif label == "Read/Write APKs":
            label = "R/W APKs"
        elif label == "Performance Data":
            label = "Perf Data"
        elif label == "Export Metrics":
            label = "Export Metrics"
    
    fig.add_trace(go.Scatter(
        x=[mid_x],
        y=[mid_y + 0.1],  # Slightly offset above the line
        mode='text',
        text=[label],
        textposition='middle center',
        textfont=dict(size=8, color='gray'),
        showlegend=False,
        hoverinfo='skip'
    ))

# Update layout
fig.update_layout(
    title="TUI-Patcher-Agent Architecture",
    showlegend=True,
    legend=dict(
        orientation='h', 
        yanchor='bottom', 
        y=1.05, 
        xanchor='center', 
        x=0.5
    ),
    xaxis=dict(range=[-0.5, 8.5]),
    yaxis=dict(range=[0.5, 3.5])
)

# Hide axes and grid
fig.update_xaxes(showgrid=False, showticklabels=False, zeroline=False)
fig.update_yaxes(showgrid=False, showticklabels=False, zeroline=False)

# Save the chart
fig.write_image("tui_patcher_architecture.png")