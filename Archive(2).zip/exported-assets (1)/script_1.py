# Create example Prometheus metrics configuration and sample data
prometheus_config = '''
# Prometheus configuration for TUI-Patcher-Agent monitoring
# File: prometheus.yml

global:
  scrape_interval: 15s
  evaluation_interval: 15s

scrape_configs:
  - job_name: 'tui-patcher-agent'
    static_configs:
      - targets: ['localhost:8080']
    metrics_path: '/metrics'
    scrape_interval: 10s
    scrape_timeout: 5s

# Example metrics exposed by TUI-Patcher-Agent:
# tui_patcher_jobs_total - Total number of patch jobs processed
# tui_patcher_jobs_completed - Number of successfully completed jobs  
# tui_patcher_jobs_failed - Number of failed jobs
# tui_patcher_jobs_processing - Number of jobs currently being processed
# tui_patcher_queue_size - Current number of jobs in queue
# tui_patcher_processing_duration_seconds - Time taken to process jobs
# tui_patcher_api_requests_total - Total API requests by endpoint
# tui_patcher_uptime_seconds - Service uptime in seconds
'''

# Create Rust code for Prometheus metrics implementation
prometheus_rust = '''
// Prometheus metrics implementation for TUI-Patcher-Agent
// File: src/metrics.rs

use prometheus::{
    Counter, Gauge, Histogram, IntCounter, IntGauge, 
    Registry, Opts, HistogramOpts
};
use std::sync::Arc;

pub struct Metrics {
    pub jobs_total: IntCounter,
    pub jobs_completed: IntCounter,
    pub jobs_failed: IntCounter,
    pub jobs_processing: IntGauge,
    pub queue_size: IntGauge,
    pub processing_duration: Histogram,
    pub api_requests: IntCounter,
    pub uptime: IntGauge,
    pub registry: Registry,
}

impl Metrics {
    pub fn new() -> Arc<Self> {
        let registry = Registry::new();
        
        let jobs_total = IntCounter::with_opts(
            Opts::new("tui_patcher_jobs_total", "Total number of patch jobs")
        ).unwrap();
        
        let jobs_completed = IntCounter::with_opts(
            Opts::new("tui_patcher_jobs_completed", "Completed patch jobs")
        ).unwrap();
        
        let jobs_failed = IntCounter::with_opts(
            Opts::new("tui_patcher_jobs_failed", "Failed patch jobs")
        ).unwrap();
        
        let jobs_processing = IntGauge::with_opts(
            Opts::new("tui_patcher_jobs_processing", "Jobs currently processing")
        ).unwrap();
        
        let queue_size = IntGauge::with_opts(
            Opts::new("tui_patcher_queue_size", "Current queue size")
        ).unwrap();
        
        let processing_duration = Histogram::with_opts(
            HistogramOpts::new("tui_patcher_processing_duration_seconds", 
                             "Time taken to process jobs")
                .buckets(vec![0.1, 0.5, 1.0, 2.5, 5.0, 10.0, 30.0, 60.0])
        ).unwrap();
        
        let api_requests = IntCounter::with_opts(
            Opts::new("tui_patcher_api_requests_total", "Total API requests")
        ).unwrap();
        
        let uptime = IntGauge::with_opts(
            Opts::new("tui_patcher_uptime_seconds", "Service uptime")
        ).unwrap();

        // Register all metrics
        registry.register(Box::new(jobs_total.clone())).unwrap();
        registry.register(Box::new(jobs_completed.clone())).unwrap();
        registry.register(Box::new(jobs_failed.clone())).unwrap();
        registry.register(Box::new(jobs_processing.clone())).unwrap();
        registry.register(Box::new(queue_size.clone())).unwrap();
        registry.register(Box::new(processing_duration.clone())).unwrap();
        registry.register(Box::new(api_requests.clone())).unwrap();
        registry.register(Box::new(uptime.clone())).unwrap();

        Arc::new(Metrics {
            jobs_total,
            jobs_completed,
            jobs_failed,
            jobs_processing,
            queue_size,
            processing_duration,
            api_requests,
            uptime,
            registry,
        })
    }
    
    pub fn get_prometheus_metrics(&self) -> String {
        use prometheus::Encoder;
        let encoder = prometheus::TextEncoder::new();
        let metric_families = self.registry.gather();
        encoder.encode_to_string(&metric_families).unwrap_or_default()
    }
}
'''

# Create sample monitoring data
import pandas as pd
from datetime import datetime, timedelta
import random

# Generate sample monitoring data for the last 24 hours
start_time = datetime.now() - timedelta(hours=24)
timestamps = []
jobs_completed = []
jobs_failed = []
queue_size = []
processing_time = []
api_requests = []

for hour in range(24):
    current_time = start_time + timedelta(hours=hour)
    timestamps.append(current_time.strftime('%Y-%m-%d %H:%M:%S'))
    
    # Simulate realistic metrics
    base_completed = 50 + random.randint(-10, 20)  # 40-70 jobs per hour
    jobs_completed.append(base_completed)
    
    jobs_failed.append(random.randint(0, 5))  # 0-5 failures per hour
    queue_size.append(random.randint(2, 15))  # Queue size varies
    processing_time.append(round(random.uniform(1.2, 3.5), 2))  # 1.2-3.5s avg processing
    api_requests.append(base_completed * random.randint(3, 7))  # Multiple API calls per job

# Create DataFrame
monitoring_data = pd.DataFrame({
    'timestamp': timestamps,
    'jobs_completed_per_hour': jobs_completed,
    'jobs_failed_per_hour': jobs_failed,
    'current_queue_size': queue_size,
    'avg_processing_time_seconds': processing_time,
    'api_requests_per_hour': api_requests
})

# Save files
with open('prometheus_config.yml', 'w') as f:
    f.write(prometheus_config)

with open('metrics_implementation.rs', 'w') as f:
    f.write(prometheus_rust)
    
monitoring_data.to_csv('tui_patcher_monitoring_data.csv', index=False)

print("Created monitoring configuration files:")
print("- prometheus_config.yml - Prometheus scraping configuration")
print("- metrics_implementation.rs - Rust metrics implementation")
print("- tui_patcher_monitoring_data.csv - Sample 24-hour monitoring data")
print(f"\nSample data summary:")
print(f"Total hours tracked: {len(monitoring_data)}")
print(f"Total jobs completed: {monitoring_data['jobs_completed_per_hour'].sum()}")
print(f"Total failures: {monitoring_data['jobs_failed_per_hour'].sum()}")
print(f"Average processing time: {monitoring_data['avg_processing_time_seconds'].mean():.2f}s")

# Preview the data
print("\nFirst 5 rows of monitoring data:")
print(monitoring_data.head().to_string(index=False))