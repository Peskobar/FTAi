
// Prometheus metrics implementation for TUI-Patcher-Agent
// File: src/metrics.rs

use prometheus::{
    Counter, Gauge, Histogram, IntCounter, IntGauge, 
    Registry, Opts, HistogramOpts
};
use std::sync::Arc;

pub struct Metrics {
    pub jobs_total: IntCounter,
    pub jobs_completed: IntCounter,
    pub jobs_failed: IntCounter,
    pub jobs_processing: IntGauge,
    pub queue_size: IntGauge,
    pub processing_duration: Histogram,
    pub api_requests: IntCounter,
    pub uptime: IntGauge,
    pub registry: Registry,
}

impl Metrics {
    pub fn new() -> Arc<Self> {
        let registry = Registry::new();

        let jobs_total = IntCounter::with_opts(
            Opts::new("tui_patcher_jobs_total", "Total number of patch jobs")
        ).unwrap();

        let jobs_completed = IntCounter::with_opts(
            Opts::new("tui_patcher_jobs_completed", "Completed patch jobs")
        ).unwrap();

        let jobs_failed = IntCounter::with_opts(
            Opts::new("tui_patcher_jobs_failed", "Failed patch jobs")
        ).unwrap();

        let jobs_processing = IntGauge::with_opts(
            Opts::new("tui_patcher_jobs_processing", "Jobs currently processing")
        ).unwrap();

        let queue_size = IntGauge::with_opts(
            Opts::new("tui_patcher_queue_size", "Current queue size")
        ).unwrap();

        let processing_duration = Histogram::with_opts(
            HistogramOpts::new("tui_patcher_processing_duration_seconds", 
                             "Time taken to process jobs")
                .buckets(vec![0.1, 0.5, 1.0, 2.5, 5.0, 10.0, 30.0, 60.0])
        ).unwrap();

        let api_requests = IntCounter::with_opts(
            Opts::new("tui_patcher_api_requests_total", "Total API requests")
        ).unwrap();

        let uptime = IntGauge::with_opts(
            Opts::new("tui_patcher_uptime_seconds", "Service uptime")
        ).unwrap();

        // Register all metrics
        registry.register(Box::new(jobs_total.clone())).unwrap();
        registry.register(Box::new(jobs_completed.clone())).unwrap();
        registry.register(Box::new(jobs_failed.clone())).unwrap();
        registry.register(Box::new(jobs_processing.clone())).unwrap();
        registry.register(Box::new(queue_size.clone())).unwrap();
        registry.register(Box::new(processing_duration.clone())).unwrap();
        registry.register(Box::new(api_requests.clone())).unwrap();
        registry.register(Box::new(uptime.clone())).unwrap();

        Arc::new(Metrics {
            jobs_total,
            jobs_completed,
            jobs_failed,
            jobs_processing,
            queue_size,
            processing_duration,
            api_requests,
            uptime,
            registry,
        })
    }

    pub fn get_prometheus_metrics(&self) -> String {
        use prometheus::Encoder;
        let encoder = prometheus::TextEncoder::new();
        let metric_families = self.registry.gather();
        encoder.encode_to_string(&metric_families).unwrap_or_default()
    }
}
