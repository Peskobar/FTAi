// TUI-Patcher-Agent Dashboard JavaScript

class PatcherDashboard {
    constructor() {
        this.isQueuePaused = false;
        this.charts = {};
        this.refreshInterval = null;
        
        // Sample data from the API
        this.data = {
            metrics: {
                total_jobs: 1322,
                success_rate: 95.2,
                current_queue_size: 7,
                avg_processing_time: 2.42
            },
            recent_jobs: [
                {
                    id: "a1b2c3d4",
                    apk_path: "com.example.app.apk",
                    status: "completed",
                    created: "2025-07-19 10:15:23",
                    processing_time: "2.1s"
                },
                {
                    id: "e5f6g7h8",
                    apk_path: "org.test.mobile.apk",
                    status: "processing",
                    created: "2025-07-19 10:18:45",
                    processing_time: "-"
                },
                {
                    id: "i9j0k1l2",
                    apk_path: "net.sample.android.apk",
                    status: "failed",
                    created: "2025-07-19 10:12:01",
                    processing_time: "1.8s"
                },
                {
                    id: "m3n4o5p6",
                    apk_path: "io.demo.patcher.apk",
                    status: "queued",
                    created: "2025-07-19 10:20:12",
                    processing_time: "-"
                },
                {
                    id: "n7o8p9q0",
                    apk_path: "com.mobile.test.apk",
                    status: "completed",
                    created: "2025-07-19 10:08:15",
                    processing_time: "3.2s"
                },
                {
                    id: "r1s2t3u4",
                    apk_path: "org.android.sample.apk",
                    status: "queued",
                    created: "2025-07-19 10:22:30",
                    processing_time: "-"
                }
            ],
            hourly_data: [
                { hour: "06:00", jobs: 45 },
                { hour: "07:00", jobs: 62 },
                { hour: "08:00", jobs: 78 },
                { hour: "09:00", jobs: 89 },
                { hour: "10:00", jobs: 56 }
            ],
            status_distribution: [
                { status: "completed", count: 1258 },
                { status: "failed", count: 64 }
            ]
        };

        this.init();
    }

    init() {
        this.updateMetrics();
        this.populateJobsTable();
        this.createCharts();
        this.setupEventListeners();
        this.startAutoRefresh();
        this.updateTimestamp();
    }

    updateMetrics() {
        document.getElementById('total-jobs').textContent = this.data.metrics.total_jobs.toLocaleString();
        document.getElementById('success-rate').textContent = `${this.data.metrics.success_rate}%`;
        document.getElementById('queue-size').textContent = this.data.metrics.current_queue_size;
        document.getElementById('avg-processing-time').textContent = `${this.data.metrics.avg_processing_time}s`;
    }

    populateJobsTable() {
        const tbody = document.getElementById('jobs-tbody');
        tbody.innerHTML = '';

        this.data.recent_jobs.forEach(job => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td class="job-id">${job.id}</td>
                <td class="apk-path" title="${job.apk_path}">${job.apk_path}</td>
                <td><span class="status status--${job.status}">${job.status}</span></td>
                <td>${this.formatDate(job.created)}</td>
                <td>${job.processing_time}</td>
            `;
            tbody.appendChild(row);
        });
    }

    createCharts() {
        this.createHourlyChart();
        this.createStatusChart();
    }

    createHourlyChart() {
        const ctx = document.getElementById('hourly-chart').getContext('2d');
        
        this.charts.hourly = new Chart(ctx, {
            type: 'line',
            data: {
                labels: this.data.hourly_data.map(d => d.hour),
                datasets: [{
                    label: 'Jobs Processed',
                    data: this.data.hourly_data.map(d => d.jobs),
                    borderColor: '#38bdf8',
                    backgroundColor: 'rgba(56, 189, 248, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: '#38bdf8',
                    pointBorderColor: '#0ea5e9',
                    pointRadius: 6,
                    pointHoverRadius: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    x: {
                        grid: {
                            color: '#2d3748',
                            borderColor: '#2d3748'
                        },
                        ticks: {
                            color: '#94a3b8'
                        }
                    },
                    y: {
                        grid: {
                            color: '#2d3748',
                            borderColor: '#2d3748'
                        },
                        ticks: {
                            color: '#94a3b8'
                        }
                    }
                },
                elements: {
                    point: {
                        hoverBackgroundColor: '#38bdf8'
                    }
                }
            }
        });
    }

    createStatusChart() {
        const ctx = document.getElementById('status-chart').getContext('2d');
        
        const total = this.data.status_distribution.reduce((sum, item) => sum + item.count, 0);
        
        this.charts.status = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Completed', 'Failed'],
                datasets: [{
                    data: [1258, 64],
                    backgroundColor: ['#10b981', '#ef4444'],
                    borderColor: ['#059669', '#dc2626'],
                    borderWidth: 2,
                    hoverBackgroundColor: ['#34d399', '#f87171'],
                    hoverBorderWidth: 3
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: '#e2e8f0',
                            padding: 20,
                            usePointStyle: true,
                            pointStyle: 'circle'
                        }
                    }
                },
                cutout: '60%'
            }
        });
    }

    setupEventListeners() {
        // Queue management buttons
        document.getElementById('pause-queue').addEventListener('click', () => {
            this.toggleQueue(true);
        });

        document.getElementById('resume-queue').addEventListener('click', () => {
            this.toggleQueue(false);
        });

        document.getElementById('view-queue').addEventListener('click', () => {
            this.showQueueModal();
        });

        document.getElementById('retry-failed').addEventListener('click', () => {
            this.retryFailedJobs();
        });

        // Refresh button
        document.getElementById('refresh-jobs').addEventListener('click', () => {
            this.refreshData();
        });

        // Modal controls
        document.getElementById('close-modal').addEventListener('click', () => {
            this.hideModal();
        });

        document.getElementById('queue-modal').addEventListener('click', (e) => {
            if (e.target.id === 'queue-modal') {
                this.hideModal();
            }
        });
    }

    toggleQueue(pause) {
        this.isQueuePaused = pause;
        const pauseBtn = document.getElementById('pause-queue');
        const resumeBtn = document.getElementById('resume-queue');
        const statusEl = document.getElementById('queue-status');

        if (pause) {
            pauseBtn.style.display = 'none';
            resumeBtn.style.display = 'inline-flex';
            statusEl.textContent = 'Paused';
            statusEl.className = 'status status--warning';
            this.showNotification('Queue processing paused', 'warning');
        } else {
            pauseBtn.style.display = 'inline-flex';
            resumeBtn.style.display = 'none';
            statusEl.textContent = 'Active';
            statusEl.className = 'status status--success';
            this.showNotification('Queue processing resumed', 'success');
        }
    }

    showQueueModal() {
        const modal = document.getElementById('queue-modal');
        const queueDetails = document.getElementById('queue-details');
        
        // Generate queue details
        const queuedJobs = this.data.recent_jobs.filter(job => job.status === 'queued');
        const processingJobs = this.data.recent_jobs.filter(job => job.status === 'processing');
        
        queueDetails.innerHTML = `
            <div class="queue-summary">
                <h4>Queue Summary</h4>
                <p><strong>Total in queue:</strong> ${queuedJobs.length} jobs</p>
                <p><strong>Currently processing:</strong> ${processingJobs.length} job(s)</p>
                <p><strong>Estimated completion:</strong> ${this.calculateEstimatedTime()}</p>
            </div>
            <div class="queued-jobs">
                <h4>Queued Jobs</h4>
                <div class="job-list">
                    ${queuedJobs.map(job => `
                        <div class="queue-item">
                            <span class="job-id">${job.id}</span>
                            <span class="job-path">${job.apk_path}</span>
                            <span class="job-created">${this.formatDate(job.created)}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
        
        modal.classList.add('active');
    }

    hideModal() {
        document.getElementById('queue-modal').classList.remove('active');
    }

    retryFailedJobs() {
        const failedJobs = this.data.recent_jobs.filter(job => job.status === 'failed');
        
        if (failedJobs.length > 0) {
            this.showNotification(`Retrying ${failedJobs.length} failed job(s)`, 'info');
            
            // Simulate retrying failed jobs
            setTimeout(() => {
                failedJobs.forEach(job => {
                    job.status = 'queued';
                });
                this.data.metrics.current_queue_size += failedJobs.length;
                this.updateMetrics();
                this.populateJobsTable();
                this.showNotification('Failed jobs added back to queue', 'success');
            }, 1000);
        } else {
            this.showNotification('No failed jobs to retry', 'info');
        }
    }

    refreshData() {
        this.showNotification('Refreshing data...', 'info');
        
        // Simulate API call with random data changes
        setTimeout(() => {
            this.simulateDataUpdate();
            this.updateMetrics();
            this.populateJobsTable();
            this.updateCharts();
            this.updateTimestamp();
            this.showNotification('Data refreshed successfully', 'success');
        }, 800);
    }

    simulateDataUpdate() {
        // Simulate some changes in the data
        this.data.metrics.total_jobs += Math.floor(Math.random() * 3);
        this.data.metrics.current_queue_size = Math.max(0, this.data.metrics.current_queue_size + (Math.random() > 0.5 ? 1 : -1));
        this.data.metrics.avg_processing_time = parseFloat((this.data.metrics.avg_processing_time + (Math.random() - 0.5) * 0.2).toFixed(2));
        
        // Update some job statuses
        this.data.recent_jobs.forEach(job => {
            if (job.status === 'processing' && Math.random() > 0.7) {
                job.status = Math.random() > 0.1 ? 'completed' : 'failed';
                job.processing_time = `${(Math.random() * 3 + 1).toFixed(1)}s`;
            }
        });
    }

    updateCharts() {
        // Add new data point to hourly chart
        const newHour = new Date().getHours().toString().padStart(2, '0') + ':00';
        const newJobCount = Math.floor(Math.random() * 40 + 50);
        
        this.data.hourly_data.push({ hour: newHour, jobs: newJobCount });
        if (this.data.hourly_data.length > 6) {
            this.data.hourly_data.shift();
        }
        
        this.charts.hourly.data.labels = this.data.hourly_data.map(d => d.hour);
        this.charts.hourly.data.datasets[0].data = this.data.hourly_data.map(d => d.jobs);
        this.charts.hourly.update('none');
    }

    startAutoRefresh() {
        this.refreshInterval = setInterval(() => {
            this.refreshData();
        }, 30000); // Refresh every 30 seconds
    }

    updateTimestamp() {
        const now = new Date();
        const timeString = now.toLocaleTimeString();
        document.getElementById('last-update-time').textContent = timeString;
    }

    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }

    calculateEstimatedTime() {
        const queueSize = this.data.metrics.current_queue_size;
        const avgTime = this.data.metrics.avg_processing_time;
        const estimatedSeconds = queueSize * avgTime;
        
        if (estimatedSeconds < 60) {
            return `${Math.round(estimatedSeconds)}s`;
        } else if (estimatedSeconds < 3600) {
            return `${Math.round(estimatedSeconds / 60)}m`;
        } else {
            return `${Math.round(estimatedSeconds / 3600)}h`;
        }
    }

    showNotification(message, type) {
        // Create a simple notification system
        const notification = document.createElement('div');
        notification.className = `notification notification--${type}`;
        notification.textContent = message;
        
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 12px 20px;
            border-radius: 8px;
            color: white;
            font-weight: 500;
            z-index: 1001;
            opacity: 0;
            transform: translateX(100%);
            transition: all 0.3s ease;
        `;
        
        const colors = {
            success: '#10b981',
            warning: '#f59e0b',
            error: '#ef4444',
            info: '#38bdf8'
        };
        
        notification.style.backgroundColor = colors[type] || colors.info;
        
        document.body.appendChild(notification);
        
        // Animate in
        setTimeout(() => {
            notification.style.opacity = '1';
            notification.style.transform = 'translateX(0)';
        }, 100);
        
        // Remove after 3 seconds
        setTimeout(() => {
            notification.style.opacity = '0';
            notification.style.transform = 'translateX(100%)';
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }
}

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new PatcherDashboard();
});