# Create comprehensive project structure for TUI-Patcher-Agent v0.3.0 with Q3 2025 Sprint
import os
import datetime

# Create main project structure
project_structure = {
    "README.md": """# TUI-Patcher-Agent v0.3.0 → v1.0 Roadmap Implementation

## Project Overview
Enterprise-grade AI-powered Android patching service with complete Q3 2025 "Hardening & Visibility" sprint implementation.

## Current Status
- Version: 0.3.0
- Success Rate: 95%
- Average Latency: 2.4s
- Queue Size: ~15 tasks

## Target Metrics (Post-Roadmap)
- Success Rate: ≥99%
- Latency: ≤1.5s (p95)
- 100% Trace Coverage
- SLSA Level 3 Compliance

## Sprint Q3 2025: Hardening & Visibility (22 SP)
- ✅ OTEL OTLP Integration (8 SP) - ETA 2025-07-15
- ✅ Traceparent Middleware (5 SP) - ETA 2025-07-29  
- ✅ Slack Alert System (3 SP) - ETA 2025-08-12
- ✅ SBOM Pipeline (6 SP) - ETA 2025-08-26

## Quick Start
```bash
# Clone and setup
git clone https://github.com/tui-patcher/tui-patcher-agent.git
cd tui-patcher-agent
cargo build --release

# Run with OTEL
export OTEL_EXPORTER_OTLP_ENDPOINT="http://localhost:4317"
export PPX_API_KEY="your-perplexity-prod-key"
export PPX_API_KEY_CI="your-perplexity-ci-key"
./target/release/tui-patcher-agent
```

## Documentation
- [Architecture Guide](./ARCHITECTURE.md)
- [Observability Setup](./OBSERVABILITY.md)
- [Edge Deployment](./EDGE_GUIDE.md)
- [Sprint Q3 2025 Details](./docs/sprint-q3-2025.md)

## Project Structure
See detailed breakdown in ARCHITECTURE.md

## License
Apache 2.0 - See LICENSE file
""",
    
    "Cargo.toml": """[package]
name = "tui-patcher-agent"
version = "0.3.0"
edition = "2021"
license = "Apache-2.0"
description = "AI-powered Android patching service"
repository = "https://github.com/tui-patcher/tui-patcher-agent"

[dependencies]
# Core Web Framework
axum = { version = "0.7", features = ["macros", "ws"] }
tokio = { version = "1.35", features = ["full"] }
tower = { version = "0.4", features = ["full"] }
tower-http = { version = "0.5", features = ["trace", "request-id", "timeout"] }

# OpenTelemetry Stack (Q3 2025 Sprint)
opentelemetry = { version = "0.23", features = ["rt-tokio"] }
opentelemetry-otlp = { version = "0.13", features = ["grpc-tonic"] }
tracing-opentelemetry = "0.23"
opentelemetry-semantic-conventions = "0.16"
axum-otel = { version = "0.2", features = ["trace"] }

# Tracing & Observability
tracing = "0.1"
tracing-subscriber = { version = "0.3", features = ["env-filter", "json", "registry"] }

# HTTP Client & Async
reqwest = { version = "0.11", features = ["json", "rustls-tls"] }
hyper = { version = "1.0", features = ["full"] }

# Serialization
serde = { version = "1.0", features = ["derive"] }
serde_json = "1.0"
toml = "0.8"

# UUID & Time
uuid = { version = "1.6", features = ["v4", "serde"] }
chrono = { version = "0.4", features = ["serde"] }

# Slack Notifications (Q3 2025 Sprint)
webhook = { version = "0.8", features = ["json"] }
slack-hook = "0.10"

# Circuit Breaker Pattern
circuitbreaker-rs = "0.1"

# SBOM Generation (Q3 2025 Sprint)
cyclonedx-bom = "0.5"

# Perplexity AI Integration (Dual-key)
perplexity = "0.2"

# Machine Learning (Future Q4 2025)
tflite = { version = "0.9", optional = true }

# WASM Runtime (Future H1 2026)
wasmtime = { version = "15.0", optional = true }

# Error Handling
anyhow = "1.0"
thiserror = "1.0"

# Async Runtime
futures = "0.3"

[dev-dependencies]
tower-test = "0.4"

[features]
default = ["otel-integration"]
otel-integration = []
tflite-ai = ["tflite"]
wasm-plugins = ["wasmtime"]
edge-runtime = []

[[bin]]
name = "tui-patcher-agent"
path = "src/main.rs"

[[bin]]
name = "tui-patcher-edge"
path = "src/edge/main.rs"
required-features = ["edge-runtime"]
""",

    "ARCHITECTURE.md": """# TUI-Patcher-Agent Architecture Guide

## System Overview
TUI-Patcher-Agent is an enterprise-grade microservice for AI-powered Android application patching, designed to achieve 99%+ success rates with sub-1.5s latency.

## Current Architecture (v0.3.0)

### Core Components
```
┌─────────────┐    ┌──────────────┐    ┌─────────────────┐
│ API Gateway │───▶│ Queue Manager│───▶│ Patching Engine │
│ (Axum/Tokio)│    │              │    │                 │
└─────────────┘    └──────────────┘    └─────────────────┘
       │                                          │
       ▼                                          ▼
┌─────────────┐                          ┌─────────────────┐
│ Prometheus  │                          │  File Storage   │
│ Metrics     │                          │                 │
└─────────────┘                          └─────────────────┘
```

### Request Flow
1. **API Gateway** receives HTTP requests via Axum
2. **Queue Manager** handles async task scheduling
3. **Patching Engine** processes APK/AAB files
4. **File Storage** manages input/output artifacts
5. **Prometheus** collects basic metrics

## Target Architecture (Post-Roadmap)

### Layered Enterprise Architecture
```
┌───────────── Edge & External Layer ─────────────────┐
│ Edge Runtime │ Perplexity AI │ WASM Marketplace     │
│ (Termux/IoT) │ Dev Assistant │ (Plugin Ecosystem)   │
└─────────────────────────────────────────────────────┘
                          │
┌───────────── Core Services Layer ───────────────────┐
│                API Gateway Enhanced                  │
│              (Axum + OTEL + Trace)                  │
├─────────────────────────┬────────────────────────────┤
│ LSTM Autoscaler │ Circuit Breaker │ Self-healing    │
│                 │                  │ Queue           │
├─────────────────┴──────────────────┴─────────────────┤
│              On-device AI (TensorFlow Lite)         │
└─────────────────────────────────────────────────────┘
                          │
┌───────────── Infrastructure Layer ──────────────────┐
│ OTEL Collector │ SBOM Generator │ SLSA L3 Compliance │
│ Kubernetes     │ Monitoring     │ Security Scanning  │
└─────────────────────────────────────────────────────┘
```

## Sprint Q3 2025: Hardening & Visibility Implementation

### 1. OpenTelemetry Integration (8 SP)
**Files Modified:**
```
src/telemetry/mod.rs              # OTEL bootstrap
src/telemetry/tracing.rs          # Trace provider
src/telemetry/metrics.rs          # Metrics provider
src/main.rs                       # Integration point
config/otel.toml                  # Configuration
```

**Key Features:**
- OTLP export to Jaeger/Zipkin
- Semantic conventions compliance
- Distributed tracing support

### 2. Traceparent Middleware (5 SP)
**Files Modified:**
```
src/middleware/tracing.rs         # W3C Trace Context
src/middleware/mod.rs             # Middleware exports
src/routes/mod.rs                 # Router integration
src/extractors/trace_context.rs  # Custom extractors
```

**Capabilities:**
- W3C Trace Context propagation
- Cross-service correlation
- Span lifecycle management

### 3. Slack Alert System (3 SP)
**Files Modified:**
```
src/notifications/slack.rs       # Webhook client
src/alerts/mod.rs                 # Alert logic
src/alerts/rules_engine.rs       # Configurable rules
config.toml                       # Webhook config
```

**Alert Rules:**
- Queue size > 10 tasks
- Success rate < 95%
- Latency p95 > 3s
- Rate limiting: max 1/5min

### 4. SBOM Pipeline (6 SP)
**Files Modified:**
```
build.rs                          # SBOM generation
.github/workflows/sbom.yml        # CI automation
src/routes/sbom.rs               # HTTP endpoint
Dockerfile                       # Multi-stage build
scripts/slsa-verify.sh           # Verification
```

**Compliance Features:**
- CycloneDX format generation
- SLSA Level 3 attestation
- Dependency vulnerability scanning

## Directory Structure
```
tui-patcher-agent/
├── src/
│   ├── main.rs                   # Application entry
│   ├── lib.rs                    # Library exports
│   ├── config/                   # Configuration
│   ├── routes/                   # HTTP endpoints
│   ├── middleware/               # Axum middleware
│   ├── telemetry/                # OTEL integration
│   ├── notifications/            # Alert systems
│   ├── alerts/                   # Alert logic
│   ├── queue/                    # Task management
│   ├── patch/                    # Core patching
│   ├── ai/                       # ML components
│   ├── plugins/                  # WASM plugins
│   └── edge/                     # Edge runtime
├── config/                       # Configuration files
├── k8s/                         # Kubernetes manifests
├── helm/                        # Helm charts
├── .github/workflows/           # CI/CD pipelines
├── docs/                        # Documentation
├── examples/                    # Usage examples
└── assets/                      # Static resources
```

## Data Flow Patterns

### 1. HTTP Request Lifecycle
```
Client Request
    ↓
[API Gateway + OTEL Middleware]
    ↓
[Authentication & Rate Limiting]
    ↓
[Business Logic Routing]
    ↓
[Queue Management]
    ↓
[Patch Processing]
    ↓
[Response + Metrics]
```

### 2. Observability Data Flow
```
Application Spans
    ↓
[OTEL Collector]
    ↓
[Jaeger/Zipkin] ←→ [Prometheus] ←→ [Grafana]
    ↓
[Alert Manager]
    ↓
[Slack Notifications]
```

## Security Architecture

### Authentication Flow
1. **API Key Validation** (Header-based)
2. **Rate Limiting** (Token bucket)
3. **Input Sanitization** (APK validation)
4. **Output Validation** (Patch verification)

### SLSA Level 3 Requirements
- ✅ Provenance generation
- ✅ Non-falsifiable metadata
- ✅ Isolated builds
- ✅ Parameterless builds

## Performance Characteristics

### Current Metrics (v0.3.0)
- **Throughput:** ~400 req/min
- **Success Rate:** 95%
- **P95 Latency:** 2.4s
- **Queue Depth:** ~15 tasks

### Target Metrics (v1.0)
- **Throughput:** ~1000 req/min
- **Success Rate:** ≥99%
- **P95 Latency:** ≤1.5s
- **Queue Depth:** <5 tasks (auto-scaling)

## Deployment Scenarios

### 1. Cloud Native (Kubernetes)
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: tui-patcher-agent
spec:
  replicas: 3
  selector:
    matchLabels:
      app: tui-patcher-agent
  template:
    spec:
      containers:
      - name: agent
        image: tui-patcher:v0.3.0
        env:
        - name: OTEL_EXPORTER_OTLP_ENDPOINT
          value: "http://otel-collector:4317"
```

### 2. Edge Deployment (Termux)
```bash
# Install on Android/Termux
pkg install rust
cargo install --path . --features edge-runtime
tui-patcher-edge --config edge.toml
```

### 3. Local Development
```bash
# Docker Compose setup
docker-compose -f docker-compose.dev.yml up
```

## Future Roadmap Integration

### Q4 2025: Intelligent Patching
- LSTM-based autoscaling
- TensorFlow Lite integration
- Circuit breaker patterns

### H1 2026: Ecosystem & Plugins
- WASM plugin marketplace
- Perplexity AI dev assistant
- Advanced edge capabilities

## Monitoring & Alerting

### Key Metrics
- `tui_patcher_requests_total` (Counter)
- `tui_patcher_request_duration_seconds` (Histogram)
- `tui_patcher_queue_size` (Gauge)
- `tui_patcher_success_rate` (Gauge)

### Alert Conditions
```yaml
groups:
- name: tui-patcher
  rules:
  - alert: HighLatency
    expr: histogram_quantile(0.95, tui_patcher_request_duration_seconds) > 1.5
  - alert: LowSuccessRate
    expr: tui_patcher_success_rate < 0.99
  - alert: QueueBacklog
    expr: tui_patcher_queue_size > 10
```

## Development Guidelines

### Code Organization
- **Domain-driven design** with clear module boundaries
- **Async-first** architecture using Tokio
- **Error handling** with `anyhow` and `thiserror`
- **Configuration** via TOML files and environment variables

### Testing Strategy
- Unit tests for core business logic
- Integration tests for HTTP endpoints
- Load tests for performance validation
- Security tests for vulnerability scanning

### CI/CD Pipeline
1. **Build** - Cargo check + test
2. **Security** - Cargo audit + SBOM generation
3. **Package** - Docker image + SLSA attestation
4. **Deploy** - Helm chart + health checks

This architecture provides a solid foundation for the enterprise transformation of TUI-Patcher-Agent while maintaining backward compatibility and supporting future enhancements.
""",

    "OBSERVABILITY.md": """# TUI-Patcher-Agent Observability Guide

## Overview
This guide covers the comprehensive observability implementation for TUI-Patcher-Agent, focusing on the Q3 2025 "Hardening & Visibility" sprint deliverables.

## OpenTelemetry Integration

### Architecture
```
Application Code
    ↓
[OTEL SDK] ←→ [Tracing Provider] ←→ [Metrics Provider]
    ↓
[OTEL Collector]
    ↓
[Jaeger] [Prometheus] [Grafana]
```

### Configuration

#### Environment Variables
```bash
# OTEL Collector Endpoint
export OTEL_EXPORTER_OTLP_ENDPOINT="http://localhost:4317"
export OTEL_SERVICE_NAME="tui-patcher-agent"
export OTEL_SERVICE_VERSION="0.3.0"

# Sampling Configuration
export OTEL_TRACES_SAMPLER="traceidratio"
export OTEL_TRACES_SAMPLER_ARG="0.1"  # 10% sampling

# Resource Attributes
export OTEL_RESOURCE_ATTRIBUTES="deployment.environment=production,service.namespace=tui-patcher"
```

#### OTEL Configuration (config/otel.toml)
```toml
[exporter]
endpoint = "http://otel-collector:4317"
timeout = "30s"
compression = "gzip"

[tracer]
service_name = "tui-patcher-agent"
service_version = "0.3.0"
sampling_ratio = 0.1

[metrics]
export_interval = "30s"
export_timeout = "10s"

[logging]
level = "info"
structured = true
```

### Implementation Details

#### Tracer Initialization (src/telemetry/tracing.rs)
```rust
use opentelemetry::sdk::{trace, Resource};
use opentelemetry::KeyValue;
use opentelemetry_otlp::WithExportConfig;

pub async fn init_tracer() -> Result<Tracer, Box<dyn std::error::Error + Send + Sync>> {
    let tracer = opentelemetry_otlp::new_pipeline()
        .tracing()
        .with_exporter(
            opentelemetry_otlp::new_exporter()
                .tonic()
                .with_endpoint("http://otel-collector:4317"),
        )
        .with_trace_config(
            trace::config()
                .with_resource(Resource::new(vec![
                    KeyValue::new("service.name", "tui-patcher-agent"),
                    KeyValue::new("service.version", "0.3.0"),
                    KeyValue::new("service.namespace", "tui-patcher"),
                ]))
                .with_sampler(trace::Sampler::TraceIdRatioBased(0.1)),
        )
        .install_batch(opentelemetry::runtime::Tokio)?;
    
    Ok(tracer)
}
```

#### Metrics Provider (src/telemetry/metrics.rs)
```rust
use opentelemetry::metrics::{Counter, Histogram, Gauge};
use opentelemetry::global;

pub struct Metrics {
    pub requests_total: Counter<u64>,
    pub request_duration: Histogram<f64>,
    pub queue_size: Gauge<u64>,
    pub success_rate: Gauge<f64>,
}

impl Metrics {
    pub fn new() -> Self {
        let meter = global::meter("tui-patcher-agent");
        
        Self {
            requests_total: meter
                .u64_counter("tui_patcher_requests_total")
                .with_description("Total number of requests processed")
                .init(),
            
            request_duration: meter
                .f64_histogram("tui_patcher_request_duration_seconds")
                .with_description("Request processing duration in seconds")
                .init(),
            
            queue_size: meter
                .u64_gauge("tui_patcher_queue_size")
                .with_description("Current queue size")
                .init(),
            
            success_rate: meter
                .f64_gauge("tui_patcher_success_rate")
                .with_description("Success rate over last 5 minutes")
                .init(),
        }
    }
}
```

## Distributed Tracing

### Traceparent Middleware Implementation

#### W3C Trace Context Propagation
```rust
use axum::{extract::Request, middleware::Next, response::Response};
use tracing::{instrument, Span};
use opentelemetry::trace::TraceContextExt;

#[instrument(skip(req, next))]
pub async fn trace_middleware(req: Request, next: Next) -> Response {
    // Extract trace context from headers
    let trace_context = extract_trace_context(&req);
    
    // Create span with trace context
    let span = tracing::info_span!(
        "http_request",
        method = %req.method(),
        uri = %req.uri(),
        version = ?req.version(),
        trace_id = %trace_context.trace_id(),
        span_id = %trace_context.span_id(),
    );
    
    // Process request within span
    let response = span.in_scope(|| next.run(req)).await;
    
    // Add trace headers to response
    add_trace_headers(response, &trace_context)
}

fn extract_trace_context(req: &Request) -> SpanContext {
    use opentelemetry::propagation::Extractor;
    
    let extractor = HeaderExtractor::new(req.headers());
    global::get_text_map_propagator(|propagator| {
        propagator.extract(&extractor)
    })
}
```

### Span Hierarchy
```
http_request (root span)
├── auth_validation
├── rate_limiting_check
├── queue_management
│   ├── queue_enqueue
│   └── queue_process
├── patch_processing
│   ├── apk_analysis
│   ├── patch_generation
│   └── apk_rebuild
└── response_formation
```

### Custom Span Attributes
```rust
// Business context attributes
span.set_attribute("apk.package_name", package_name);
span.set_attribute("apk.version_code", version_code);
span.set_attribute("patch.type", patch_type);
span.set_attribute("queue.position", queue_position);

// Technical attributes
span.set_attribute("http.route", route);
span.set_attribute("user.id", user_id);
span.set_attribute("request.size_bytes", content_length);
```

## Metrics Collection

### Core Business Metrics
```rust
#[derive(Clone)]
pub struct BusinessMetrics {
    // Request metrics
    pub requests_total: Counter<u64>,
    pub requests_duration: Histogram<f64>,
    pub requests_in_flight: Gauge<i64>,
    
    // Success/failure metrics
    pub success_rate: Gauge<f64>,
    pub error_rate: Gauge<f64>,
    pub patch_success_total: Counter<u64>,
    pub patch_failure_total: Counter<u64>,
    
    // Queue metrics
    pub queue_size: Gauge<u64>,
    pub queue_wait_time: Histogram<f64>,
    pub queue_processing_time: Histogram<f64>,
    
    // Resource metrics
    pub memory_usage: Gauge<f64>,
    pub cpu_usage: Gauge<f64>,
    pub disk_usage: Gauge<f64>,
}
```

### Metric Labels and Dimensions
```rust
// Request labels
let labels = [
    ("method", request.method().as_str()),
    ("route", route.as_str()),
    ("status_code", status_code.as_str()),
    ("user_agent", user_agent.as_str()),
];

// Business labels
let business_labels = [
    ("patch_type", patch_type.as_str()),
    ("android_version", android_version.as_str()),
    ("app_category", app_category.as_str()),
];
```

## Alert System Integration

### Slack Webhook Configuration
```rust
use slack_hook::{Slack, PayloadBuilder};

pub struct SlackNotifier {
    webhook_url: String,
    channel: String,
    username: String,
}

impl SlackNotifier {
    pub async fn send_alert(&self, alert: &Alert) -> Result<(), SlackError> {
        let slack = Slack::new(&self.webhook_url)?;
        
        let payload = PayloadBuilder::new()
            .channel(&self.channel)
            .username(&self.username)
            .icon_emoji(":warning:")
            .text(&format!("🚨 TUI-Patcher Alert: {}", alert.title))
            .attachments(vec![
                attachment_builder()
                    .color("danger")
                    .title(&alert.title)
                    .text(&alert.description)
                    .field(Field::new("Metric", &alert.metric, true))
                    .field(Field::new("Value", &alert.value, true))
                    .field(Field::new("Threshold", &alert.threshold, true))
                    .field(Field::new("Trace ID", &alert.trace_id, true))
                    .build()?
            ])
            .build()?;
        
        slack.send(&payload).await
    }
}
```

### Alert Rules Engine
```rust
pub struct AlertRule {
    pub name: String,
    pub condition: AlertCondition,
    pub threshold: f64,
    pub duration: Duration,
    pub severity: Severity,
    pub enabled: bool,
}

pub enum AlertCondition {
    GreaterThan(MetricType),
    LessThan(MetricType),
    PercentageChange(MetricType, Duration),
}

// Predefined alert rules
pub fn default_alert_rules() -> Vec<AlertRule> {
    vec![
        AlertRule {
            name: "High Queue Size".to_string(),
            condition: AlertCondition::GreaterThan(MetricType::QueueSize),
            threshold: 10.0,
            duration: Duration::from_secs(60),
            severity: Severity::Warning,
            enabled: true,
        },
        AlertRule {
            name: "Low Success Rate".to_string(),
            condition: AlertCondition::LessThan(MetricType::SuccessRate),
            threshold: 0.95,
            duration: Duration::from_secs(300),
            severity: Severity::Critical,
            enabled: true,
        },
        AlertRule {
            name: "High P95 Latency".to_string(),
            condition: AlertCondition::GreaterThan(MetricType::LatencyP95),
            threshold: 1.5,
            duration: Duration::from_secs(180),
            severity: Severity::Warning,
            enabled: true,
        },
    ]
}
```

## SBOM and Compliance Monitoring

### SBOM Generation Pipeline
```bash
#!/bin/bash
# scripts/generate-sbom.sh

set -euo pipefail

echo "Generating SBOM for TUI-Patcher-Agent..."

# Install cargo-cyclonedx if not present
if ! cargo cyclonedx --version >/dev/null 2>&1; then
    cargo install cargo-cyclonedx
fi

# Generate CycloneDX SBOM
cargo cyclonedx --format json --output cyclonedx.json

# Validate SBOM format
echo "Validating SBOM format..."
if command -v cyclonedx-cli >/dev/null 2>&1; then
    cyclonedx-cli validate cyclonedx.json
fi

# Generate SPDX format (optional)
if command -v cargo-spdx >/dev/null 2>&1; then
    cargo spdx --output spdx.json
fi

echo "SBOM generation complete:"
echo "- CycloneDX: cyclonedx.json"
echo "- SPDX: spdx.json (if available)"

# Upload to artifact store
if [[ "${CI:-false}" == "true" ]]; then
    echo "Uploading SBOM to artifact store..."
    # Implementation depends on your artifact storage
fi
```

### SLSA Level 3 Attestation
```yaml
# .github/workflows/slsa-attestation.yml
name: SLSA Attestation

on:
  release:
    types: [published]

jobs:
  attestation:
    runs-on: ubuntu-latest
    permissions:
      id-token: write
      contents: read
      attestations: write
    
    steps:
    - uses: actions/checkout@v4
    
    - name: Build artifact
      run: |
        cargo build --release
        cp target/release/tui-patcher-agent ./
    
    - name: Generate SBOM
      run: |
        cargo install cargo-cyclonedx
        cargo cyclonedx --format json --output cyclonedx.json
    
    - name: Generate attestation
      uses: actions/attest-build-provenance@v1
      with:
        subject-path: |
          tui-patcher-agent
          cyclonedx.json
```

## Monitoring Dashboards

### Grafana Dashboard Configuration
```json
{
  "dashboard": {
    "id": null,
    "title": "TUI-Patcher-Agent Observability",
    "tags": ["tui-patcher", "observability"],
    "timezone": "browser",
    "panels": [
      {
        "title": "Request Rate",
        "type": "stat",
        "targets": [
          {
            "expr": "rate(tui_patcher_requests_total[5m])",
            "legendFormat": "req/sec"
          }
        ]
      },
      {
        "title": "Success Rate",
        "type": "gauge",
        "targets": [
          {
            "expr": "tui_patcher_success_rate",
            "legendFormat": "Success Rate"
          }
        ],
        "fieldConfig": {
          "defaults": {
            "min": 0,
            "max": 1,
            "thresholds": {
              "steps": [
                {"color": "red", "value": 0},
                {"color": "yellow", "value": 0.95},
                {"color": "green", "value": 0.99}
              ]
            }
          }
        }
      },
      {
        "title": "P95 Latency",
        "type": "timeseries",
        "targets": [
          {
            "expr": "histogram_quantile(0.95, rate(tui_patcher_request_duration_seconds_bucket[5m]))",
            "legendFormat": "P95 Latency"
          }
        ]
      },
      {
        "title": "Queue Size",
        "type": "timeseries",
        "targets": [
          {
            "expr": "tui_patcher_queue_size",
            "legendFormat": "Queue Size"
          }
        ]
      }
    ]
  }
}
```

### Jaeger Query Examples
```bash
# Find traces with high latency
curl "http://jaeger:16686/api/traces?service=tui-patcher-agent&minDuration=2s"

# Find failed patch operations
curl "http://jaeger:16686/api/traces?service=tui-patcher-agent&tags={\"error\":\"true\"}"

# Find traces for specific APK
curl "http://jaeger:16686/api/traces?service=tui-patcher-agent&tags={\"apk.package_name\":\"com.example.app\"}"
```

## Performance Monitoring

### SLI/SLO Configuration
```yaml
# SLI (Service Level Indicators)
sli:
  availability:
    metric: "sum(rate(tui_patcher_requests_total{code!~\"5..\"}[5m])) / sum(rate(tui_patcher_requests_total[5m]))"
    threshold: 0.99
  
  latency:
    metric: "histogram_quantile(0.95, rate(tui_patcher_request_duration_seconds_bucket[5m]))"
    threshold: 1.5
  
  throughput:
    metric: "sum(rate(tui_patcher_requests_total[5m]))"
    threshold: 10

# SLO (Service Level Objectives)
slo:
  availability: "99.9% over 30 days"
  latency: "95% of requests under 1.5s"
  throughput: "Handle at least 1000 req/min"
```

### Error Tracking
```rust
use tracing::{error, warn, info};

// Structured error logging
#[instrument(skip(self))]
pub async fn process_patch(&self, request: PatchRequest) -> Result<PatchResponse, PatchError> {
    let _timer = self.metrics.request_duration.start_timer();
    
    match self.validate_request(&request).await {
        Ok(_) => {
            info!(
                apk.package_name = %request.package_name,
                apk.version = %request.version,
                "Processing patch request"
            );
        },
        Err(e) => {
            warn!(
                error = %e,
                apk.package_name = %request.package_name,
                "Request validation failed"
            );
            self.metrics.error_rate.add(1, &[]);
            return Err(PatchError::ValidationFailed(e));
        }
    }
    
    // Processing logic...
    
    match result {
        Ok(response) => {
            self.metrics.success_rate.add(1, &[]);
            info!("Patch processing completed successfully");
            Ok(response)
        },
        Err(e) => {
            error!(
                error = %e,
                apk.package_name = %request.package_name,
                "Patch processing failed"
            );
            self.metrics.error_rate.add(1, &[]);
            Err(e)
        }
    }
}
```

## Observability Best Practices

### 1. Correlation IDs
- Generate unique correlation ID for each request
- Propagate through all service calls
- Include in all log messages and traces

### 2. Structured Logging
- Use consistent log format (JSON in production)
- Include relevant context in every log message
- Avoid sensitive data in logs

### 3. Metric Naming
- Follow OpenTelemetry semantic conventions
- Use consistent naming patterns
- Include relevant labels for dimensionality

### 4. Trace Sampling
- Use appropriate sampling rates for production
- Ensure critical paths are always traced
- Consider cost vs. visibility trade-offs

### 5. Alert Hygiene
- Avoid alert fatigue with proper thresholds
- Include relevant context in alert messages
- Provide clear escalation paths

This observability implementation provides comprehensive visibility into TUI-Patcher-Agent operations, enabling proactive monitoring, rapid troubleshooting, and data-driven optimization decisions.
""",

    "EDGE_GUIDE.md": """# TUI-Patcher-Agent Edge Deployment Guide

## Overview
This guide covers deploying TUI-Patcher-Agent in edge environments, including Android/Termux, IoT devices, and resource-constrained scenarios.

## Edge Architecture

### Components
```
┌─────────────────── Edge Device ────────────────────┐
│                                                    │
│  ┌──────────────┐    ┌─────────────────────────┐   │
│  │ TUI-Patcher  │───▶│    Local Processing     │   │
│  │    Edge      │    │   (Lightweight Core)    │   │
│  │              │    │                         │   │
│  └──────────────┘    └─────────────────────────┘   │
│           │                                        │
│           ▼                                        │
│  ┌─────────────────────────────────────────────┐   │
│  │           Local Storage                     │   │
│  │        (SQLite/Files)                      │   │
│  └─────────────────────────────────────────────┘   │
│                                                    │
└────────────────────────────────────────────────────┘
                         │
                         ▼ (Optional Sync)
┌─────────────────────────────────────────────────────┐
│              Cloud TUI-Patcher Cluster             │
│                 (Full Features)                    │
└─────────────────────────────────────────────────────┘
```

## Supported Platforms

### 1. Android/Termux
**Target:** Android devices with Termux environment
**Use Case:** Mobile app patching, local development

### 2. Raspberry Pi / IoT
**Target:** ARM-based single-board computers
**Use Case:** Local patching stations, offline environments

### 3. Embedded Linux
**Target:** Resource-constrained Linux devices
**Use Case:** Factory environments, air-gapped networks

## Edge Binary Configuration

### Cargo.toml Features
```toml
[features]
default = ["edge-runtime"]
edge-runtime = [
    "minimal-deps",
    "local-storage", 
    "offline-mode"
]
minimal-deps = []
local-storage = ["sqlite", "sled"]
offline-mode = []

# Reduced dependencies for edge
[dependencies]
# Core (required)
tokio = { version = "1.35", features = ["rt", "net", "fs"] }
serde = { version = "1.0", features = ["derive"] }
anyhow = "1.0"

# Local storage
sqlite = { version = "0.32", optional = true }
sled = { version = "0.34", optional = true }

# HTTP (minimal)
hyper = { version = "1.0", features = ["client", "http1"] }

# Remove heavy dependencies
# opentelemetry = { version = "0.23", optional = true }  # Cloud only
# tracing-opentelemetry = { version = "0.23", optional = true }  # Cloud only
```

### Edge Main Binary (src/edge/main.rs)
```rust
use std::path::PathBuf;
use tokio::signal;
use anyhow::Result;

mod config;
mod storage;
mod patch;
mod sync;

use config::EdgeConfig;
use storage::LocalStorage;
use patch::EdgePatchEngine;

#[tokio::main]
async fn main() -> Result<()> {
    // Initialize edge-specific logging
    init_edge_logging()?;
    
    // Load configuration
    let config = EdgeConfig::load_from_file("edge.toml")?;
    
    // Initialize local storage
    let storage = LocalStorage::new(&config.storage_path).await?;
    
    // Initialize patch engine
    let patch_engine = EdgePatchEngine::new(storage.clone(), config.clone()).await?;
    
    // Start background sync (if enabled)
    let sync_handle = if config.sync_enabled {
        Some(start_sync_service(storage.clone(), config.clone()).await?)
    } else {
        None
    };
    
    // Start CLI interface
    start_cli_interface(patch_engine, config).await?;
    
    // Wait for shutdown signal
    signal::ctrl_c().await?;
    println!("Shutting down edge runtime...");
    
    if let Some(handle) = sync_handle {
        handle.abort();
    }
    
    Ok(())
}

async fn init_edge_logging() -> Result<()> {
    use tracing_subscriber::{layer::SubscriberExt, util::SubscriberInitExt};
    
    tracing_subscriber::registry()
        .with(tracing_subscriber::fmt::layer()
            .with_target(false)
            .with_thread_ids(false)
            .with_file(false)
            .with_line_number(false)
            .compact())
        .init();
    
    Ok(())
}
```

## Installation Methods

### 1. Android/Termux Installation
```bash
# Update Termux packages
pkg update && pkg upgrade

# Install required dependencies
pkg install rust git build-essential

# Clone repository
git clone https://github.com/tui-patcher/tui-patcher-agent.git
cd tui-patcher-agent

# Build edge binary
cargo build --release --features edge-runtime --bin tui-patcher-edge

# Install to PATH
cp target/release/tui-patcher-edge $PREFIX/bin/

# Create config directory
mkdir -p ~/.config/tui-patcher-edge

# Generate default config
tui-patcher-edge --generate-config > ~/.config/tui-patcher-edge/config.toml
```

### 2. Raspberry Pi Installation
```bash
# Install Rust on Raspberry Pi OS
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
source ~/.cargo/env

# Clone and build
git clone https://github.com/tui-patcher/tui-patcher-agent.git
cd tui-patcher-agent

# Build for ARM
cargo build --release --features edge-runtime --bin tui-patcher-edge

# Install as systemd service
sudo cp target/release/tui-patcher-edge /usr/local/bin/
sudo cp scripts/tui-patcher-edge.service /etc/systemd/system/
sudo systemctl enable tui-patcher-edge
sudo systemctl start tui-patcher-edge
```

### 3. Docker Edge Container
```dockerfile
# Dockerfile.edge
FROM rust:1.75-slim as builder

WORKDIR /app
COPY . .

# Build edge binary
RUN cargo build --release --features edge-runtime --bin tui-patcher-edge

FROM debian:bookworm-slim

# Install runtime dependencies
RUN apt-get update && apt-get install -y \
    ca-certificates \
    libssl3 \
    && rm -rf /var/lib/apt/lists/*

# Copy binary
COPY --from=builder /app/target/release/tui-patcher-edge /usr/local/bin/

# Create data directory
RUN mkdir -p /data

# Set working directory
WORKDIR /data

# Expose port for local API
EXPOSE 8080

# Run edge binary
CMD ["tui-patcher-edge", "--config", "/data/edge.toml"]
```

## Configuration

### Edge Configuration (edge.toml)
```toml
[service]
name = "tui-patcher-edge"
bind_address = "127.0.0.1:8080"
log_level = "info"

[storage]
type = "sqlite"  # "sqlite" or "sled"
path = "./data/edge.db"
max_size_mb = 100

[processing]
# Reduced resource limits
max_concurrent_jobs = 2
max_memory_mb = 512
temp_dir = "./tmp"

[sync]
enabled = false  # Disable by default for offline
cloud_endpoint = "https://api.tui-patcher.com"
sync_interval_minutes = 60
api_key = ""  # Set if sync enabled

[features]
# Enable only essential features
basic_patching = true
ai_analysis = false  # Disable AI for edge
metrics_collection = false  # Disable OTEL
alerting = false  # Disable alerts

[security]
# Simplified security for edge
require_auth = false
allow_local_only = true
max_file_size_mb = 50
```

## Edge-Specific Features

### 1. Local Storage Implementation
```rust
// src/edge/storage.rs
use serde::{Deserialize, Serialize};
use std::path::Path;
use anyhow::Result;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PatchJob {
    pub id: String,
    pub status: JobStatus,
    pub input_path: String,
    pub output_path: Option<String>,
    pub created_at: chrono::DateTime<chrono::Utc>,
    pub completed_at: Option<chrono::DateTime<chrono::Utc>>,
    pub error_message: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum JobStatus {
    Pending,
    Processing,
    Completed,
    Failed,
}

pub struct LocalStorage {
    db: sqlite::Connection,
}

impl LocalStorage {
    pub async fn new(db_path: &Path) -> Result<Self> {
        let db = sqlite::open(db_path)?;
        
        // Initialize schema
        db.execute("
            CREATE TABLE IF NOT EXISTS patch_jobs (
                id TEXT PRIMARY KEY,
                status TEXT NOT NULL,
                input_path TEXT NOT NULL,
                output_path TEXT,
                created_at TEXT NOT NULL,
                completed_at TEXT,
                error_message TEXT
            )
        ")?;
        
        Ok(Self { db })
    }
    
    pub async fn create_job(&self, job: &PatchJob) -> Result<()> {
        let mut statement = self.db.prepare("
            INSERT INTO patch_jobs 
            (id, status, input_path, output_path, created_at, completed_at, error_message)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ")?;
        
        statement.bind((
            1, job.id.as_str(),
            2, format!("{:?}", job.status).as_str(),
            3, job.input_path.as_str(),
            4, job.output_path.as_deref().unwrap_or(""),
            5, job.created_at.to_rfc3339().as_str(),
            6, job.completed_at.map(|t| t.to_rfc3339()).as_deref().unwrap_or(""),
            7, job.error_message.as_deref().unwrap_or(""),
        ))?;
        
        statement.next()?;
        Ok(())
    }
    
    pub async fn get_job(&self, id: &str) -> Result<Option<PatchJob>> {
        let mut statement = self.db.prepare("
            SELECT id, status, input_path, output_path, created_at, completed_at, error_message
            FROM patch_jobs WHERE id = ?
        ")?;
        
        statement.bind((1, id))?;
        
        if let Some(Ok(row)) = statement.next() {
            let job = PatchJob {
                id: row.read::<&str, _>(0).to_string(),
                status: match row.read::<&str, _>(1) {
                    "Pending" => JobStatus::Pending,
                    "Processing" => JobStatus::Processing,
                    "Completed" => JobStatus::Completed,
                    "Failed" => JobStatus::Failed,
                    _ => JobStatus::Failed,
                },
                input_path: row.read::<&str, _>(2).to_string(),
                output_path: {
                    let path = row.read::<&str, _>(3);
                    if path.is_empty() { None } else { Some(path.to_string()) }
                },
                created_at: chrono::DateTime::parse_from_rfc3339(row.read::<&str, _>(4))?
                    .with_timezone(&chrono::Utc),
                completed_at: {
                    let time_str = row.read::<&str, _>(5);
                    if time_str.is_empty() {
                        None
                    } else {
                        Some(chrono::DateTime::parse_from_rfc3339(time_str)?
                            .with_timezone(&chrono::Utc))
                    }
                },
                error_message: {
                    let msg = row.read::<&str, _>(6);
                    if msg.is_empty() { None } else { Some(msg.to_string()) }
                },
            };
            Ok(Some(job))
        } else {
            Ok(None)
        }
    }
}
```

### 2. Lightweight Patch Engine
```rust
// src/edge/patch.rs
use std::path::{Path, PathBuf};
use std::process::Command;
use anyhow::{Result, Context};
use tokio::fs;

pub struct EdgePatchEngine {
    storage: LocalStorage,
    config: EdgeConfig,
    temp_dir: PathBuf,
}

impl EdgePatchEngine {
    pub async fn new(storage: LocalStorage, config: EdgeConfig) -> Result<Self> {
        let temp_dir = PathBuf::from(&config.processing.temp_dir);
        fs::create_dir_all(&temp_dir).await?;
        
        Ok(Self {
            storage,
            config,
            temp_dir,
        })
    }
    
    pub async fn process_apk(&self, input_path: &Path) -> Result<PathBuf> {
        // Simplified patching without AI
        let job_id = uuid::Uuid::new_v4().to_string();
        let output_path = self.temp_dir.join(format!("{}_patched.apk", job_id));
        
        // Create job record
        let job = PatchJob {
            id: job_id.clone(),
            status: JobStatus::Processing,
            input_path: input_path.to_string_lossy().to_string(),
            output_path: Some(output_path.to_string_lossy().to_string()),
            created_at: chrono::Utc::now(),
            completed_at: None,
            error_message: None,
        };
        
        self.storage.create_job(&job).await?;
        
        // Basic patching using apktool
        let success = self.run_apktool_patch(input_path, &output_path).await?;
        
        // Update job status
        let final_status = if success {
            JobStatus::Completed
        } else {
            JobStatus::Failed
        };
        
        // Update job record would go here...
        
        if success {
            Ok(output_path)
        } else {
            Err(anyhow::anyhow!("Patch processing failed"))
        }
    }
    
    async fn run_apktool_patch(&self, input: &Path, output: &Path) -> Result<bool> {
        // Extract APK
        let extract_dir = self.temp_dir.join("extracted");
        fs::create_dir_all(&extract_dir).await?;
        
        let extract_output = Command::new("apktool")
            .args(&["d", input.to_str().unwrap(), "-o", extract_dir.to_str().unwrap()])
            .output()
            .context("Failed to extract APK")?;
        
        if !extract_output.status.success() {
            return Ok(false);
        }
        
        // Apply basic patches (placeholder)
        self.apply_basic_patches(&extract_dir).await?;
        
        // Rebuild APK
        let rebuild_output = Command::new("apktool")
            .args(&["b", extract_dir.to_str().unwrap(), "-o", output.to_str().unwrap()])
            .output()
            .context("Failed to rebuild APK")?;
        
        // Cleanup
        fs::remove_dir_all(&extract_dir).await.ok();
        
        Ok(rebuild_output.status.success())
    }
    
    async fn apply_basic_patches(&self, extract_dir: &Path) -> Result<()> {
        // Implement basic patching logic
        // This would contain the core patching algorithms
        // without AI/ML dependencies
        
        // Example: Remove debug flags
        let manifest_path = extract_dir.join("AndroidManifest.xml");
        if manifest_path.exists() {
            // Parse and modify manifest
            // Implementation depends on specific patches needed
        }
        
        Ok(())
    }
}
```

### 3. CLI Interface
```rust
// src/edge/cli.rs
use clap::{Parser, Subcommand};
use std::path::PathBuf;

#[derive(Parser)]
#[command(name = "tui-patcher-edge")]
#[command(about = "TUI-Patcher Edge Runtime for resource-constrained environments")]
pub struct Cli {
    #[command(subcommand)]
    pub command: Commands,
    
    #[arg(long, default_value = "edge.toml")]
    pub config: PathBuf,
    
    #[arg(long)]
    pub verbose: bool,
}

#[derive(Subcommand)]
pub enum Commands {
    /// Patch an APK file
    Patch {
        /// Input APK file path
        input: PathBuf,
        
        /// Output APK file path (optional)
        #[arg(long)]
        output: Option<PathBuf>,
    },
    
    /// Check status of a patch job
    Status {
        /// Job ID to check
        job_id: String,
    },
    
    /// List all jobs
    List {
        /// Show only active jobs
        #[arg(long)]
        active: bool,
    },
    
    /// Start daemon mode
    Daemon,
    
    /// Generate default configuration
    GenerateConfig,
    
    /// Sync with cloud (if enabled)
    Sync,
}

pub async fn run_cli(engine: EdgePatchEngine, config: EdgeConfig) -> Result<()> {
    let cli = Cli::parse();
    
    match cli.command {
        Commands::Patch { input, output } => {
            println!("Processing APK: {}", input.display());
            
            match engine.process_apk(&input).await {
                Ok(result_path) => {
                    if let Some(output_path) = output {
                        fs::copy(&result_path, &output_path).await?;
                        println!("Patched APK saved to: {}", output_path.display());
                    } else {
                        println!("Patched APK available at: {}", result_path.display());
                    }
                },
                Err(e) => {
                    eprintln!("Error processing APK: {}", e);
                    std::process::exit(1);
                }
            }
        },
        
        Commands::Status { job_id } => {
            match engine.get_job_status(&job_id).await {
                Ok(Some(job)) => {
                    println!("Job {}: {:?}", job_id, job.status);
                    if let Some(error) = job.error_message {
                        println!("Error: {}", error);
                    }
                },
                Ok(None) => {
                    println!("Job {} not found", job_id);
                },
                Err(e) => {
                    eprintln!("Error checking status: {}", e);
                }
            }
        },
        
        Commands::List { active } => {
            // Implementation for listing jobs
            println!("Listing jobs...");
        },
        
        Commands::Daemon => {
            println!("Starting daemon mode...");
            // Start HTTP server for API access
            start_daemon_server(engine, config).await?;
        },
        
        Commands::GenerateConfig => {
            let default_config = EdgeConfig::default();
            let config_toml = toml::to_string_pretty(&default_config)?;
            println!("{}", config_toml);
        },
        
        Commands::Sync => {
            if config.sync.enabled {
                println!("Syncing with cloud...");
                // Implementation for cloud sync
            } else {
                println!("Sync is disabled in configuration");
            }
        },
    }
    
    Ok(())
}
```

## Resource Optimization

### Memory Management
```rust
// src/edge/resources.rs
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;

pub struct ResourceMonitor {
    max_memory_mb: usize,
    current_memory: Arc<AtomicUsize>,
}

impl ResourceMonitor {
    pub fn new(max_memory_mb: usize) -> Self {
        Self {
            max_memory_mb,
            current_memory: Arc::new(AtomicUsize::new(0)),
        }
    }
    
    pub fn check_memory_available(&self, required_mb: usize) -> bool {
        let current = self.current_memory.load(Ordering::Relaxed);
        current + required_mb <= self.max_memory_mb
    }
    
    pub fn allocate_memory(&self, mb: usize) -> Option<MemoryGuard> {
        if self.check_memory_available(mb) {
            self.current_memory.fetch_add(mb, Ordering::Relaxed);
            Some(MemoryGuard {
                mb,
                monitor: self.current_memory.clone(),
            })
        } else {
            None
        }
    }
}

pub struct MemoryGuard {
    mb: usize,
    monitor: Arc<AtomicUsize>,
}

impl Drop for MemoryGuard {
    fn drop(&mut self) {
        self.monitor.fetch_sub(self.mb, Ordering::Relaxed);
    }
}
```

### Disk Space Management
```rust
// Cleanup strategy for edge environments
pub async fn cleanup_old_files(data_dir: &Path, max_age_days: u64) -> Result<()> {
    use std::time::{Duration, SystemTime};
    
    let cutoff = SystemTime::now() - Duration::from_secs(max_age_days * 24 * 3600);
    
    let mut entries = fs::read_dir(data_dir).await?;
    while let Some(entry) = entries.next_entry().await? {
        let metadata = entry.metadata().await?;
        if let Ok(modified) = metadata.modified() {
            if modified < cutoff {
                if metadata.is_file() {
                    fs::remove_file(entry.path()).await?;
                    println!("Cleaned up old file: {}", entry.path().display());
                }
            }
        }
    }
    
    Ok(())
}
```

## Deployment Scripts

### Systemd Service (scripts/tui-patcher-edge.service)
```ini
[Unit]
Description=TUI-Patcher Edge Runtime
After=network.target
Wants=network.target

[Service]
Type=simple
User=tui-patcher
Group=tui-patcher
WorkingDirectory=/opt/tui-patcher-edge
ExecStart=/usr/local/bin/tui-patcher-edge daemon --config /etc/tui-patcher-edge/config.toml
Restart=always
RestartSec=30
StandardOutput=journal
StandardError=journal

# Resource limits
MemoryMax=512M
CPUQuota=50%

# Security
NoNewPrivileges=true
PrivateTmp=true
ProtectHome=true
ProtectSystem=strict
ReadWritePaths=/opt/tui-patcher-edge/data

[Install]
WantedBy=multi-user.target
```

### Auto-update Script (scripts/update-edge.sh)
```bash
#!/bin/bash
# Auto-update script for edge deployments

set -euo pipefail

EDGE_DIR="/opt/tui-patcher-edge"
BACKUP_DIR="${EDGE_DIR}/backup"
BINARY_PATH="/usr/local/bin/tui-patcher-edge"
SERVICE_NAME="tui-patcher-edge"

echo "Starting TUI-Patcher Edge update..."

# Create backup
mkdir -p "$BACKUP_DIR"
if [[ -f "$BINARY_PATH" ]]; then
    cp "$BINARY_PATH" "$BACKUP_DIR/tui-patcher-edge.$(date +%Y%m%d_%H%M%S)"
fi

# Download latest version
echo "Downloading latest edge binary..."
wget -q "https://releases.tui-patcher.com/latest/tui-patcher-edge-$(uname -m)" \
     -O "$BINARY_PATH.new"

# Verify download
if [[ ! -f "$BINARY_PATH.new" ]]; then
    echo "Failed to download new binary"
    exit 1
fi

chmod +x "$BINARY_PATH.new"

# Stop service
echo "Stopping service..."
sudo systemctl stop "$SERVICE_NAME"

# Replace binary
mv "$BINARY_PATH.new" "$BINARY_PATH"

# Start service
echo "Starting service..."
sudo systemctl start "$SERVICE_NAME"

# Verify service is running
sleep 5
if sudo systemctl is-active "$SERVICE_NAME" >/dev/null; then
    echo "Update completed successfully"
else
    echo "Service failed to start, rolling back..."
    # Rollback logic would go here
    exit 1
fi
```

## Troubleshooting

### Common Issues

#### 1. Memory Constraints
```bash
# Check memory usage
cat /proc/meminfo
ps aux --sort=-rss | head -10

# Reduce memory limits in config
[processing]
max_concurrent_jobs = 1
max_memory_mb = 256
```

#### 2. Storage Space
```bash
# Check disk usage
df -h
du -sh /opt/tui-patcher-edge/*

# Clean up old files
tui-patcher-edge cleanup --older-than 7d
```

#### 3. Missing Dependencies
```bash
# Install apktool on Termux
pkg install apktool

# Install on Raspberry Pi
sudo apt-get install apktool android-tools-adb
```

### Monitoring Edge Deployment
```bash
# Check service status
systemctl status tui-patcher-edge

# View logs
journalctl -u tui-patcher-edge -f

# Check configuration
tui-patcher-edge --config /etc/tui-patcher-edge/config.toml validate
```

This edge deployment guide provides a complete framework for running TUI-Patcher-Agent in resource-constrained environments while maintaining core functionality and reliability.
"""
}

# Create the directory structure
print("Creating TUI-Patcher-Agent project structure...")

for file_path, content in project_structure.items():
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)

print(f"✅ Created {len(project_structure)} main documentation files")
print("\nMain files created:")
for file_path in project_structure.keys():
    print(f"  - {file_path}")