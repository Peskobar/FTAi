# Create additional source files and CI/CD components
additional_files = {}

# Patch engine implementation
additional_files["src/patch/mod.rs"] = '''//! Core patching engine for Android APK/AAB files

use anyhow::Result;
use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};
use std::process::Command;
use tokio::fs;
use tracing::{info, warn, instrument};

use crate::queue::{PatchRequest, PatchResult, PatchType, AiAnalysisResult, RiskLevel};

/// Main patch engine for processing Android applications
#[derive(Clone)]
pub struct PatchEngine {
    temp_dir: PathBuf,
    tools_path: PathBuf,
}

impl PatchEngine {
    pub fn new() -> Self {
        Self {
            temp_dir: PathBuf::from("/tmp/tui-patcher"),
            tools_path: PathBuf::from("/opt/android-tools"),
        }
    }
    
    #[instrument(skip(self))]
    pub async fn process_apk(&self, request: &PatchRequest) -> Result<PatchResult> {
        info!(apk_path = %request.apk_path, patch_type = ?request.patch_type, "Starting APK processing");
        
        // Create working directory
        let work_dir = self.temp_dir.join(uuid::Uuid::new_v4().to_string());
        fs::create_dir_all(&work_dir).await?;
        
        // Extract APK
        let extract_dir = work_dir.join("extracted");
        self.extract_apk(&request.apk_path, &extract_dir).await?;
        
        // Analyze APK structure
        let analysis = self.analyze_apk(&extract_dir).await?;
        
        // Apply patches based on type
        let applied_patches = match request.patch_type {
            PatchType::Security => self.apply_security_patches(&extract_dir).await?,
            PatchType::Performance => self.apply_performance_patches(&extract_dir).await?,
            PatchType::Feature => self.apply_feature_patches(&extract_dir).await?,
            PatchType::Compatibility => self.apply_compatibility_patches(&extract_dir).await?,
            PatchType::Custom(ref name) => self.apply_custom_patches(&extract_dir, name).await?,
        };
        
        // Rebuild APK
        let output_path = work_dir.join("patched.apk");
        self.rebuild_apk(&extract_dir, &output_path).await?;
        
        // AI analysis (if enabled)
        let ai_analysis = if request.options.enable_ai_analysis {
            Some(self.perform_ai_analysis(&extract_dir, &applied_patches).await?)
        } else {
            None
        };
        
        // Cleanup working directory
        fs::remove_dir_all(&work_dir).await.ok();
        
        Ok(PatchResult {
            output_path: output_path.to_string_lossy().to_string(),
            patch_summary: format!("Applied {} patches successfully", applied_patches.len()),
            applied_patches,
            warnings: vec![],
            ai_analysis,
        })
    }
    
    async fn extract_apk(&self, apk_path: &str, extract_dir: &Path) -> Result<()> {
        let output = Command::new("apktool")
            .args(&["d", apk_path, "-o", extract_dir.to_str().unwrap(), "-f"])
            .output()?;
        
        if !output.status.success() {
            return Err(anyhow::anyhow!("Failed to extract APK: {}", 
                String::from_utf8_lossy(&output.stderr)));
        }
        
        Ok(())
    }
    
    async fn rebuild_apk(&self, extract_dir: &Path, output_path: &Path) -> Result<()> {
        let output = Command::new("apktool")
            .args(&["b", extract_dir.to_str().unwrap(), "-o", output_path.to_str().unwrap()])
            .output()?;
        
        if !output.status.success() {
            return Err(anyhow::anyhow!("Failed to rebuild APK: {}", 
                String::from_utf8_lossy(&output.stderr)));
        }
        
        Ok(())
    }
    
    async fn analyze_apk(&self, extract_dir: &Path) -> Result<ApkAnalysis> {
        let manifest_path = extract_dir.join("AndroidManifest.xml");
        
        // Basic analysis - in real implementation would be more comprehensive
        Ok(ApkAnalysis {
            package_name: "com.example.app".to_string(),
            version_code: 1,
            version_name: "1.0".to_string(),
            target_sdk: 30,
            permissions: vec!["android.permission.INTERNET".to_string()],
            activities: vec!["MainActivity".to_string()],
        })
    }
    
    async fn apply_security_patches(&self, extract_dir: &Path) -> Result<Vec<String>> {
        let mut patches = Vec::new();
        
        // Remove debug information
        self.remove_debug_info(extract_dir).await?;
        patches.push("Removed debug information".to_string());
        
        // Update network security config
        self.update_network_security(extract_dir).await?;
        patches.push("Updated network security configuration".to_string());
        
        // Obfuscate resources
        self.obfuscate_resources(extract_dir).await?;
        patches.push("Obfuscated sensitive resources".to_string());
        
        Ok(patches)
    }
    
    async fn apply_performance_patches(&self, extract_dir: &Path) -> Result<Vec<String>> {
        let mut patches = Vec::new();
        
        // Optimize images
        self.optimize_images(extract_dir).await?;
        patches.push("Optimized image resources".to_string());
        
        // Compress resources
        self.compress_resources(extract_dir).await?;
        patches.push("Compressed application resources".to_string());
        
        // Remove unused resources
        self.remove_unused_resources(extract_dir).await?;
        patches.push("Removed unused resources".to_string());
        
        Ok(patches)
    }
    
    async fn apply_feature_patches(&self, extract_dir: &Path) -> Result<Vec<String>> {
        let mut patches = Vec::new();
        
        // Add feature flags
        self.add_feature_flags(extract_dir).await?;
        patches.push("Added feature flag support".to_string());
        
        // Update UI components
        self.update_ui_components(extract_dir).await?;
        patches.push("Updated UI components".to_string());
        
        Ok(patches)
    }
    
    async fn apply_compatibility_patches(&self, extract_dir: &Path) -> Result<Vec<String>> {
        let mut patches = Vec::new();
        
        // Update API compatibility
        self.update_api_compatibility(extract_dir).await?;
        patches.push("Updated API compatibility".to_string());
        
        // Fix deprecated methods
        self.fix_deprecated_methods(extract_dir).await?;
        patches.push("Fixed deprecated method calls".to_string());
        
        Ok(patches)
    }
    
    async fn apply_custom_patches(&self, extract_dir: &Path, patch_name: &str) -> Result<Vec<String>> {
        // Load custom patch from plugins
        info!(patch_name = %patch_name, "Applying custom patch");
        
        // This would integrate with the WASM plugin system (H1 2026)
        Ok(vec![format!("Applied custom patch: {}", patch_name)])
    }
    
    async fn perform_ai_analysis(&self, extract_dir: &Path, patches: &[String]) -> Result<AiAnalysisResult> {
        // This would integrate with Perplexity AI (H1 2026)
        // For now, return mock analysis
        
        Ok(AiAnalysisResult {
            recommendations: vec![
                "Consider updating target SDK to latest version".to_string(),
                "Add ProGuard configuration for better obfuscation".to_string(),
                "Implement certificate pinning for network security".to_string(),
            ],
            risk_assessment: RiskLevel::Low,
            confidence_score: 0.85,
        })
    }
    
    // Patch implementation methods (simplified)
    async fn remove_debug_info(&self, _extract_dir: &Path) -> Result<()> { Ok(()) }
    async fn update_network_security(&self, _extract_dir: &Path) -> Result<()> { Ok(()) }
    async fn obfuscate_resources(&self, _extract_dir: &Path) -> Result<()> { Ok(()) }
    async fn optimize_images(&self, _extract_dir: &Path) -> Result<()> { Ok(()) }
    async fn compress_resources(&self, _extract_dir: &Path) -> Result<()> { Ok(()) }
    async fn remove_unused_resources(&self, _extract_dir: &Path) -> Result<()> { Ok(()) }
    async fn add_feature_flags(&self, _extract_dir: &Path) -> Result<()> { Ok(()) }
    async fn update_ui_components(&self, _extract_dir: &Path) -> Result<()> { Ok(()) }
    async fn update_api_compatibility(&self, _extract_dir: &Path) -> Result<()> { Ok(()) }
    async fn fix_deprecated_methods(&self, _extract_dir: &Path) -> Result<()> { Ok(()) }
}

#[derive(Debug, Serialize, Deserialize)]
struct ApkAnalysis {
    package_name: String,
    version_code: u32,
    version_name: String,
    target_sdk: u32,
    permissions: Vec<String>,
    activities: Vec<String>,
}
'''

# Notifications module (Slack integration)
additional_files["src/notifications/mod.rs"] = '''//! Notification services for TUI-Patcher-Agent
//! Q3 2025 Sprint: Slack alert integration

use anyhow::Result;
use serde::{Deserialize, Serialize};
use slack_hook::{Slack, PayloadBuilder};
use tracing::{error, info, instrument};

pub mod slack;

#[derive(Debug, Clone)]
pub struct NotificationService {
    slack_client: Option<SlackClient>,
}

impl NotificationService {
    pub fn new(webhook_url: Option<String>) -> Self {
        let slack_client = webhook_url.map(|url| SlackClient::new(url));
        
        Self { slack_client }
    }
    
    #[instrument(skip(self))]
    pub async fn send_alert(&self, alert: Alert) -> Result<()> {
        info!(alert_type = ?alert.alert_type, message = %alert.message, "Sending alert");
        
        if let Some(ref slack) = self.slack_client {
            slack.send_alert(&alert).await?;
        }
        
        // Could add other notification channels here (email, webhook, etc.)
        
        Ok(())
    }
    
    #[instrument(skip(self))]
    pub async fn send_notification(&self, notification: Notification) -> Result<()> {
        info!(title = %notification.title, "Sending notification");
        
        if let Some(ref slack) = self.slack_client {
            slack.send_notification(&notification).await?;
        }
        
        Ok(())
    }
}

#[derive(Debug, Clone)]
struct SlackClient {
    webhook_url: String,
}

impl SlackClient {
    fn new(webhook_url: String) -> Self {
        Self { webhook_url }
    }
    
    async fn send_alert(&self, alert: &Alert) -> Result<()> {
        let slack = Slack::new(&self.webhook_url)?;
        
        let color = match alert.severity {
            AlertSeverity::Critical => "danger",
            AlertSeverity::Warning => "warning",
            AlertSeverity::Info => "good",
        };
        
        let payload = PayloadBuilder::new()
            .channel("#alerts")
            .username("TUI-Patcher Bot")
            .icon_emoji(":warning:")
            .text(&format!("🚨 TUI-Patcher Alert: {}", alert.message))
            .attachments(vec![
                slack_hook::AttachmentBuilder::new()
                    .color(color)
                    .title(&format!("{:?} Alert", alert.alert_type))
                    .text(&alert.message)
                    .field(slack_hook::Field::new("Severity", &format!("{:?}", alert.severity), true))
                    .field(slack_hook::Field::new("Timestamp", &alert.timestamp.to_rfc3339(), true))
                    .field(slack_hook::Field::new("Value", &alert.current_value.to_string(), true))
                    .field(slack_hook::Field::new("Threshold", &alert.threshold.to_string(), true))
                    .build()?
            ])
            .build()?;
        
        tokio::task::spawn_blocking(move || slack.send(&payload))
            .await??;
        
        Ok(())
    }
    
    async fn send_notification(&self, notification: &Notification) -> Result<()> {
        let slack = Slack::new(&self.webhook_url)?;
        
        let payload = PayloadBuilder::new()
            .channel("#general")
            .username("TUI-Patcher Bot")
            .icon_emoji(":information_source:")
            .text(&notification.title)
            .attachments(vec![
                slack_hook::AttachmentBuilder::new()
                    .color("good")
                    .title(&notification.title)
                    .text(&notification.message)
                    .field(slack_hook::Field::new("Timestamp", &notification.timestamp.to_rfc3339(), true))
                    .build()?
            ])
            .build()?;
        
        tokio::task::spawn_blocking(move || slack.send(&payload))
            .await??;
        
        Ok(())
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Alert {
    pub alert_type: AlertType,
    pub severity: AlertSeverity,
    pub message: String,
    pub current_value: f64,
    pub threshold: f64,
    pub timestamp: chrono::DateTime<chrono::Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum AlertType {
    QueueSize,
    SuccessRate,
    Latency,
    ErrorRate,
    SystemHealth,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum AlertSeverity {
    Info,
    Warning,
    Critical,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Notification {
    pub title: String,
    pub message: String,
    pub timestamp: chrono::DateTime<chrono::Utc>,
}
'''

# Alerts module
additional_files["src/alerts/mod.rs"] = '''//! Alert system for TUI-Patcher-Agent
//! Q3 2025 Sprint: Automated alerting with configurable rules

use anyhow::Result;
use std::time::Duration;
use tokio::time::interval;
use tracing::{error, info, instrument, warn};

use crate::config::AlertConfig;
use crate::notifications::{Alert, AlertSeverity, AlertType, NotificationService};
use crate::queue::QueueManager;

pub mod rules;

use rules::AlertRule;

/// Alert service that monitors system metrics and sends notifications
pub struct AlertService {
    config: AlertConfig,
    notification_service: NotificationService,
    rules: Vec<AlertRule>,
    last_alert_times: std::collections::HashMap<String, chrono::DateTime<chrono::Utc>>,
}

impl AlertService {
    pub async fn new(config: AlertConfig) -> Result<Self> {
        let notification_service = NotificationService::new(config.slack_webhook_url.clone());
        
        let rules = vec![
            AlertRule::queue_size_threshold(config.queue_size_threshold),
            AlertRule::success_rate_threshold(config.success_rate_threshold),
            AlertRule::latency_threshold(config.latency_threshold_ms),
        ];
        
        Ok(Self {
            config,
            notification_service,
            rules,
            last_alert_times: std::collections::HashMap::new(),
        })
    }
    
    #[instrument(skip(self))]
    pub async fn run(&mut self) {
        if !self.config.enabled {
            info!("Alert service disabled");
            return;
        }
        
        info!("Starting alert service");
        let mut check_interval = interval(Duration::from_secs(30));
        
        loop {
            check_interval.tick().await;
            
            if let Err(e) = self.check_alerts().await {
                error!(error = %e, "Error checking alerts");
            }
        }
    }
    
    async fn check_alerts(&mut self) -> Result<()> {
        // Get current metrics
        let metrics = self.collect_current_metrics().await?;
        
        // Check each rule
        for rule in &self.rules {
            if let Some(alert) = rule.evaluate(&metrics) {
                if self.should_send_alert(&alert) {
                    if let Err(e) = self.notification_service.send_alert(alert.clone()).await {
                        error!(error = %e, alert_type = ?alert.alert_type, "Failed to send alert");
                    } else {
                        self.last_alert_times.insert(
                            format!("{:?}", alert.alert_type),
                            chrono::Utc::now(),
                        );
                        info!(alert_type = ?alert.alert_type, "Alert sent successfully");
                    }
                }
            }
        }
        
        Ok(())
    }
    
    async fn collect_current_metrics(&self) -> Result<SystemMetrics> {
        // In a real implementation, this would collect metrics from:
        // - Queue manager
        // - Prometheus metrics
        // - System resources
        // - Application health checks
        
        // Mock metrics for now
        Ok(SystemMetrics {
            queue_size: 8,
            success_rate: 0.96,
            avg_latency_ms: 1800,
            error_rate: 0.04,
            cpu_usage: 0.65,
            memory_usage: 0.80,
        })
    }
    
    fn should_send_alert(&self, alert: &Alert) -> bool {
        let alert_key = format!("{:?}", alert.alert_type);
        
        // Rate limiting: don't send the same alert type more than once every 5 minutes
        if let Some(last_time) = self.last_alert_times.get(&alert_key) {
            let time_since_last = chrono::Utc::now() - *last_time;
            if time_since_last < chrono::Duration::minutes(5) {
                return false;
            }
        }
        
        true
    }
}

#[derive(Debug, Clone)]
pub struct SystemMetrics {
    pub queue_size: u32,
    pub success_rate: f64,
    pub avg_latency_ms: u64,
    pub error_rate: f64,
    pub cpu_usage: f64,
    pub memory_usage: f64,
}
'''

# Routes implementations
additional_files["src/routes/health.rs"] = '''//! Health check endpoints

use axum::{response::Json, http::StatusCode};
use serde_json::{json, Value};

/// Basic health check endpoint
pub async fn health_check() -> Json<Value> {
    Json(json!({
        "status": "healthy",
        "timestamp": chrono::Utc::now().to_rfc3339(),
        "version": crate::VERSION,
        "service": "tui-patcher-agent"
    }))
}

/// Readiness check endpoint
pub async fn readiness_check() -> Result<Json<Value>, StatusCode> {
    // Check if all dependencies are ready
    // - Database connections
    // - External services
    // - Queue system
    
    // For now, always return ready
    Ok(Json(json!({
        "status": "ready",
        "timestamp": chrono::Utc::now().to_rfc3339(),
        "checks": {
            "queue": "healthy",
            "storage": "healthy",
            "external_apis": "healthy"
        }
    })))
}
'''

# SBOM endpoint (Q3 2025 Sprint)
additional_files["src/routes/sbom.rs"] = '''//! Software Bill of Materials (SBOM) endpoint
//! Q3 2025 Sprint: SBOM compliance implementation

use axum::{
    response::{Json, Response},
    http::{header, StatusCode},
};
use serde_json::{json, Value};
use std::fs;

/// SBOM endpoint for supply chain compliance
pub async fn sbom_handler() -> Result<Response, StatusCode> {
    // Try to read the SBOM file generated during build
    match fs::read_to_string("cyclonedx.json") {
        Ok(sbom_content) => {
            // Parse and return the SBOM JSON
            match serde_json::from_str::<Value>(&sbom_content) {
                Ok(sbom_json) => {
                    Ok(Response::builder()
                        .status(StatusCode::OK)
                        .header(header::CONTENT_TYPE, "application/json")
                        .header(header::CONTENT_DISPOSITION, "attachment; filename=\"sbom.json\"")
                        .header("X-SBOM-Format", "CycloneDX")
                        .header("X-SBOM-Version", "1.5")
                        .body(sbom_content.into())
                        .unwrap())
                }
                Err(_) => {
                    // Return error if SBOM is malformed
                    Ok(Response::builder()
                        .status(StatusCode::INTERNAL_SERVER_ERROR)
                        .header(header::CONTENT_TYPE, "application/json")
                        .body(json!({
                            "error": "SBOM file is malformed",
                            "timestamp": chrono::Utc::now().to_rfc3339()
                        }).to_string().into())
                        .unwrap())
                }
            }
        }
        Err(_) => {
            // Return placeholder SBOM if file doesn't exist
            let placeholder_sbom = json!({
                "bomFormat": "CycloneDX",
                "specVersion": "1.5",
                "serialNumber": format!("urn:uuid:{}", uuid::Uuid::new_v4()),
                "version": 1,
                "metadata": {
                    "timestamp": chrono::Utc::now().to_rfc3339(),
                    "tools": [
                        {
                            "vendor": "TUI-Patcher",
                            "name": "tui-patcher-agent",
                            "version": crate::VERSION
                        }
                    ],
                    "component": {
                        "type": "application",
                        "bom-ref": "tui-patcher-agent",
                        "name": "tui-patcher-agent",
                        "version": crate::VERSION,
                        "description": "AI-powered Android patching service"
                    }
                },
                "components": [
                    {
                        "type": "library",
                        "bom-ref": "axum",
                        "name": "axum",
                        "version": "0.7.0",
                        "scope": "required"
                    },
                    {
                        "type": "library", 
                        "bom-ref": "tokio",
                        "name": "tokio",
                        "version": "1.35.0",
                        "scope": "required"
                    },
                    {
                        "type": "library",
                        "bom-ref": "opentelemetry",
                        "name": "opentelemetry", 
                        "version": "0.23.0",
                        "scope": "required"
                    }
                ]
            });
            
            Ok(Response::builder()
                .status(StatusCode::OK)
                .header(header::CONTENT_TYPE, "application/json")
                .header("X-SBOM-Format", "CycloneDX")
                .header("X-SBOM-Version", "1.5")
                .header("X-SBOM-Generated", "runtime")
                .body(placeholder_sbom.to_string().into())
                .unwrap())
        }
    }
}
'''

# CI/CD workflows
additional_files[".github/workflows/ci.yml"] = '''name: CI/CD Pipeline

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main ]

env:
  CARGO_TERM_COLOR: always
  RUST_BACKTRACE: 1

jobs:
  test:
    name: Test Suite
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v4
    
    - name: Install Rust
      uses: dtolnay/rust-toolchain@stable
      with:
        components: rustfmt, clippy
    
    - name: Cache dependencies
      uses: actions/cache@v3
      with:
        path: ~/.cargo
        key: ${{ runner.os }}-cargo-${{ hashFiles('**/Cargo.lock') }}
    
    - name: Check formatting
      run: cargo fmt -- --check
    
    - name: Run clippy
      run: cargo clippy -- -D warnings
    
    - name: Run tests
      run: cargo test --verbose

  security:
    name: Security Audit
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v4
    
    - name: Install Rust
      uses: dtolnay/rust-toolchain@stable
    
    - name: Install cargo-audit
      run: cargo install cargo-audit
    
    - name: Run security audit
      run: cargo audit

  sbom:
    name: Generate SBOM
    runs-on: ubuntu-latest
    needs: [test, security]
    steps:
    - uses: actions/checkout@v4
    
    - name: Install Rust
      uses: dtolnay/rust-toolchain@stable
    
    - name: Install cargo-cyclonedx
      run: cargo install cargo-cyclonedx
    
    - name: Generate SBOM
      run: cargo cyclonedx --format json --output cyclonedx.json
    
    - name: Upload SBOM
      uses: actions/upload-artifact@v3
      with:
        name: sbom
        path: cyclonedx.json

  build:
    name: Build and Push
    runs-on: ubuntu-latest
    needs: [test, security, sbom]
    if: github.ref == 'refs/heads/main'
    permissions:
      contents: read
      packages: write
      attestations: write
      id-token: write
    
    steps:
    - uses: actions/checkout@v4
    
    - name: Install Rust
      uses: dtolnay/rust-toolchain@stable
    
    - name: Build binary
      run: cargo build --release
    
    - name: Set up Docker Buildx
      uses: docker/setup-buildx-action@v3
    
    - name: Log in to GitHub Container Registry
      uses: docker/login-action@v3
      with:
        registry: ghcr.io
        username: ${{ github.actor }}
        password: ${{ secrets.GITHUB_TOKEN }}
    
    - name: Extract metadata
      id: meta
      uses: docker/metadata-action@v5
      with:
        images: ghcr.io/${{ github.repository }}
        tags: |
          type=ref,event=branch
          type=ref,event=pr
          type=sha,prefix={{branch}}-
          type=raw,value=latest,enable={{is_default_branch}}
    
    - name: Build and push Docker image
      uses: docker/build-push-action@v5
      with:
        context: .
        push: true
        tags: ${{ steps.meta.outputs.tags }}
        labels: ${{ steps.meta.outputs.labels }}
        cache-from: type=gha
        cache-to: type=gha,mode=max
    
    - name: Generate SLSA attestation
      uses: actions/attest-build-provenance@v1
      with:
        subject-name: ghcr.io/${{ github.repository }}
        subject-digest: ${{ steps.build.outputs.digest }}
        push-to-registry: true

  deploy:
    name: Deploy to Kubernetes
    runs-on: ubuntu-latest
    needs: build
    if: github.ref == 'refs/heads/main'
    environment: production
    
    steps:
    - uses: actions/checkout@v4
    
    - name: Configure kubectl
      uses: azure/k8s-set-context@v3
      with:
        method: kubeconfig
        kubeconfig: ${{ secrets.KUBECONFIG }}
    
    - name: Deploy with Helm
      run: |
        helm upgrade --install tui-patcher-agent ./helm/tui-patcher-agent \\
          --namespace tui-patcher \\
          --create-namespace \\
          --set image.tag=${{ github.sha }} \\
          --set image.repository=ghcr.io/${{ github.repository }} \\
          --wait
'''

# Kubernetes manifests
additional_files["k8s/deployment.yaml"] = '''apiVersion: apps/v1
kind: Deployment
metadata:
  name: tui-patcher-agent
  namespace: tui-patcher
  labels:
    app: tui-patcher-agent
    version: v0.3.0
spec:
  replicas: 3
  selector:
    matchLabels:
      app: tui-patcher-agent
  template:
    metadata:
      labels:
        app: tui-patcher-agent
        version: v0.3.0
      annotations:
        prometheus.io/scrape: "true"
        prometheus.io/port: "8080"
        prometheus.io/path: "/metrics"
    spec:
      containers:
      - name: tui-patcher-agent
        image: ghcr.io/tui-patcher/tui-patcher-agent:latest
        ports:
        - containerPort: 8080
          name: http
        env:
        - name: SERVER_HOST
          value: "0.0.0.0"
        - name: SERVER_PORT
          value: "8080"
        - name: OTEL_EXPORTER_OTLP_ENDPOINT
          value: "http://otel-collector:4317"
        - name: OTEL_SERVICE_NAME
          value: "tui-patcher-agent"
        - name: SLACK_WEBHOOK_URL
          valueFrom:
            secretKeyRef:
              name: tui-patcher-secrets
              key: slack-webhook-url
        - name: PPX_API_KEY
          valueFrom:
            secretKeyRef:
              name: tui-patcher-secrets
              key: perplexity-api-key
        - name: PPX_API_KEY_CI
          valueFrom:
            secretKeyRef:
              name: tui-patcher-secrets
              key: perplexity-api-key-ci
        livenessProbe:
          httpGet:
            path: /health
            port: 8080
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /ready
            port: 8080
          initialDelaySeconds: 5
          periodSeconds: 5
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "512Mi"
            cpu: "500m"
        volumeMounts:
        - name: temp-storage
          mountPath: /tmp
        - name: sbom-volume
          mountPath: /app/sbom
          readOnly: true
      volumes:
      - name: temp-storage
        emptyDir: {}
      - name: sbom-volume
        configMap:
          name: sbom-config
          optional: true
---
apiVersion: v1
kind: Service
metadata:
  name: tui-patcher-agent
  namespace: tui-patcher
  labels:
    app: tui-patcher-agent
spec:
  selector:
    app: tui-patcher-agent
  ports:
  - name: http
    port: 80
    targetPort: 8080
  type: ClusterIP
---
apiVersion: v1
kind: Secret
metadata:
  name: tui-patcher-secrets
  namespace: tui-patcher
type: Opaque
stringData:
  slack-webhook-url: "https://hooks.slack.com/services/YOUR/SLACK/WEBHOOK"
  perplexity-api-key: "pplx-your-production-key"
  perplexity-api-key-ci: "pplx-your-ci-key"
'''

# Default configuration
additional_files["config.toml"] = '''# TUI-Patcher-Agent Configuration

[server]
host = "127.0.0.1"
port = 8080
workers = 4

[telemetry]
otel_endpoint = "http://localhost:4317"
service_name = "tui-patcher-agent"
sampling_ratio = 0.1
export_timeout_secs = 30

[auth]
require_api_key = false
api_keys = []

[rate_limit]
requests_per_minute = 100
burst_size = 20

[queue]
max_concurrent_jobs = 5
job_timeout_secs = 300
cleanup_interval_secs = 3600

[patch]
temp_dir = "/tmp/tui-patcher"
max_file_size_mb = 100
timeout_secs = 180

[alerts]
enabled = true
slack_webhook_url = ""  # Set via environment variable
queue_size_threshold = 10
success_rate_threshold = 0.95
latency_threshold_ms = 2000

[ai]
perplexity_api_key = ""  # Set via environment variable
perplexity_api_key_ci = ""  # Set via environment variable
enable_on_device = false
model_path = ""
'''

# Write additional files
for file_path, content in additional_files.items():
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)

print(f"✅ Created {len(additional_files)} additional files")
print("\nAdditional files created:")
for file_path in additional_files.keys():
    print(f"  - {file_path}")