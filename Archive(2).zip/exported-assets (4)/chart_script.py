import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
from datetime import datetime
import plotly.io as pio

# Load the data
data = [
  {
    "Task": "Q3 2025: Hardening & Visibility",
    "Start": "2025-07-01",
    "End": "2025-08-26", 
    "Duration": 56,
    "Phase": "Q3 2025",
    "Story_Points": 22,
    "Type": "Phase"
  },
  {
    "Task": "OTEL OTLP Integration",
    "Start": "2025-07-01",
    "End": "2025-07-15",
    "Duration": 14,
    "Phase": "Q3 2025", 
    "Story_Points": 8,
    "Type": "Task"
  },
  {
    "Task": "Traceparent Middleware", 
    "Start": "2025-07-16",
    "End": "2025-07-29",
    "Duration": 13,
    "Phase": "Q3 2025",
    "Story_Points": 5,
    "Type": "Task"
  },
  {
    "Task": "Slack Alert System",
    "Start": "2025-07-30", 
    "End": "2025-08-12",
    "Duration": 13,
    "Phase": "Q3 2025",
    "Story_Points": 3,
    "Type": "Task"
  },
  {
    "Task": "SBOM Pipeline",
    "Start": "2025-08-13",
    "End": "2025-08-26", 
    "Duration": 13,
    "Phase": "Q3 2025",
    "Story_Points": 6,
    "Type": "Task"
  },
  {
    "Task": "Q4 2025: Intelligent Patching",
    "Start": "2025-09-01",
    "End": "2025-12-16",
    "Duration": 106,
    "Phase": "Q4 2025",
    "Story_Points": 49,
    "Type": "Phase"
  },
  {
    "Task": "LSTM Autoscaler",
    "Start": "2025-09-01", 
    "End": "2025-09-23",
    "Duration": 22,
    "Phase": "Q4 2025",
    "Story_Points": 13,
    "Type": "Task"
  },
  {
    "Task": "On-device AI (TFLite)",
    "Start": "2025-09-24",
    "End": "2025-11-04",
    "Duration": 41,
    "Phase": "Q4 2025",
    "Story_Points": 21,
    "Type": "Task"
  },
  {
    "Task": "Self-healing Queue",
    "Start": "2025-11-05",
    "End": "2025-11-25", 
    "Duration": 20,
    "Phase": "Q4 2025",
    "Story_Points": 8,
    "Type": "Task"
  },
  {
    "Task": "Circuit Breaker",
    "Start": "2025-11-26",
    "End": "2025-12-16",
    "Duration": 20,
    "Phase": "Q4 2025", 
    "Story_Points": 7,
    "Type": "Task"
  },
  {
    "Task": "H1 2026: Ecosystem & Plugins",
    "Start": "2026-01-01",
    "End": "2026-04-28",
    "Duration": 118,
    "Phase": "H1 2026",
    "Story_Points": 55,
    "Type": "Phase"
  },
  {
    "Task": "Edge Runtime Build",
    "Start": "2026-01-01",
    "End": "2026-01-20",
    "Duration": 19,
    "Phase": "H1 2026",
    "Story_Points": 15,
    "Type": "Task"
  },
  {
    "Task": "WASM Marketplace", 
    "Start": "2026-01-21",
    "End": "2026-03-03",
    "Duration": 41,
    "Phase": "H1 2026",
    "Story_Points": 18,
    "Type": "Task"
  },
  {
    "Task": "Perplexity AI Dev Assistant",
    "Start": "2026-03-04",
    "End": "2026-03-31",
    "Duration": 27,
    "Phase": "H1 2026",
    "Story_Points": 12,
    "Type": "Task"
  },
  {
    "Task": "Final Integration",
    "Start": "2026-04-01", 
    "End": "2026-04-28",
    "Duration": 27,
    "Phase": "H1 2026",
    "Story_Points": 10,
    "Type": "Task"
  }
]

# Convert to DataFrame
df = pd.DataFrame(data)

# Convert dates
df['Start'] = pd.to_datetime(df['Start'])
df['End'] = pd.to_datetime(df['End'])

# Create abbreviated task names for display (15 char limit)
def abbreviate_task(task):
    if len(task) <= 15:
        return task
    # Special abbreviations for better readability
    abbrev = {
        'Q3 2025: Hardening & Visibility': 'Q3: Hardening',
        'Q4 2025: Intelligent Patching': 'Q4: Intel Patch', 
        'H1 2026: Ecosystem & Plugins': 'H1: Ecosystem',
        'OTEL OTLP Integration': 'OTEL OTLP',
        'Traceparent Middleware': 'Traceparent MW',
        'Slack Alert System': 'Slack Alerts',
        'On-device AI (TFLite)': 'On-device AI',
        'Self-healing Queue': 'Self-heal Queue',
        'Edge Runtime Build': 'Edge Runtime',
        'Perplexity AI Dev Assistant': 'Perplexity AI',
        'Final Integration': 'Final Integr'
    }
    return abbrev.get(task, task[:15])

df['Task_Short'] = df['Task'].apply(abbreviate_task)

# Define colors for each phase
phase_colors = {
    'Q3 2025': '#1FB8CD',  # Strong cyan (blue)
    'Q4 2025': '#FFC185',  # Light orange  
    'H1 2026': '#ECEBD5'   # Light green
}

# Create the Gantt chart using timeline
fig = px.timeline(df, 
                 x_start="Start", 
                 x_end="End", 
                 y="Task_Short",
                 color="Phase",
                 color_discrete_map=phase_colors,
                 title="TUI-Patcher Roadmap 2025-26")

# Update traces to add story points as text and set cliponaxis
for i, trace in enumerate(fig.data):
    phase_data = df[df['Phase'] == trace.name]
    # Add story points as text on bars
    trace.texttemplate = "%{customdata}SP"
    trace.textposition = "inside"
    trace.customdata = phase_data['Story_Points'].values
    trace.cliponaxis = False

# Add milestone markers at end of each phase
milestones = [
    ('2025-08-26', 'Q3 End'),
    ('2025-12-16', 'Q4 End'), 
    ('2026-04-28', 'H1 End')
]

for date, label in milestones:
    fig.add_vline(x=date, line_dash="dash", line_color="red", opacity=0.7)

# Update layout
fig.update_layout(
    title="TUI-Patcher Roadmap 2025-26",
    xaxis_title="Timeline",
    yaxis_title="Tasks",
    legend=dict(orientation='h', yanchor='bottom', y=1.05, xanchor='center', x=0.5),
    showlegend=True
)

# Update x-axis to show months
fig.update_xaxes(
    tickformat="%b %Y",
    dtick="M1"
)

# Save the chart
fig.write_image("gantt_chart.png")