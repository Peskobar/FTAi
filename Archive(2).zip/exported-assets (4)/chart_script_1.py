import plotly.graph_objects as go
from plotly.subplots import make_subplots
import json

# Parse the provided data
data = [
  {
    "component": "API Gateway",
    "type": "current",
    "layer": "core",
    "x": 1,
    "y": 2,
    "connections": ["Queue Manager", "Prometheus Metrics"]
  },
  {
    "component": "Queue Manager", 
    "type": "current",
    "layer": "core",
    "x": 2,
    "y": 2,
    "connections": ["Patching Engine"]
  },
  {
    "component": "Patching Engine",
    "type": "current", 
    "layer": "core",
    "x": 3,
    "y": 2,
    "connections": ["File Storage"]
  },
  {
    "component": "Prometheus Metrics",
    "type": "current",
    "layer": "infrastructure", 
    "x": 1,
    "y": 1,
    "connections": []
  },
  {
    "component": "File Storage",
    "type": "current",
    "layer": "infrastructure",
    "x": 3,
    "y": 1,
    "connections": []
  },
  {
    "component": "Edge Runtime",
    "type": "new",
    "layer": "edge",
    "x": 1,
    "y": 3,
    "connections": ["API Gateway Enhanced"]
  },
  {
    "component": "Perplexity AI",
    "type": "new", 
    "layer": "edge",
    "x": 2,
    "y": 3,
    "connections": ["API Gateway Enhanced"]
  },
  {
    "component": "WASM Marketplace",
    "type": "new",
    "layer": "edge", 
    "x": 3,
    "y": 3,
    "connections": ["API Gateway Enhanced"]
  },
  {
    "component": "API Gateway Enhanced",
    "type": "enhanced",
    "layer": "core",
    "x": 1,
    "y": 2,
    "connections": ["LSTM Autoscaler", "Circuit Breaker", "OTEL Collector"]
  },
  {
    "component": "LSTM Autoscaler",
    "type": "new",
    "layer": "core",
    "x": 2,
    "y": 2,
    "connections": ["Self-healing Queue"]
  },
  {
    "component": "Circuit Breaker",
    "type": "new",
    "layer": "core", 
    "x": 3,
    "y": 2,
    "connections": ["Self-healing Queue"]
  },
  {
    "component": "Self-healing Queue",
    "type": "enhanced",
    "layer": "core",
    "x": 4,
    "y": 2,
    "connections": ["On-device AI"]
  },
  {
    "component": "On-device AI",
    "type": "new",
    "layer": "core",
    "x": 5,
    "y": 2,
    "connections": ["Kubernetes"]
  },
  {
    "component": "OTEL Collector",
    "type": "new",
    "layer": "infrastructure",
    "x": 1,
    "y": 1,
    "connections": []
  },
  {
    "component": "SBOM Generator", 
    "type": "new",
    "layer": "infrastructure",
    "x": 2,
    "y": 1,
    "connections": []
  },
  {
    "component": "SLSA L3 Compliance",
    "type": "new",
    "layer": "infrastructure",
    "x": 3,
    "y": 1,
    "connections": []
  },
  {
    "component": "Kubernetes",
    "type": "enhanced",
    "layer": "infrastructure", 
    "x": 4,
    "y": 1,
    "connections": []
  }
]

# Color mapping
colors = {
    'current': '#5D878F',  # Cyan (basic blue)
    'new': '#ECEBD5',      # Light green 
    'enhanced': '#FFC185'   # Light orange
}

# Create subplots
fig = make_subplots(
    rows=1, cols=2,
    subplot_titles=['Current: v0.3.0', 'Target: v1.0'],
    horizontal_spacing=0.15
)

# Filter current components for left subplot
current_components = [comp for comp in data if comp['type'] == 'current']

# Add current architecture components (left)
for comp in current_components:
    # Abbreviate component names to fit 15 char limit
    name_map = {
        'API Gateway': 'API Gateway',
        'Queue Manager': 'Queue Mgr',
        'Patching Engine': 'Patch Engine',
        'Prometheus Metrics': 'Prometheus',
        'File Storage': 'File Store'
    }
    display_name = name_map.get(comp['component'], comp['component'])
    
    fig.add_trace(
        go.Scatter(
            x=[comp['x']],
            y=[comp['y']],
            mode='markers+text',
            marker=dict(size=40, color=colors[comp['type']], line=dict(width=2, color='white')),
            text=display_name,
            textposition='middle center',
            textfont=dict(size=8, color='black'),
            showlegend=False,
            hoverinfo='skip',
            cliponaxis=False
        ),
        row=1, col=1
    )

# Add target architecture components (right)
target_components = data.copy()
legend_added = {'current': False, 'new': False, 'enhanced': False}

for i, comp in enumerate(target_components):
    # Abbreviate component names
    name_map = {
        'API Gateway': 'API Gateway',
        'Queue Manager': 'Queue Mgr', 
        'Patching Engine': 'Patch Engine',
        'Edge Runtime': 'Edge Runtime',
        'Perplexity AI': 'Perplexity',
        'WASM Marketplace': 'WASM Market',
        'API Gateway Enhanced': 'API Gateway+',
        'LSTM Autoscaler': 'LSTM Scale',
        'Circuit Breaker': 'Circuit Break',
        'Self-healing Queue': 'Self-heal Q',
        'On-device AI': 'On-device AI',
        'OTEL Collector': 'OTEL Collect',
        'SBOM Generator': 'SBOM Gen',
        'SLSA L3 Compliance': 'SLSA L3',
        'Kubernetes': 'Kubernetes'
    }
    display_name = name_map.get(comp['component'], comp['component'][:12])
    
    # Show legend only for first occurrence of each type
    show_legend = False
    if not legend_added[comp['type']]:
        show_legend = True
        legend_added[comp['type']] = True
        
    legend_name = comp['type'].title()
    if comp['type'] == 'enhanced':
        legend_name = 'Enhanced'
        
    fig.add_trace(
        go.Scatter(
            x=[comp['x']],
            y=[comp['y']],
            mode='markers+text',
            marker=dict(size=35, color=colors[comp['type']], line=dict(width=2, color='white')),
            text=display_name,
            textposition='middle center',
            textfont=dict(size=7, color='black'),
            name=legend_name,
            showlegend=show_legend,
            hoverinfo='skip',
            cliponaxis=False
        ),
        row=1, col=2
    )

# Add connections for current architecture
comp_positions_current = {comp['component']: (comp['x'], comp['y']) for comp in current_components}
for comp in current_components:
    for connection in comp['connections']:
        if connection in comp_positions_current:
            x1, y1 = comp_positions_current[comp['component']]
            x2, y2 = comp_positions_current[connection]
            fig.add_trace(
                go.Scatter(
                    x=[x1, x2],
                    y=[y1, y2],
                    mode='lines',
                    line=dict(color='gray', width=1),
                    showlegend=False,
                    hoverinfo='skip',
                    cliponaxis=False
                ),
                row=1, col=1
            )

# Add connections for target architecture
comp_positions_target = {comp['component']: (comp['x'], comp['y']) for comp in target_components}
for comp in target_components:
    for connection in comp['connections']:
        if connection in comp_positions_target:
            x1, y1 = comp_positions_target[comp['component']]
            x2, y2 = comp_positions_target[connection]
            fig.add_trace(
                go.Scatter(
                    x=[x1, x2],
                    y=[y1, y2],
                    mode='lines',
                    line=dict(color='gray', width=1),
                    showlegend=False,
                    hoverinfo='skip',
                    cliponaxis=False
                ),
                row=1, col=2
            )

# Add performance metrics as annotations
fig.add_annotation(
    x=0.25, y=-0.1,
    text="95% success, 2.4s latency",
    showarrow=False,
    xref="paper", yref="paper",
    font=dict(size=10)
)

fig.add_annotation(
    x=0.75, y=-0.1, 
    text="≥99% success, ≤1.5s latency",
    showarrow=False,
    xref="paper", yref="paper",
    font=dict(size=10)
)

# Update layout
fig.update_layout(
    title="TUI-Patcher Architecture Evolution",
    showlegend=True,
    legend=dict(orientation='h', yanchor='bottom', y=1.05, xanchor='center', x=0.5)
)

# Update axes
fig.update_xaxes(showgrid=False, showticklabels=False, zeroline=False)
fig.update_yaxes(showgrid=False, showticklabels=False, zeroline=False, range=[0.5, 3.5])

# Set axis ranges to fit components properly
fig.update_xaxes(range=[0.5, 3.5], row=1, col=1)
fig.update_xaxes(range=[0.5, 5.5], row=1, col=2)

fig.write_image("architecture_evolution.png")