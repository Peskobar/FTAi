# Kubernetes Configuration Files

## Deployment Manifest

```yaml
# k8s/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: tui-patcher-agent-backend
  namespace: tui-patcher
  labels:
    app: tui-patcher-agent
    component: backend
    version: v1.0.0
spec:
  replicas: 3
  revisionHistoryLimit: 5
  selector:
    matchLabels:
      app: tui-patcher-agent
      component: backend
  template:
    metadata:
      labels:
        app: tui-patcher-agent
        component: backend
        version: v1.0.0
      annotations:
        prometheus.io/scrape: "true"
        prometheus.io/port: "8000"
        prometheus.io/path: "/api/v1/metrics"
    spec:
      serviceAccountName: tui-patcher-agent
      securityContext:
        runAsNonRoot: true
        runAsUser: 1001
        fsGroup: 1001
      containers:
      - name: backend
        image: tuipatcher/tui-patcher-agent:v1.0.0
        imagePullPolicy: Always
        ports:
        - name: http
          containerPort: 8000
          protocol: TCP
        env:
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: tui-patcher-secrets
              key: database-url
        - name: REDIS_URL
          valueFrom:
            secretKeyRef:
              name: tui-patcher-secrets
              key: redis-url
        - name: OTEL_EXPORTER_OTLP_ENDPOINT
          value: "http://otel-collector:4317"
        - name: OTEL_SERVICE_NAME
          value: "tui-patcher-agent"
        - name: OTEL_SERVICE_VERSION
          value: "v1.0.0"
        - name: RUST_LOG
          value: "info"
        - name: SLACK_WEBHOOK_URL
          valueFrom:
            secretKeyRef:
              name: tui-patcher-secrets
              key: slack-webhook-url
              optional: true
        - name: PPX_API_KEY
          valueFrom:
            secretKeyRef:
              name: tui-patcher-secrets
              key: perplexity-api-key
              optional: true
        - name: PPX_API_KEY_CI
          valueFrom:
            secretKeyRef:
              name: tui-patcher-secrets
              key: perplexity-api-key-ci
              optional: true
        resources:
          requests:
            memory: "512Mi"
            cpu: "250m"
          limits:
            memory: "2Gi"
            cpu: "1000m"
        volumeMounts:
        - name: config
          mountPath: /app/config
          readOnly: true
        - name: plugins
          mountPath: /app/plugins
        - name: models
          mountPath: /app/models
        - name: workspace
          mountPath: /tmp/tui-patcher/workspace
        - name: temp
          mountPath: /tmp/tui-patcher/temp
        - name: sbom
          mountPath: /app/sbom
          readOnly: true
        livenessProbe:
          httpGet:
            path: /health
            port: http
          initialDelaySeconds: 30
          periodSeconds: 10
          timeoutSeconds: 5
          failureThreshold: 3
        readinessProbe:
          httpGet:
            path: /readiness
            port: http
          initialDelaySeconds: 5
          periodSeconds: 5
          timeoutSeconds: 3
          failureThreshold: 3
        lifecycle:
          preStop:
            exec:
              command: ["/bin/sh", "-c", "sleep 10"]
      - name: otel-collector
        image: otel/opentelemetry-collector-contrib:0.91.0
        args:
          - --config=/etc/otel-collector-config.yml
        ports:
        - name: otlp-grpc
          containerPort: 4317
          protocol: TCP
        - name: otlp-http
          containerPort: 4318
          protocol: TCP
        volumeMounts:
        - name: otel-config
          mountPath: /etc/otel-collector-config.yml
          subPath: otel-collector.yml
          readOnly: true
        resources:
          requests:
            memory: "128Mi"
            cpu: "100m"
          limits:
            memory: "256Mi"
            cpu: "200m"
      volumes:
      - name: config
        configMap:
          name: tui-patcher-config
      - name: otel-config
        configMap:
          name: otel-collector-config
      - name: plugins
        persistentVolumeClaim:
          claimName: tui-patcher-plugins-pvc
      - name: models
        persistentVolumeClaim:
          claimName: tui-patcher-models-pvc
      - name: workspace
        emptyDir:
          sizeLimit: 10Gi
      - name: temp
        emptyDir:
          sizeLimit: 5Gi
      - name: sbom
        configMap:
          name: tui-patcher-sbom
      nodeSelector:
        kubernetes.io/arch: amd64
      tolerations:
      - key: node-role.kubernetes.io/master
        operator: Exists
        effect: NoSchedule
      affinity:
        podAntiAffinity:
          preferredDuringSchedulingIgnoredDuringExecution:
          - weight: 100
            podAffinityTerm:
              labelSelector:
                matchExpressions:
                - key: app
                  operator: In
                  values:
                  - tui-patcher-agent
              topologyKey: kubernetes.io/hostname

---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: tui-patcher-agent-frontend
  namespace: tui-patcher
  labels:
    app: tui-patcher-agent
    component: frontend
    version: v1.0.0
spec:
  replicas: 2
  selector:
    matchLabels:
      app: tui-patcher-agent
      component: frontend
  template:
    metadata:
      labels:
        app: tui-patcher-agent
        component: frontend
        version: v1.0.0
    spec:
      securityContext:
        runAsNonRoot: true
        runAsUser: 101
        runAsGroup: 101
      containers:
      - name: frontend
        image: tuipatcher/tui-patcher-frontend:v1.0.0
        imagePullPolicy: Always
        ports:
        - name: http
          containerPort: 80
          protocol: TCP
        resources:
          requests:
            memory: "64Mi"
            cpu: "50m"
          limits:
            memory: "128Mi"
            cpu: "100m"
        livenessProbe:
          httpGet:
            path: /health
            port: http
          initialDelaySeconds: 10
          periodSeconds: 30
        readinessProbe:
          httpGet:
            path: /health
            port: http
          initialDelaySeconds: 5
          periodSeconds: 10
```

## Service Manifest

```yaml
# k8s/service.yaml
apiVersion: v1
kind: Service
metadata:
  name: tui-patcher-backend
  namespace: tui-patcher
  labels:
    app: tui-patcher-agent
    component: backend
  annotations:
    prometheus.io/scrape: "true"
    prometheus.io/port: "8000"
    prometheus.io/path: "/api/v1/metrics"
spec:
  type: ClusterIP
  ports:
  - name: http
    port: 8000
    targetPort: http
    protocol: TCP
  - name: otlp-grpc
    port: 4317
    targetPort: otlp-grpc
    protocol: TCP
  - name: otlp-http
    port: 4318
    targetPort: otlp-http
    protocol: TCP
  selector:
    app: tui-patcher-agent
    component: backend

---
apiVersion: v1
kind: Service
metadata:
  name: tui-patcher-frontend
  namespace: tui-patcher
  labels:
    app: tui-patcher-agent
    component: frontend
spec:
  type: ClusterIP
  ports:
  - name: http
    port: 80
    targetPort: http
    protocol: TCP
  selector:
    app: tui-patcher-agent
    component: frontend
```

## ConfigMap

```yaml
# k8s/configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: tui-patcher-config
  namespace: tui-patcher
data:
  app.toml: |
    [server]
    host = "0.0.0.0"
    port = 8000
    workers = 4
    request_timeout = 30
    max_request_size = 104857600

    [database]
    max_connections = 20
    min_connections = 5
    connect_timeout = 30
    idle_timeout = 600

    [telemetry]
    service_name = "tui-patcher-agent"
    service_version = "v1.0.0"
    otlp_endpoint = "http://localhost:4317"
    sampling_ratio = 0.1

    [queue]
    max_concurrent_jobs = 20
    job_timeout = 600
    retry_attempts = 3
    retry_delay = 10
    dead_letter_queue = true

    [patching]
    workspace_dir = "/tmp/tui-patcher/workspace"
    temp_dir = "/tmp/tui-patcher/temp"
    max_apk_size = 209715200
    bundletool_path = "/opt/android-sdk/bundletool.jar"
    aapt_path = "/opt/android-sdk/aapt"
    zipalign_path = "/opt/android-sdk/zipalign"
    supported_formats = ["apk", "aab"]

    [plugins]
    plugin_dir = "/app/plugins"
    marketplace_url = "https://marketplace.tuipatcher.com"
    auto_update = false
    sandbox_memory_limit = 67108864
    execution_timeout = 30

    [ai]
    tflite_model_path = "/app/models/patch_analyzer.tflite"
    gemma_model_path = "/app/models/gemma-2b"
    cuda_enabled = false
    batch_size = 16

    [notifications.slack]
    channel = "#alerts"
    username = "TUI-Patcher-Bot"
    rate_limit = 10

    [security.rate_limit]
    requests_per_minute = 120
    burst_size = 20
    ban_duration = 300

    [security]
    cors_origins = ["https://tuipatcher.com", "https://app.tuipatcher.com"]

---
apiVersion: v1
kind: ConfigMap
metadata:
  name: otel-collector-config
  namespace: tui-patcher
data:
  otel-collector.yml: |
    receivers:
      otlp:
        protocols:
          grpc:
            endpoint: 0.0.0.0:4317
          http:
            endpoint: 0.0.0.0:4318
      prometheus:
        config:
          scrape_configs:
            - job_name: 'tui-patcher-agent'
              static_configs:
                - targets: ['localhost:8000']

    processors:
      batch:
        timeout: 1s
        send_batch_max_size: 1024
        send_batch_size: 512
      resource:
        attributes:
          - key: service.name
            value: tui-patcher-agent
            action: upsert
          - key: service.version
            value: v1.0.0
            action: upsert

    exporters:
      jaeger:
        endpoint: jaeger:14250
        tls:
          insecure: true
      prometheus:
        endpoint: "0.0.0.0:8889"
      logging:
        loglevel: debug

    service:
      pipelines:
        traces:
          receivers: [otlp]
          processors: [resource, batch]
          exporters: [jaeger, logging]
        metrics:
          receivers: [otlp, prometheus]
          processors: [resource, batch]
          exporters: [prometheus, logging]
```

## Ingress

```yaml
# k8s/ingress.yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: tui-patcher-ingress
  namespace: tui-patcher
  annotations:
    nginx.ingress.kubernetes.io/rewrite-target: /
    nginx.ingress.kubernetes.io/ssl-redirect: "true"
    nginx.ingress.kubernetes.io/proxy-body-size: "100m"
    cert-manager.io/cluster-issuer: "letsencrypt-prod"
    nginx.ingress.kubernetes.io/enable-cors: "true"
    nginx.ingress.kubernetes.io/cors-allow-origin: "https://tuipatcher.com"
    nginx.ingress.kubernetes.io/cors-allow-methods: "GET, POST, PUT, DELETE, OPTIONS"
    nginx.ingress.kubernetes.io/cors-allow-headers: "DNT,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Range,Authorization"
    nginx.ingress.kubernetes.io/proxy-read-timeout: "86400"
    nginx.ingress.kubernetes.io/proxy-send-timeout: "86400"
    nginx.ingress.kubernetes.io/upstream-hash-by: "$request_uri"
spec:
  tls:
  - hosts:
    - tuipatcher.com
    - api.tuipatcher.com
    secretName: tui-patcher-tls
  rules:
  - host: tuipatcher.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: tui-patcher-frontend
            port:
              number: 80
  - host: api.tuipatcher.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: tui-patcher-backend
            port:
              number: 8000
      - path: /ws
        pathType: Prefix
        backend:
          service:
            name: tui-patcher-backend
            port:
              number: 8000
```

## Horizontal Pod Autoscaler

```yaml
# k8s/hpa.yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: tui-patcher-backend-hpa
  namespace: tui-patcher
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: tui-patcher-agent-backend
  minReplicas: 3
  maxReplicas: 20
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
  - type: Pods
    pods:
      metric:
        name: http_requests_per_second
      target:
        type: AverageValue
        averageValue: "100"
  behavior:
    scaleUp:
      stabilizationWindowSeconds: 60
      policies:
      - type: Percent
        value: 100
        periodSeconds: 15
      - type: Pods
        value: 2
        periodSeconds: 60
      selectPolicy: Max
    scaleDown:
      stabilizationWindowSeconds: 300
      policies:
      - type: Percent
        value: 10
        periodSeconds: 60

---
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: tui-patcher-frontend-hpa
  namespace: tui-patcher
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: tui-patcher-agent-frontend
  minReplicas: 2
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 60
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 70
```

## PersistentVolumeClaim

```yaml
# k8s/pvc.yaml
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: tui-patcher-plugins-pvc
  namespace: tui-patcher
spec:
  accessModes:
    - ReadWriteMany
  resources:
    requests:
      storage: 10Gi
  storageClassName: nfs-client

---
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: tui-patcher-models-pvc
  namespace: tui-patcher
spec:
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 50Gi
  storageClassName: fast-ssd
```

## ServiceAccount and RBAC

```yaml
# k8s/rbac.yaml
apiVersion: v1
kind: ServiceAccount
metadata:
  name: tui-patcher-agent
  namespace: tui-patcher

---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: tui-patcher-agent-cluster-role
rules:
- apiGroups: [""]
  resources: ["pods", "services", "endpoints"]
  verbs: ["get", "list", "watch"]
- apiGroups: ["apps"]
  resources: ["deployments", "replicasets"]
  verbs: ["get", "list", "watch"]
- apiGroups: ["metrics.k8s.io"]
  resources: ["*"]
  verbs: ["get", "list"]

---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: tui-patcher-agent-cluster-role-binding
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: tui-patcher-agent-cluster-role
subjects:
- kind: ServiceAccount
  name: tui-patcher-agent
  namespace: tui-patcher
```

## Secret Template

```yaml
# k8s/secret-template.yaml
apiVersion: v1
kind: Secret
metadata:
  name: tui-patcher-secrets
  namespace: tui-patcher
type: Opaque
stringData:
  database-url: "postgresql://username:password@postgres:5432/tui_patcher"
  redis-url: "redis://redis:6379"
  slack-webhook-url: "https://hooks.slack.com/services/YOUR/WEBHOOK/URL"
  perplexity-api-key: "your-perplexity-api-key"
  perplexity-api-key-ci: "your-perplexity-ci-api-key"
  jwt-secret: "your-jwt-secret-key"
```