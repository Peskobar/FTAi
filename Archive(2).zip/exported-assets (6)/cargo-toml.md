# Backend Cargo.toml

```toml
[package]
name = "tui-patcher-agent"
version = "1.0.0"
edition = "2021"
authors = ["TUI-Patcher Team <team@tuipatcher.com>"]
description = "AI-powered Android patching service (micro-plugin)"
license = "Apache-2.0"
repository = "https://github.com/tuipatcher/tui-patcher-agent"

[dependencies]
# Web framework
axum = { version = "0.7", features = ["macros", "tracing", "ws"] }
tokio = { version = "1.0", features = ["full"] }
tower = { version = "0.4", features = ["full"] }
tower-http = { version = "0.5", features = ["trace", "cors", "fs"] }
hyper = { version = "1.0", features = ["full"] }
hyper-util = { version = "0.1", features = ["full"] }

# OpenTelemetry stack
opentelemetry = { version = "0.24", features = ["rt-tokio"] }
opentelemetry-otlp = { version = "0.17", features = ["grpc-tonic", "metrics", "trace"] }
tracing = "0.1"
tracing-opentelemetry = "0.25"
tracing-subscriber = { version = "0.3", features = ["json", "env-filter"] }
opentelemetry-semantic-conventions = "0.16"

# Serialization
serde = { version = "1.0", features = ["derive"] }
serde_json = "1.0"
toml = "0.8"

# HTTP client
reqwest = { version = "0.12", features = ["json", "rustls-tls"] }

# Database
sqlx = { version = "0.8", features = ["runtime-tokio-rustls", "postgres", "uuid", "chrono"] }

# Async utilities
futures = "0.3"
uuid = { version = "1.0", features = ["v4", "serde"] }
chrono = { version = "0.4", features = ["serde"] }

# Error handling
thiserror = "1.0"
anyhow = "1.0"

# Configuration
config = "0.14"

# WASM runtime
wasmtime = { version = "24.0", features = ["component-model"] }
wasmtime-wasi = "24.0"

# Android tools
zip = "2.1"

# AI/ML
candle-core = { version = "0.6", features = ["cuda"] }
candle-nn = "0.6" 
candle-transformers = "0.6"

# Monitoring
metrics = "0.23"
metrics-exporter-prometheus = "0.15"

# Security
ring = "0.17"
base64 = "0.22"

# Utilities
clap = { version = "4.0", features = ["derive"] }
dotenvy = "0.15"

[dev-dependencies]
tokio-test = "0.4"
tower-test = "0.4"
mockall = "0.13"

[build-dependencies]
cyclonedx-bom = "0.5"

[[bin]]
name = "tui-patcher-agent"
path = "src/main.rs"

[features]
default = ["otel-integration", "ai-features"]
otel-integration = []
ai-features = ["candle-core", "candle-nn"]
edge-runtime = []
```