# Backend Main.rs

```rust
//! TUI-Patcher-Agent - AI-powered Android patching service
//! 
//! This is the main entry point for the TUI-Patcher-Agent backend service.
//! The service provides enterprise-grade Android APK/AAB patching capabilities
//! with full OpenTelemetry observability, WASM plugin support, and edge deployment readiness.

use anyhow::Result;
use axum::{
    extract::DefaultBodyLimit,
    http::{HeaderValue, Method},
    routing::{get, post},
    Extension, Router,
};
use clap::{Arg, Command};
use dotenvy::dotenv;
use std::{net::SocketAddr, sync::Arc, time::Duration};
use tokio::signal;
use tower::ServiceBuilder;
use tower_http::{
    cors::CorsLayer,
    timeout::TimeoutLayer,
    trace::TraceLayer,
};
use tracing::{info, warn};

mod telemetry;
mod routes;
mod middleware;
mod patching;
mod queue;
mod notifications;
mod database;
mod ai;
mod plugins;
mod error;
mod config;
mod health;
mod websocket;

use config::AppConfig;
use database::Database;
use error::AppError;
use health::HealthChecker;
use queue::QueueManager;
use telemetry::TelemetryService;

/// Application state shared across all handlers
#[derive(Clone)]
pub struct AppState {
    pub db: Database,
    pub queue: Arc<QueueManager>,
    pub config: AppConfig,
    pub health: Arc<HealthChecker>,
    pub telemetry: Arc<TelemetryService>,
    pub patch_engine: Arc<patching::PatchEngine>,
    pub plugin_manager: Arc<plugins::PluginManager>,
    pub ai_service: Arc<ai::AIService>,
    pub notification_service: Arc<notifications::NotificationService>,
}

#[tokio::main]
async fn main() -> Result<()> {
    // Load environment variables
    if let Err(e) = dotenv() {
        warn!("Failed to load .env file: {}", e);
    }

    // Parse command line arguments
    let matches = Command::new("tui-patcher-agent")
        .version("1.0.0")
        .author("TUI-Patcher Team")
        .about("AI-powered Android patching service")
        .arg(
            Arg::new("config")
                .short('c')
                .long("config")
                .value_name("FILE")
                .help("Sets a custom config file")
                .default_value("config/app.toml"),
        )
        .arg(
            Arg::new("port")
                .short('p')
                .long("port")
                .value_name("PORT")
                .help("Sets the server port")
                .default_value("8000"),
        )
        .get_matches();

    // Load configuration
    let config_path = matches.get_one::<String>("config").unwrap();
    let config = AppConfig::load(config_path)?;
    
    // Initialize telemetry first
    let telemetry_service = Arc::new(TelemetryService::new(&config.telemetry)?);
    telemetry_service.init_tracing().await?;
    
    info!("TUI-Patcher-Agent starting up...");
    info!("Version: {}", env!("CARGO_PKG_VERSION"));
    info!("Config loaded from: {}", config_path);

    // Initialize database
    let db = Database::connect(&config.database).await?;
    db.run_migrations().await?;
    info!("Database connected and migrations applied");

    // Initialize core services
    let queue_manager = Arc::new(QueueManager::new(&config.queue, db.clone()).await?);
    let health_checker = Arc::new(HealthChecker::new());
    let patch_engine = Arc::new(patching::PatchEngine::new(&config.patching)?);
    let plugin_manager = Arc::new(plugins::PluginManager::new(&config.plugins)?);
    let ai_service = Arc::new(ai::AIService::new(&config.ai)?);
    let notification_service = Arc::new(
        notifications::NotificationService::new(&config.notifications)?
    );

    info!("Core services initialized");

    // Create application state
    let app_state = AppState {
        db,
        queue: queue_manager.clone(),
        config: config.clone(),
        health: health_checker.clone(),
        telemetry: telemetry_service.clone(),
        patch_engine,
        plugin_manager,
        ai_service,
        notification_service,
    };

    // Start background services
    let queue_processor = queue_manager.clone();
    tokio::spawn(async move {
        if let Err(e) = queue_processor.start_processing().await {
            tracing::error!("Queue processor error: {}", e);
        }
    });

    // Health monitoring task
    let health_monitor = health_checker.clone();
    tokio::spawn(async move {
        health_monitor.start_monitoring().await;
    });

    // Build the application router
    let app = build_router(app_state).await?;

    // Server configuration
    let port: u16 = matches.get_one::<String>("port")
        .unwrap()
        .parse()
        .expect("Invalid port number");
    let addr = SocketAddr::from(([0, 0, 0, 0], port));

    info!("Starting server on {}", addr);

    // Create server
    let listener = tokio::net::TcpListener::bind(addr).await?;
    
    // Start server with graceful shutdown
    axum::serve(listener, app)
        .with_graceful_shutdown(shutdown_signal())
        .await?;

    info!("TUI-Patcher-Agent shut down successfully");
    Ok(())
}

/// Build the main application router with all routes and middleware
async fn build_router(state: AppState) -> Result<Router> {
    // CORS configuration
    let cors = CorsLayer::new()
        .allow_origin("http://localhost:3000".parse::<HeaderValue>()?)
        .allow_methods([Method::GET, Method::POST, Method::PUT, Method::DELETE])
        .allow_headers(tower_http::cors::Any)
        .allow_credentials(true);

    // Build the router
    let router = Router::new()
        // Health endpoints
        .route("/health", get(routes::health::health_check))
        .route("/readiness", get(routes::health::readiness_check))
        .route("/liveness", get(routes::health::liveness_check))
        
        // Core API endpoints
        .route("/api/v1/enqueue", post(routes::enqueue::handle_enqueue))
        .route("/api/v1/status/:id", get(routes::status::handle_status))
        .route("/api/v1/metrics", get(routes::metrics::handle_metrics))
        .route("/api/v1/sbom", get(routes::sbom::handle_sbom))
        
        // Queue management
        .route("/api/v1/queue", get(routes::queue::get_queue_status))
        .route("/api/v1/queue/:id/cancel", post(routes::queue::cancel_job))
        
        // Plugin marketplace
        .route("/api/v1/plugins", get(routes::plugins::list_plugins))
        .route("/api/v1/plugins/:id", get(routes::plugins::get_plugin))
        .route("/api/v1/plugins/:id/install", post(routes::plugins::install_plugin))
        
        // AI services
        .route("/api/v1/ai/analyze", post(routes::ai::analyze_apk))
        .route("/api/v1/ai/suggest", post(routes::ai::suggest_patches))
        
        // WebSocket for real-time updates
        .route("/ws", get(websocket::websocket_handler))
        
        // Static file serving for frontend
        .nest_service("/", tower_http::services::ServeDir::new("frontend/dist"))
        
        // Add state and middleware
        .with_state(state)
        .layer(
            ServiceBuilder::new()
                .layer(cors)
                .layer(TraceLayer::new_for_http())
                .layer(middleware::tracing::TraceparentLayer::new())
                .layer(middleware::auth::AuthLayer::new())
                .layer(DefaultBodyLimit::max(100 * 1024 * 1024)) // 100MB limit
                .layer(TimeoutLayer::new(Duration::from_secs(30)))
        );

    Ok(router)
}

/// Graceful shutdown signal handler
async fn shutdown_signal() {
    let ctrl_c = async {
        signal::ctrl_c()
            .await
            .expect("failed to install Ctrl+C handler");
    };

    #[cfg(unix)]
    let terminate = async {
        signal::unix::signal(signal::unix::SignalKind::terminate())
            .expect("failed to install signal handler")
            .recv()
            .await;
    };

    #[cfg(not(unix))]
    let terminate = std::future::pending::<()>();

    tokio::select! {
        _ = ctrl_c => {},
        _ = terminate => {},
    }

    info!("Shutdown signal received, starting graceful shutdown");
}
```