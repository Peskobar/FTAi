# Frontend Components

## Dashboard Component

```tsx
// src/components/Dashboard.tsx
import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { 
  Activity, 
  Clock, 
  CheckCircle, 
  XCircle, 
  Zap,
  TrendingUp,
  Users,
  Server
} from 'lucide-react'
import { useQuery } from '@tanstack/react-query'
import { QueueMonitor } from './QueueMonitor'
import { TraceExplorer } from './TraceExplorer'
import { RealtimeMetrics } from './RealtimeMetrics'
import { PerformanceChart } from './PerformanceChart'
import { useWebSocket } from '@hooks/useWebSocket'
import { apiClient } from '@services/api'
import type { DashboardMetrics } from '@types'

export const Dashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'overview' | 'queue' | 'traces' | 'metrics'>('overview')
  
  // Fetch dashboard metrics
  const { data: metrics, isLoading } = useQuery({
    queryKey: ['dashboard-metrics'],
    queryFn: () => apiClient.get<DashboardMetrics>('/api/v1/metrics'),
    refetchInterval: 5000, // Refresh every 5 seconds
  })

  // WebSocket connection for real-time updates
  const { isConnected, data: realtimeData } = useWebSocket('/ws', {
    onMessage: (data) => {
      // Handle real-time updates
      console.log('Real-time update:', data)
    },
  })

  const statCards = [
    {
      title: 'Queue Size',
      value: metrics?.queue_size || 0,
      icon: Clock,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
      change: '+2.3%',
      changeType: 'increase' as const,
    },
    {
      title: 'Active Jobs',
      value: metrics?.active_jobs || 0,
      icon: Activity,
      color: 'text-green-600',
      bgColor: 'bg-green-50',
      change: '+5.1%',
      changeType: 'increase' as const,
    },
    {
      title: 'Success Rate',
      value: `${metrics?.success_rate_24h || 95.2}%`,
      icon: CheckCircle,
      color: 'text-emerald-600',
      bgColor: 'bg-emerald-50',
      change: '+0.8%',
      changeType: 'increase' as const,
    },
    {
      title: 'Avg Process Time',
      value: `${metrics?.avg_processing_time || 2.4}s`,
      icon: Zap,
      color: 'text-orange-600',
      bgColor: 'bg-orange-50',
      change: '-0.3s',
      changeType: 'decrease' as const,
    },
  ]

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            TUI-Patcher-Agent Dashboard
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Monitor your Android patching operations in real-time
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <div className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
            isConnected 
              ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
              : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
          }`}>
            <div className={`w-2 h-2 rounded-full mr-1 ${
              isConnected ? 'bg-green-500' : 'bg-red-500'
            }`} />
            {isConnected ? 'Connected' : 'Disconnected'}
          </div>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((stat, index) => (
          <motion.div
            key={stat.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
            className="card"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">
                  {stat.title}
                </p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">
                  {stat.value}
                </p>
              </div>
              <div className={`p-3 rounded-full ${stat.bgColor} dark:${stat.bgColor.replace('50', '900/20')}`}>
                <stat.icon className={`h-6 w-6 ${stat.color}`} />
              </div>
            </div>
            <div className="mt-4 flex items-center text-sm">
              <span className={`font-medium ${
                stat.changeType === 'increase' ? 'text-green-600' : 'text-red-600'
              }`}>
                {stat.change}
              </span>
              <span className="text-gray-500 ml-1">vs last 24h</span>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Tab Navigation */}
      <div className="border-b border-gray-200 dark:border-gray-700">
        <nav className="-mb-px flex space-x-8">
          {[
            { key: 'overview', label: 'Overview', icon: TrendingUp },
            { key: 'queue', label: 'Queue Monitor', icon: Clock },
            { key: 'traces', label: 'Trace Explorer', icon: Activity },
            { key: 'metrics', label: 'Metrics', icon: Server },
          ].map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key as any)}
              className={`flex items-center py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === tab.key
                  ? 'border-primary-500 text-primary-600 dark:text-primary-400'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
              }`}
            >
              <tab.icon className="h-4 w-4 mr-2" />
              {tab.label}
            </button>
          ))}
        </nav>
      </div>

      {/* Tab Content */}
      <div className="mt-6">
        {activeTab === 'overview' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-6">
              <PerformanceChart />
              <RealtimeMetrics />
            </div>
            <div className="space-y-6">
              <QueueMonitor compact />
              <div className="card">
                <h3 className="text-lg font-semibold mb-4">Recent Activity</h3>
                <div className="space-y-3">
                  {/* Recent activity items */}
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="h-5 w-5 text-green-500" />
                    <div className="flex-1">
                      <p className="text-sm font-medium">APK patching completed</p>
                      <p className="text-xs text-gray-500">job_id: abc123 • 2 minutes ago</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Activity className="h-5 w-5 text-blue-500" />
                    <div className="flex-1">
                      <p className="text-sm font-medium">New job queued</p>
                      <p className="text-xs text-gray-500">job_id: def456 • 5 minutes ago</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <XCircle className="h-5 w-5 text-red-500" />
                    <div className="flex-1">
                      <p className="text-sm font-medium">Job failed - retry initiated</p>
                      <p className="text-xs text-gray-500">job_id: ghi789 • 8 minutes ago</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
        
        {activeTab === 'queue' && <QueueMonitor />}
        {activeTab === 'traces' && <TraceExplorer />}
        {activeTab === 'metrics' && <RealtimeMetrics />}
      </div>
    </div>
  )
}
```

## Queue Monitor Component

```tsx
// src/components/QueueMonitor.tsx
import React, { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Clock, 
  Play, 
  Pause, 
  CheckCircle, 
  XCircle, 
  AlertCircle,
  MoreHorizontal,
  RefreshCw
} from 'lucide-react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { apiClient } from '@services/api'
import type { QueueJob, QueueStatus } from '@types'
import { formatDistanceToNow } from 'date-fns'

interface QueueMonitorProps {
  compact?: boolean
}

export const QueueMonitor: React.FC<QueueMonitorProps> = ({ compact = false }) => {
  const [selectedJobs, setSelectedJobs] = useState<Set<string>>(new Set())
  const queryClient = useQueryClient()

  // Fetch queue data
  const { data: queueData, isLoading, error } = useQuery({
    queryKey: ['queue-status'],
    queryFn: () => apiClient.get<QueueStatus>('/api/v1/queue'),
    refetchInterval: 2000,
  })

  // Cancel job mutation
  const cancelJobMutation = useMutation({
    mutationFn: (jobId: string) => apiClient.post(`/api/v1/queue/${jobId}/cancel`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['queue-status'] })
    },
  })

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'queued':
        return <Clock className="h-4 w-4 text-blue-500" />
      case 'processing':
        return <Play className="h-4 w-4 text-green-500" />
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-emerald-500" />
      case 'failed':
        return <XCircle className="h-4 w-4 text-red-500" />
      case 'cancelled':
        return <Pause className="h-4 w-4 text-gray-500" />
      default:
        return <AlertCircle className="h-4 w-4 text-yellow-500" />
    }
  }

  const getStatusBadge = (status: string) => {
    const baseClasses = "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium"
    
    switch (status) {
      case 'queued':
        return `${baseClasses} bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400`
      case 'processing':
        return `${baseClasses} bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400`
      case 'completed':
        return `${baseClasses} bg-emerald-100 text-emerald-800 dark:bg-emerald-900/20 dark:text-emerald-400`
      case 'failed':
        return `${baseClasses} bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400`
      case 'cancelled':
        return `${baseClasses} bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300`
      default:
        return `${baseClasses} bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400`
    }
  }

  if (isLoading) {
    return (
      <div className="card">
        <div className="animate-pulse space-y-4">
          <div className="h-4 bg-gray-200 rounded w-1/4"></div>
          <div className="space-y-2">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-12 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="card">
        <div className="text-center py-8">
          <XCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
          <p className="text-red-600 dark:text-red-400">Failed to load queue data</p>
        </div>
      </div>
    )
  }

  const jobs = queueData?.jobs || []
  const displayJobs = compact ? jobs.slice(0, 5) : jobs

  return (
    <div className="card">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            Queue Monitor
          </h3>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            {jobs.length} jobs • {jobs.filter(j => j.status === 'processing').length} active
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => queryClient.invalidateQueries({ queryKey: ['queue-status'] })}
            className="btn-ghost p-2"
          >
            <RefreshCw className="h-4 w-4" />
          </button>
        </div>
      </div>

      <div className="space-y-2">
        <AnimatePresence>
          {displayJobs.map((job) => (
            <motion.div
              key={job.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, x: -10 }}
              className="flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50 dark:border-gray-700 dark:hover:bg-gray-800/50 transition-colors"
            >
              <div className="flex items-center space-x-3 min-w-0 flex-1">
                {getStatusIcon(job.status)}
                <div className="min-w-0 flex-1">
                  <div className="flex items-center space-x-2">
                    <p className="text-sm font-medium text-gray-900 dark:text-white truncate">
                      {job.filename}
                    </p>
                    <span className={getStatusBadge(job.status)}>
                      {job.status}
                    </span>
                  </div>
                  <div className="flex items-center space-x-4 mt-1">
                    <p className="text-xs text-gray-500">
                      ID: {job.id.slice(0, 8)}...
                    </p>
                    <p className="text-xs text-gray-500">
                      {formatDistanceToNow(new Date(job.created_at), { addSuffix: true })}
                    </p>
                    {job.status === 'processing' && (
                      <div className="flex items-center space-x-2">
                        <div className="w-16 bg-gray-200 rounded-full h-1.5 dark:bg-gray-700">
                          <div 
                            className="bg-primary-600 h-1.5 rounded-full transition-all duration-300"
                            style={{ width: `${job.progress}%` }}
                          />
                        </div>
                        <span className="text-xs text-gray-500">{job.progress}%</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
              
              {job.status === 'queued' || job.status === 'processing' ? (
                <button
                  onClick={() => cancelJobMutation.mutate(job.id)}
                  disabled={cancelJobMutation.isPending}
                  className="btn-ghost p-2 text-red-600 hover:text-red-700"
                >
                  <Pause className="h-4 w-4" />
                </button>
              ) : (
                <button className="btn-ghost p-2">
                  <MoreHorizontal className="h-4 w-4" />
                </button>
              )}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {jobs.length === 0 && (
        <div className="text-center py-8">
          <Clock className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-500 dark:text-gray-400">No jobs in queue</p>
        </div>
      )}

      {compact && jobs.length > 5 && (
        <div className="mt-4 text-center">
          <button className="text-primary-600 hover:text-primary-700 text-sm font-medium">
            View all {jobs.length} jobs
          </button>
        </div>
      )}
    </div>
  )
}
```