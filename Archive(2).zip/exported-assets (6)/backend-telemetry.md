# Backend Telemetry Module

```rust
//! OpenTelemetry telemetry service for TUI-Patcher-Agent
//! 
//! This module provides comprehensive observability with distributed tracing,
//! metrics collection, and logging using OpenTelemetry standards.

use anyhow::{Context, Result};
use opentelemetry::{
    global,
    KeyValue,
    metrics::{Counter, Histogram, MeterProvider},
    trace::{TraceContextExt, Tracer},
};
use opentelemetry_otlp::{WithExportConfig, WithTonicConfig};
use opentelemetry_semantic_conventions as semcov;
use std::{collections::HashMap, sync::Arc, time::Duration};
use tracing::{info, warn, Span};
use tracing_opentelemetry::OpenTelemetrySpanExt;
use tracing_subscriber::{
    fmt,
    layer::SubscriberExt,
    util::SubscriberInitExt,
    EnvFilter,
    Layer,
};

use crate::config::TelemetryConfig;

/// Telemetry service managing all observability concerns
pub struct TelemetryService {
    tracer: Arc<dyn Tracer + Send + Sync>,
    metrics: TelemetryMetrics,
    config: TelemetryConfig,
}

/// Application-specific metrics
#[derive(Clone)]
pub struct TelemetryMetrics {
    pub http_requests_total: Counter<u64>,
    pub http_request_duration: Histogram<f64>,
    pub queue_size: Histogram<u64>,
    pub patch_operations_total: Counter<u64>,
    pub patch_success_rate: Histogram<f64>,
    pub plugin_executions_total: Counter<u64>,
    pub ai_inference_duration: Histogram<f64>,
}

impl TelemetryService {
    /// Create a new telemetry service
    pub fn new(config: &TelemetryConfig) -> Result<Self> {
        let tracer = Arc::new(
            global::tracer_provider()
                .tracer("tui-patcher-agent")
        );

        let meter = global::meter_provider()
            .meter("tui-patcher-agent");

        let metrics = TelemetryMetrics {
            http_requests_total: meter
                .u64_counter("http_requests_total")
                .with_description("Total number of HTTP requests")
                .init(),
            http_request_duration: meter
                .f64_histogram("http_request_duration_seconds")
                .with_description("Duration of HTTP requests in seconds")
                .init(),
            queue_size: meter
                .u64_histogram("queue_size")
                .with_description("Current queue size")
                .init(),
            patch_operations_total: meter
                .u64_counter("patch_operations_total")
                .with_description("Total number of patch operations")
                .init(),
            patch_success_rate: meter
                .f64_histogram("patch_success_rate")
                .with_description("Patch operation success rate")
                .init(),
            plugin_executions_total: meter
                .u64_counter("plugin_executions_total")
                .with_description("Total number of plugin executions")
                .init(),
            ai_inference_duration: meter
                .f64_histogram("ai_inference_duration_seconds")
                .with_description("Duration of AI inference operations in seconds")
                .init(),
        };

        Ok(Self {
            tracer,
            metrics,
            config: config.clone(),
        })
    }

    /// Initialize OpenTelemetry tracing and metrics
    pub async fn init_tracing(&self) -> Result<()> {
        // Initialize OTLP trace exporter
        let otlp_exporter = opentelemetry_otlp::new_exporter()
            .tonic()
            .with_endpoint(&self.config.otlp_endpoint)
            .with_timeout(Duration::from_secs(10));

        let tracer = opentelemetry_otlp::new_pipeline()
            .tracing()
            .with_exporter(otlp_exporter)
            .with_trace_config(
                opentelemetry::sdk::trace::config()
                    .with_sampler(opentelemetry::sdk::trace::Sampler::TraceIdRatioBased(
                        self.config.sampling_ratio,
                    ))
                    .with_resource(opentelemetry::sdk::Resource::new(vec![
                        KeyValue::new(semcov::resource::SERVICE_NAME, self.config.service_name.clone()),
                        KeyValue::new(semcov::resource::SERVICE_VERSION, self.config.service_version.clone()),
                        KeyValue::new(semcov::resource::SERVICE_INSTANCE_ID, uuid::Uuid::new_v4().to_string()),
                    ])),
            )
            .install_batch(opentelemetry::runtime::Tokio)
            .context("Failed to install OpenTelemetry tracer")?;

        // Initialize OTLP metrics exporter
        let metrics_exporter = opentelemetry_otlp::new_exporter()
            .tonic()
            .with_endpoint(&self.config.otlp_endpoint);

        let meter_provider = opentelemetry_otlp::new_pipeline()
            .metrics(opentelemetry::runtime::Tokio)
            .with_exporter(metrics_exporter)
            .with_resource(opentelemetry::sdk::Resource::new(vec![
                KeyValue::new(semcov::resource::SERVICE_NAME, self.config.service_name.clone()),
                KeyValue::new(semcov::resource::SERVICE_VERSION, self.config.service_version.clone()),
            ]))
            .build()
            .context("Failed to build metrics provider")?;

        global::set_meter_provider(meter_provider);

        // Initialize tracing subscriber
        let telemetry_layer = tracing_opentelemetry::layer()
            .with_tracer(tracer);

        let env_filter = EnvFilter::try_from_default_env()
            .or_else(|_| EnvFilter::try_new("tui_patcher_agent=info,axum=debug"))
            .context("Failed to create env filter")?;

        tracing_subscriber::registry()
            .with(env_filter)
            .with(telemetry_layer)
            .with(
                fmt::layer()
                    .json()
                    .with_current_span(true)
                    .with_span_list(true)
                    .with_target(false)
            )
            .init();

        info!("OpenTelemetry telemetry initialized successfully");
        info!("OTLP endpoint: {}", self.config.otlp_endpoint);
        info!("Sampling ratio: {}", self.config.sampling_ratio);

        Ok(())
    }

    /// Get reference to metrics
    pub fn metrics(&self) -> &TelemetryMetrics {
        &self.metrics
    }

    /// Record HTTP request metrics
    pub fn record_http_request(
        &self,
        method: &str,
        path: &str,
        status: u16,
        duration: Duration,
    ) {
        let labels = [
            KeyValue::new("method", method.to_string()),
            KeyValue::new("path", path.to_string()),
            KeyValue::new("status", status.to_string()),
        ];

        self.metrics.http_requests_total.add(1, &labels);
        self.metrics.http_request_duration.record(
            duration.as_secs_f64(),
            &labels,
        );
    }

    /// Record queue metrics
    pub fn record_queue_size(&self, size: u64) {
        self.metrics.queue_size.record(size, &[]);
    }

    /// Record patch operation metrics
    pub fn record_patch_operation(&self, success: bool, patch_type: &str) {
        let labels = [
            KeyValue::new("success", success.to_string()),
            KeyValue::new("patch_type", patch_type.to_string()),
        ];

        self.metrics.patch_operations_total.add(1, &labels);
    }

    /// Record plugin execution metrics
    pub fn record_plugin_execution(&self, plugin_name: &str, success: bool, duration: Duration) {
        let labels = [
            KeyValue::new("plugin_name", plugin_name.to_string()),
            KeyValue::new("success", success.to_string()),
        ];

        self.metrics.plugin_executions_total.add(1, &labels);
    }

    /// Record AI inference metrics
    pub fn record_ai_inference(&self, model: &str, duration: Duration) {
        let labels = [KeyValue::new("model", model.to_string())];
        self.metrics.ai_inference_duration.record(duration.as_secs_f64(), &labels);
    }

    /// Add custom attributes to current span
    pub fn add_span_attributes(&self, attributes: &[(&str, &str)]) {
        let span = Span::current();
        let context = span.context();
        
        if let Some(otel_span) = context.span() {
            for (key, value) in attributes {
                otel_span.set_attribute(KeyValue::new(*key, value.to_string()));
            }
        }
    }

    /// Create a new span with custom attributes
    pub fn create_span(&self, name: &str, attributes: &[(&str, &str)]) -> tracing::Span {
        let span = tracing::info_span!(name);
        
        for (key, value) in attributes {
            span.record(key, value);
        }
        
        span
    }
}

/// Middleware for automatic HTTP request tracing
pub mod middleware {
    use super::*;
    use axum::{
        extract::Request,
        middleware::Next,
        response::Response,
    };
    use std::time::Instant;

    pub async fn trace_requests(
        request: Request,
        next: Next,
    ) -> Response {
        let start = Instant::now();
        let method = request.method().to_string();
        let path = request.uri().path().to_string();

        let span = tracing::info_span!(
            "http_request",
            method = %method,
            path = %path,
            status = tracing::field::Empty,
            duration = tracing::field::Empty,
        );

        let response = next.run(request).await;
        let duration = start.elapsed();
        let status = response.status().as_u16();

        span.record("status", status);
        span.record("duration", format!("{}ms", duration.as_millis()));

        response
    }
}

/// Utility functions for tracing
pub mod utils {
    use super::*;
    use uuid::Uuid;

    /// Generate a unique trace ID for operations
    pub fn generate_trace_id() -> String {
        Uuid::new_v4().to_string()
    }

    /// Create a child span with correlation ID
    pub fn create_child_span(parent_span: &tracing::Span, name: &str, correlation_id: &str) -> tracing::Span {
        let _guard = parent_span.enter();
        tracing::info_span!(
            name,
            correlation_id = %correlation_id,
            parent_span = %parent_span.id().unwrap_or(tracing::Id::from_u64(0))
        )
    }

    /// Add error information to span
    pub fn record_error(span: &tracing::Span, error: &dyn std::error::Error) {
        span.record("error", true);
        span.record("error.message", error.to_string().as_str());
        span.record("error.type", std::any::type_name_of_val(error));
    }

    /// Record custom event in span
    pub fn record_event(event_name: &str, attributes: &[(&str, &str)]) {
        let mut event = tracing::event!(tracing::Level::INFO, event_name);
        for (key, value) in attributes {
            event = tracing::event!(tracing::Level::INFO, event_name, %key = %value);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::TelemetryConfig;

    #[tokio::test]
    async fn test_telemetry_service_creation() {
        let config = TelemetryConfig {
            service_name: "test-service".to_string(),
            service_version: "1.0.0".to_string(),
            otlp_endpoint: "http://localhost:4317".to_string(),
            sampling_ratio: 1.0,
            jaeger_endpoint: None,
            prometheus_endpoint: None,
        };

        let service = TelemetryService::new(&config);
        assert!(service.is_ok());
    }

    #[test]
    fn test_metrics_recording() {
        let config = TelemetryConfig {
            service_name: "test-service".to_string(),
            service_version: "1.0.0".to_string(),
            otlp_endpoint: "http://localhost:4317".to_string(),
            sampling_ratio: 1.0,
            jaeger_endpoint: None,
            prometheus_endpoint: None,
        };

        let service = TelemetryService::new(&config).unwrap();
        
        // Test HTTP request recording
        service.record_http_request("GET", "/api/v1/test", 200, Duration::from_millis(100));
        
        // Test queue size recording
        service.record_queue_size(5);
        
        // Test patch operation recording
        service.record_patch_operation(true, "security");
        
        // Test plugin execution recording
        service.record_plugin_execution("test-plugin", true, Duration::from_millis(50));
    }
}
```