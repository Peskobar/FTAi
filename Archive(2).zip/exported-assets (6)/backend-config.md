# Backend Configuration Module

```rust
//! Configuration management for TUI-Patcher-Agent
//! 
//! This module handles loading and parsing of configuration files,
//! environment variables, and provides typed configuration structs.

use anyhow::{Context, Result};
use serde::{Deserialize, Serialize};
use std::{env, path::Path};

/// Main application configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AppConfig {
    pub server: ServerConfig,
    pub database: DatabaseConfig,
    pub telemetry: TelemetryConfig,
    pub queue: QueueConfig,
    pub patching: PatchingConfig,
    pub plugins: PluginConfig,
    pub ai: AIConfig,
    pub notifications: NotificationConfig,
    pub security: SecurityConfig,
}

/// Server configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ServerConfig {
    pub host: String,
    pub port: u16,
    pub workers: usize,
    pub request_timeout: u64,
    pub max_request_size: usize,
}

/// Database configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DatabaseConfig {
    pub url: String,
    pub max_connections: u32,
    pub min_connections: u32,
    pub connect_timeout: u64,
    pub idle_timeout: u64,
}

/// OpenTelemetry configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TelemetryConfig {
    pub service_name: String,
    pub service_version: String,
    pub otlp_endpoint: String,
    pub sampling_ratio: f64,
    pub jaeger_endpoint: Option<String>,
    pub prometheus_endpoint: Option<String>,
}

/// Queue management configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct QueueConfig {
    pub max_concurrent_jobs: usize,
    pub job_timeout: u64,
    pub retry_attempts: u32,
    pub retry_delay: u64,
    pub dead_letter_queue: bool,
}

/// APK/AAB patching configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PatchingConfig {
    pub workspace_dir: String,
    pub temp_dir: String,
    pub max_apk_size: usize,
    pub bundletool_path: String,
    pub aapt_path: String,
    pub zipalign_path: String,
    pub supported_formats: Vec<String>,
}

/// WASM plugin system configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PluginConfig {
    pub plugin_dir: String,
    pub marketplace_url: String,
    pub auto_update: bool,
    pub sandbox_memory_limit: usize,
    pub execution_timeout: u64,
}

/// AI/ML services configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AIConfig {
    pub tflite_model_path: String,
    pub gemma_model_path: String,
    pub perplexity_api_key: Option<String>,
    pub perplexity_api_key_ci: Option<String>,
    pub cuda_enabled: bool,
    pub batch_size: usize,
}

/// Notification services configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NotificationConfig {
    pub slack: SlackConfig,
    pub email: EmailConfig,
    pub webhooks: Vec<WebhookConfig>,
}

/// Slack notification configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SlackConfig {
    pub webhook_url: Option<String>,
    pub channel: String,
    pub username: String,
    pub rate_limit: u32,
}

/// Email notification configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EmailConfig {
    pub smtp_server: String,
    pub smtp_port: u16,
    pub username: String,
    pub password: String,
    pub from_address: String,
}

/// Webhook configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WebhookConfig {
    pub name: String,
    pub url: String,
    pub secret: String,
    pub events: Vec<String>,
}

/// Security configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SecurityConfig {
    pub jwt_secret: String,
    pub api_keys: Vec<String>,
    pub rate_limit: RateLimitConfig,
    pub cors_origins: Vec<String>,
}

/// Rate limiting configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RateLimitConfig {
    pub requests_per_minute: u32,
    pub burst_size: u32,
    pub ban_duration: u64,
}

impl AppConfig {
    /// Load configuration from file with environment variable overrides
    pub fn load<P: AsRef<Path>>(config_path: P) -> Result<Self> {
        let mut config = config::Config::builder()
            .add_source(config::File::with_name(
                config_path.as_ref().to_str().unwrap()
            ))
            .add_source(config::Environment::with_prefix("TUI_PATCHER"));

        // Apply environment-specific overrides
        if let Ok(env) = env::var("ENVIRONMENT") {
            config = config.add_source(config::File::with_name(&format!("config/{}", env)).required(false));
        }

        let config = config.build()
            .context("Failed to build configuration")?;

        let app_config: AppConfig = config.try_deserialize()
            .context("Failed to deserialize configuration")?;

        // Validate configuration
        app_config.validate()?;

        Ok(app_config)
    }

    /// Validate configuration values
    fn validate(&self) -> Result<()> {
        // Validate server config
        if self.server.port == 0 {
            return Err(anyhow::anyhow!("Server port must be greater than 0"));
        }

        // Validate database URL
        if self.database.url.is_empty() {
            return Err(anyhow::anyhow!("Database URL cannot be empty"));
        }

        // Validate telemetry config
        if self.telemetry.service_name.is_empty() {
            return Err(anyhow::anyhow!("Service name cannot be empty"));
        }

        // Validate patching paths
        if !Path::new(&self.patching.bundletool_path).exists() {
            return Err(anyhow::anyhow!("Bundletool path does not exist"));
        }

        // Validate AI config if AI features are enabled
        #[cfg(feature = "ai-features")]
        {
            if !Path::new(&self.ai.tflite_model_path).exists() {
                return Err(anyhow::anyhow!("TensorFlow Lite model path does not exist"));
            }
        }

        Ok(())
    }
}

impl Default for AppConfig {
    fn default() -> Self {
        Self {
            server: ServerConfig {
                host: "0.0.0.0".to_string(),
                port: 8000,
                workers: num_cpus::get(),
                request_timeout: 30,
                max_request_size: 100 * 1024 * 1024, // 100MB
            },
            database: DatabaseConfig {
                url: env::var("DATABASE_URL")
                    .unwrap_or_else(|_| "postgresql://localhost/tui_patcher".to_string()),
                max_connections: 10,
                min_connections: 2,
                connect_timeout: 30,
                idle_timeout: 600,
            },
            telemetry: TelemetryConfig {
                service_name: "tui-patcher-agent".to_string(),
                service_version: env!("CARGO_PKG_VERSION").to_string(),
                otlp_endpoint: env::var("OTEL_EXPORTER_OTLP_ENDPOINT")
                    .unwrap_or_else(|_| "http://localhost:4317".to_string()),
                sampling_ratio: 0.1,
                jaeger_endpoint: env::var("JAEGER_ENDPOINT").ok(),
                prometheus_endpoint: env::var("PROMETHEUS_ENDPOINT").ok(),
            },
            queue: QueueConfig {
                max_concurrent_jobs: 10,
                job_timeout: 300,
                retry_attempts: 3,
                retry_delay: 5,
                dead_letter_queue: true,
            },
            patching: PatchingConfig {
                workspace_dir: "/tmp/tui-patcher/workspace".to_string(),
                temp_dir: "/tmp/tui-patcher/temp".to_string(),
                max_apk_size: 200 * 1024 * 1024, // 200MB
                bundletool_path: "/usr/local/bin/bundletool.jar".to_string(),
                aapt_path: "/usr/local/bin/aapt".to_string(),
                zipalign_path: "/usr/local/bin/zipalign".to_string(),
                supported_formats: vec!["apk".to_string(), "aab".to_string()],
            },
            plugins: PluginConfig {
                plugin_dir: "plugins".to_string(),
                marketplace_url: "https://marketplace.tuipatcher.com".to_string(),
                auto_update: false,
                sandbox_memory_limit: 64 * 1024 * 1024, // 64MB
                execution_timeout: 30,
            },
            ai: AIConfig {
                tflite_model_path: "models/patch_analyzer.tflite".to_string(),
                gemma_model_path: "models/gemma-2b".to_string(),
                perplexity_api_key: env::var("PPX_API_KEY").ok(),
                perplexity_api_key_ci: env::var("PPX_API_KEY_CI").ok(),
                cuda_enabled: false,
                batch_size: 8,
            },
            notifications: NotificationConfig {
                slack: SlackConfig {
                    webhook_url: env::var("SLACK_WEBHOOK_URL").ok(),
                    channel: "#alerts".to_string(),
                    username: "TUI-Patcher-Bot".to_string(),
                    rate_limit: 10, // messages per minute
                },
                email: EmailConfig {
                    smtp_server: "localhost".to_string(),
                    smtp_port: 587,
                    username: "noreply@tuipatcher.com".to_string(),
                    password: env::var("EMAIL_PASSWORD").unwrap_or_default(),
                    from_address: "noreply@tuipatcher.com".to_string(),
                },
                webhooks: vec![],
            },
            security: SecurityConfig {
                jwt_secret: env::var("JWT_SECRET")
                    .unwrap_or_else(|_| "super-secret-jwt-key".to_string()),
                api_keys: vec![],
                rate_limit: RateLimitConfig {
                    requests_per_minute: 60,
                    burst_size: 10,
                    ban_duration: 300, // 5 minutes
                },
                cors_origins: vec![
                    "http://localhost:3000".to_string(),
                    "https://tuipatcher.com".to_string(),
                ],
            },
        }
    }
}
```

## Application Configuration File (app.toml)

```toml
[server]
host = "0.0.0.0"
port = 8000
workers = 4
request_timeout = 30
max_request_size = 104857600  # 100MB

[database]
url = "postgresql://tui_patcher:password@localhost:5432/tui_patcher"
max_connections = 10
min_connections = 2
connect_timeout = 30
idle_timeout = 600

[telemetry]
service_name = "tui-patcher-agent"
service_version = "1.0.0"
otlp_endpoint = "http://localhost:4317"
sampling_ratio = 0.1
jaeger_endpoint = "http://localhost:14268"
prometheus_endpoint = "http://localhost:9090"

[queue]
max_concurrent_jobs = 10
job_timeout = 300
retry_attempts = 3
retry_delay = 5
dead_letter_queue = true

[patching]
workspace_dir = "/tmp/tui-patcher/workspace"
temp_dir = "/tmp/tui-patcher/temp"
max_apk_size = 209715200  # 200MB
bundletool_path = "/usr/local/bin/bundletool.jar"
aapt_path = "/usr/local/bin/aapt"
zipalign_path = "/usr/local/bin/zipalign"
supported_formats = ["apk", "aab"]

[plugins]
plugin_dir = "plugins"
marketplace_url = "https://marketplace.tuipatcher.com"
auto_update = false
sandbox_memory_limit = 67108864  # 64MB
execution_timeout = 30

[ai]
tflite_model_path = "models/patch_analyzer.tflite"
gemma_model_path = "models/gemma-2b"
cuda_enabled = false
batch_size = 8

[notifications.slack]
channel = "#alerts"
username = "TUI-Patcher-Bot"
rate_limit = 10

[notifications.email]
smtp_server = "localhost"
smtp_port = 587
username = "noreply@tuipatcher.com"
from_address = "noreply@tuipatcher.com"

[security.rate_limit]
requests_per_minute = 60
burst_size = 10
ban_duration = 300

[security]
cors_origins = ["http://localhost:3000", "https://tuipatcher.com"]
```