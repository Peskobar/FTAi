# Backend Routes Module

```rust
//! HTTP route handlers for TUI-Patcher-Agent API
//! 
//! This module contains all REST API endpoints for the patching service.

pub mod health;
pub mod enqueue;
pub mod status; 
pub mod metrics;
pub mod sbom;
pub mod queue;
pub mod plugins;
pub mod ai;

use axum::{
    extract::{Path, Query, State},
    http::StatusCode,
    response::{IntoResponse, Json},
};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use uuid::Uuid;

use crate::{AppState, error::AppError};

/// Standard API response wrapper
#[derive(Serialize)]
pub struct ApiResponse<T> {
    pub success: bool,
    pub data: Option<T>,
    pub error: Option<String>,
    pub timestamp: chrono::DateTime<chrono::Utc>,
    pub trace_id: Option<String>,
}

impl<T> ApiResponse<T> {
    pub fn success(data: T) -> Self {
        Self {
            success: true,
            data: Some(data),
            error: None,
            timestamp: chrono::Utc::now(),
            trace_id: None, // Will be filled by middleware
        }
    }

    pub fn error(message: String) -> ApiResponse<()> {
        ApiResponse {
            success: false,
            data: None,
            error: Some(message),
            timestamp: chrono::Utc::now(),
            trace_id: None,
        }
    }
}

impl<T: Serialize> IntoResponse for ApiResponse<T> {
    fn into_response(self) -> axum::response::Response {
        Json(self).into_response()
    }
}

/// Query parameters for pagination
#[derive(Deserialize)]
pub struct PaginationQuery {
    pub page: Option<u32>,
    pub limit: Option<u32>,
}

impl Default for PaginationQuery {
    fn default() -> Self {
        Self {
            page: Some(1),
            limit: Some(20),
        }
    }
}

/// Health check endpoints
pub mod health {
    use super::*;
    use serde_json::json;

    /// Basic health check
    pub async fn health_check(State(state): State<AppState>) -> impl IntoResponse {
        let health_status = state.health.get_status().await;
        
        let response = json!({
            "status": "healthy",
            "version": env!("CARGO_PKG_VERSION"),
            "timestamp": chrono::Utc::now(),
            "uptime": health_status.uptime,
            "checks": health_status.checks
        });

        (StatusCode::OK, Json(response))
    }

    /// Kubernetes readiness probe
    pub async fn readiness_check(State(state): State<AppState>) -> impl IntoResponse {
        if state.health.is_ready().await {
            (StatusCode::OK, Json(json!({"status": "ready"})))
        } else {
            (StatusCode::SERVICE_UNAVAILABLE, Json(json!({"status": "not_ready"})))
        }
    }

    /// Kubernetes liveness probe
    pub async fn liveness_check(State(state): State<AppState>) -> impl IntoResponse {
        if state.health.is_alive().await {
            (StatusCode::OK, Json(json!({"status": "alive"})))
        } else {
            (StatusCode::SERVICE_UNAVAILABLE, Json(json!({"status": "dead"})))
        }
    }
}

/// Enqueue endpoint for patch jobs
pub mod enqueue {
    use super::*;
    use axum::extract::Multipart;
    use crate::patching::types::{PatchRequest, PatchJob};

    /// Handle APK/AAB upload and enqueue for patching
    pub async fn handle_enqueue(
        State(state): State<AppState>,
        mut multipart: Multipart,
    ) -> Result<impl IntoResponse, AppError> {
        let mut file_data: Option<Vec<u8>> = None;
        let mut filename: Option<String> = None;
        let mut patch_types: Vec<String> = vec![];

        // Process multipart form data
        while let Some(field) = multipart.next_field().await? {
            match field.name() {
                Some("file") => {
                    filename = field.file_name().map(|s| s.to_string());
                    file_data = Some(field.bytes().await?.to_vec());
                }
                Some("patch_types") => {
                    let types = field.text().await?;
                    patch_types = types.split(',').map(|s| s.trim().to_string()).collect();
                }
                _ => {}
            }
        }

        // Validate file data
        let file_data = file_data.ok_or(AppError::BadRequest("No file provided".to_string()))?;
        let filename = filename.ok_or(AppError::BadRequest("No filename provided".to_string()))?;

        // Validate file format
        let file_extension = filename.split('.').last()
            .ok_or(AppError::BadRequest("Invalid filename".to_string()))?;
        
        if !state.config.patching.supported_formats.contains(&file_extension.to_lowercase()) {
            return Err(AppError::BadRequest(
                format!("Unsupported file format: {}", file_extension)
            ));
        }

        // Check file size
        if file_data.len() > state.config.patching.max_apk_size {
            return Err(AppError::BadRequest("File too large".to_string()));
        }

        // Create patch request
        let patch_request = PatchRequest {
            id: Uuid::new_v4(),
            filename,
            file_data,
            patch_types: if patch_types.is_empty() { 
                vec!["security".to_string(), "performance".to_string()] 
            } else { 
                patch_types 
            },
            priority: 0,
            metadata: HashMap::new(),
        };

        // Enqueue the job
        let job = state.queue.enqueue(patch_request).await?;

        // Record metrics
        state.telemetry.record_patch_operation(true, "enqueue");

        Ok(ApiResponse::success(serde_json::json!({
            "job_id": job.id,
            "status": "queued",
            "estimated_completion": job.estimated_completion,
            "position_in_queue": state.queue.get_position(&job.id).await?
        })))
    }
}

/// Status endpoint for job tracking
pub mod status {
    use super::*;
    use crate::patching::types::JobStatus;

    /// Get job status by ID
    pub async fn handle_status(
        State(state): State<AppState>,
        Path(job_id): Path<Uuid>,
    ) -> Result<impl IntoResponse, AppError> {
        let job_status = state.queue.get_job_status(&job_id).await?;

        let response = match job_status {
            Some(status) => ApiResponse::success(serde_json::json!({
                "job_id": job_id,
                "status": status.status,
                "progress": status.progress,
                "created_at": status.created_at,
                "updated_at": status.updated_at,
                "completed_at": status.completed_at,
                "error_message": status.error_message,
                "result_url": status.result_url,
                "logs": status.logs
            })),
            None => return Err(AppError::NotFound("Job not found".to_string())),
        };

        Ok(response)
    }
}

/// Metrics endpoint for monitoring
pub mod metrics {
    use super::*;
    use metrics_exporter_prometheus::PrometheusHandle;

    /// Export Prometheus metrics
    pub async fn handle_metrics(
        State(state): State<AppState>,
    ) -> Result<impl IntoResponse, AppError> {
        // Get current queue metrics
        let queue_size = state.queue.size().await;
        state.telemetry.record_queue_size(queue_size);

        // Export metrics in Prometheus format
        let metrics = state.telemetry.metrics();
        
        let response = serde_json::json!({
            "queue_size": queue_size,
            "active_jobs": state.queue.active_jobs().await,
            "completed_jobs_today": state.queue.completed_jobs_today().await,
            "success_rate_24h": state.queue.success_rate_24h().await,
            "avg_processing_time": state.queue.avg_processing_time().await,
        });

        Ok(ApiResponse::success(response))
    }
}

/// SBOM endpoint for supply chain compliance
pub mod sbom {
    use super::*;
    use std::fs;

    /// Serve the Software Bill of Materials
    pub async fn handle_sbom(
        State(_state): State<AppState>,
    ) -> Result<impl IntoResponse, AppError> {
        // Read SBOM file generated during build
        let sbom_content = fs::read_to_string("cyclonedx.json")
            .map_err(|_| AppError::InternalError("SBOM not available".to_string()))?;

        let sbom: serde_json::Value = serde_json::from_str(&sbom_content)
            .map_err(|_| AppError::InternalError("Invalid SBOM format".to_string()))?;

        Ok((
            StatusCode::OK,
            [("Content-Type", "application/json")],
            Json(sbom),
        ))
    }
}

/// Queue management endpoints
pub mod queue {
    use super::*;

    /// Get current queue status
    pub async fn get_queue_status(
        State(state): State<AppState>,
        Query(pagination): Query<PaginationQuery>,
    ) -> Result<impl IntoResponse, AppError> {
        let page = pagination.page.unwrap_or(1);
        let limit = pagination.limit.unwrap_or(20);
        
        let queue_info = state.queue.get_queue_info(page, limit).await?;

        Ok(ApiResponse::success(queue_info))
    }

    /// Cancel a specific job
    pub async fn cancel_job(
        State(state): State<AppState>,
        Path(job_id): Path<Uuid>,
    ) -> Result<impl IntoResponse, AppError> {
        let cancelled = state.queue.cancel_job(&job_id).await?;

        if cancelled {
            Ok(ApiResponse::success(serde_json::json!({
                "job_id": job_id,
                "status": "cancelled"
            })))
        } else {
            Err(AppError::BadRequest("Job cannot be cancelled".to_string()))
        }
    }
}

/// Plugin marketplace endpoints
pub mod plugins {
    use super::*;

    /// List available plugins
    pub async fn list_plugins(
        State(state): State<AppState>,
        Query(pagination): Query<PaginationQuery>,
    ) -> Result<impl IntoResponse, AppError> {
        let page = pagination.page.unwrap_or(1);
        let limit = pagination.limit.unwrap_or(20);
        
        let plugins = state.plugin_manager.list_plugins(page, limit).await?;

        Ok(ApiResponse::success(plugins))
    }

    /// Get plugin details
    pub async fn get_plugin(
        State(state): State<AppState>,
        Path(plugin_id): Path<String>,
    ) -> Result<impl IntoResponse, AppError> {
        let plugin = state.plugin_manager.get_plugin(&plugin_id).await?;

        match plugin {
            Some(plugin_info) => Ok(ApiResponse::success(plugin_info)),
            None => Err(AppError::NotFound("Plugin not found".to_string())),
        }
    }

    /// Install a plugin
    pub async fn install_plugin(
        State(state): State<AppState>,
        Path(plugin_id): Path<String>,
    ) -> Result<impl IntoResponse, AppError> {
        let installation = state.plugin_manager.install_plugin(&plugin_id).await?;

        Ok(ApiResponse::success(serde_json::json!({
            "plugin_id": plugin_id,
            "status": "installed",
            "version": installation.version,
            "installed_at": installation.installed_at
        })))
    }
}

/// AI service endpoints
pub mod ai {
    use super::*;
    use axum::extract::Multipart;

    /// Analyze APK with AI
    pub async fn analyze_apk(
        State(state): State<AppState>,
        mut multipart: Multipart,
    ) -> Result<impl IntoResponse, AppError> {
        let mut file_data: Option<Vec<u8>> = None;
        
        while let Some(field) = multipart.next_field().await? {
            if field.name() == Some("file") {
                file_data = Some(field.bytes().await?.to_vec());
                break;
            }
        }

        let file_data = file_data.ok_or(AppError::BadRequest("No file provided".to_string()))?;

        // Run AI analysis
        let analysis = state.ai_service.analyze_apk(&file_data).await?;

        Ok(ApiResponse::success(analysis))
    }

    /// Get AI patch suggestions
    pub async fn suggest_patches(
        State(state): State<AppState>,
        Json(request): Json<serde_json::Value>,
    ) -> Result<impl IntoResponse, AppError> {
        let suggestions = state.ai_service.suggest_patches(request).await?;

        Ok(ApiResponse::success(suggestions))
    }
}
```