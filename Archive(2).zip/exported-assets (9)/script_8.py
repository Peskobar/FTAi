# scripts/health-check.sh - Comprehensive health check script  
health_check_script_content = """#!/bin/bash
# SmartFix Core - Health Check Script

set -e

# Colors
RED='\\033[0;31m'
GREEN='\\033[0;32m'
YELLOW='\\033[1;33m'
BLUE='\\033[0;34m'
CYAN='\\033[0;36m'
NC='\\033[0m'

# Configuration
BACKEND_URL="http://localhost:8000"
FRONTEND_URL="http://localhost:3000"
TIMEOUT=10
RETRY_COUNT=3

echo -e "${CYAN}🏥 SmartFix Core - Health Check${NC}"
echo -e "${BLUE}===============================${NC}"

# Function to check HTTP endpoint
check_endpoint() {
    local name=$1
    local url=$2
    local expected_status=${3:-200}
    
    echo -n -e "${BLUE}Checking $name... ${NC}"
    
    for i in $(seq 1 $RETRY_COUNT); do
        if response=$(curl -s -o /dev/null -w "%{http_code}" --max-time $TIMEOUT "$url" 2>/dev/null); then
            if [[ "$response" == "$expected_status" ]]; then
                echo -e "${GREEN}✅ OK ($response)${NC}"
                return 0
            fi
        fi
        
        if [[ $i -lt $RETRY_COUNT ]]; then
            echo -n -e "${YELLOW}⏳ Retry $i... ${NC}"
            sleep 2
        fi
    done
    
    echo -e "${RED}❌ FAIL${NC}"
    return 1
}

# Function to check database connection
check_database() {
    echo -n -e "${BLUE}Checking Database... ${NC}"
    
    if docker-compose exec -T postgres pg_isready -U smartfix -d smartfix_core >/dev/null 2>&1; then
        echo -e "${GREEN}✅ OK${NC}"
        return 0
    else
        echo -e "${RED}❌ FAIL${NC}"
        return 1
    fi
}

# Function to check Redis connection
check_redis() {
    echo -n -e "${BLUE}Checking Redis... ${NC}"
    
    if docker-compose exec -T redis redis-cli ping >/dev/null 2>&1; then
        echo -e "${GREEN}✅ OK${NC}"
        return 0
    else
        echo -e "${RED}❌ FAIL${NC}"
        return 1
    fi
}

# Function to check container status
check_containers() {
    echo -e "${BLUE}Container Status:${NC}"
    
    containers=(
        "smartfix-backend"
        "smartfix-frontend" 
        "smartfix-postgres"
        "smartfix-redis"
        "smartfix-celery-worker"
    )
    
    for container in "${containers[@]}"; do
        if docker ps --format "table {{.Names}}" | grep -q "$container"; then
            status=$(docker inspect --format='{{.State.Health.Status}}' "$container" 2>/dev/null || echo "unknown")
            if [[ "$status" == "healthy" ]] || [[ "$status" == "unknown" ]]; then
                echo -e "${GREEN}  ✅ $container: running${NC}"
            else
                echo -e "${YELLOW}  ⚠️  $container: $status${NC}"
            fi
        else
            echo -e "${RED}  ❌ $container: not running${NC}"
        fi
    done
}

# Function to check API endpoints
check_api_endpoints() {
    echo -e "${BLUE}API Endpoints:${NC}"
    
    endpoints=(
        "Health Check:$BACKEND_URL/health"
        "API Docs:$BACKEND_URL/docs"  
        "OpenAPI Spec:$BACKEND_URL/openapi.json"
        "Metrics:$BACKEND_URL/metrics"
    )
    
    for endpoint in "${endpoints[@]}"; do
        name=${endpoint%:*}
        url=${endpoint#*:}
        check_endpoint "$name" "$url"
    done
}

# Function to check frontend
check_frontend() {
    echo -e "${BLUE}Frontend:${NC}"
    check_endpoint "Main Page" "$FRONTEND_URL"
}

# Function to check monitoring stack
check_monitoring() {
    echo -e "${BLUE}Monitoring Stack:${NC}"
    
    monitoring_endpoints=(
        "Prometheus:http://localhost:9090/-/healthy"
        "Grafana:http://localhost:3001/api/health"
        "Jaeger:http://localhost:16686"
    )
    
    for endpoint in "${monitoring_endpoints[@]}"; do
        name=${endpoint%:*}
        url=${endpoint#*:}
        check_endpoint "$name" "$url" || true  # Don't fail if monitoring is down
    done
}

# Function to check disk space
check_disk_space() {
    echo -e "${BLUE}System Resources:${NC}"
    
    # Check disk space
    disk_usage=$(df -h . | awk 'NR==2 {print $5}' | sed 's/%//')
    if [[ $disk_usage -lt 90 ]]; then
        echo -e "${GREEN}  ✅ Disk usage: $disk_usage%${NC}"
    else
        echo -e "${RED}  ❌ Disk usage: $disk_usage% (>90%)${NC}"
    fi
    
    # Check Docker system usage
    docker_usage=$(docker system df --format "table {{.Type}}\\t{{.Size}}" | grep "Images\\|Containers\\|Local Volumes" || true)
    if [[ -n "$docker_usage" ]]; then
        echo -e "${BLUE}  Docker Resources:${NC}"
        echo "$docker_usage" | sed 's/^/    /'
    fi
}

# Function to run performance test
check_performance() {
    echo -e "${BLUE}Performance Test:${NC}"
    
    echo -n -e "${BLUE}  API Response Time... ${NC}"
    if command -v curl &> /dev/null; then
        response_time=$(curl -s -o /dev/null -w "%{time_total}" --max-time $TIMEOUT "$BACKEND_URL/health" 2>/dev/null || echo "timeout")
        
        if [[ "$response_time" != "timeout" ]]; then
            response_ms=$(echo "$response_time * 1000" | bc 2>/dev/null || echo "$response_time")
            if (( $(echo "$response_time < 1.0" | bc -l 2>/dev/null || echo 0) )); then
                echo -e "${GREEN}✅ ${response_ms}ms${NC}"
            else
                echo -e "${YELLOW}⚠️  ${response_ms}ms (slow)${NC}"
            fi
        else
            echo -e "${RED}❌ Timeout${NC}"
        fi
    else
        echo -e "${YELLOW}⚠️  curl not available${NC}"
    fi
}

# Function to check logs for errors
check_logs() {
    echo -e "${BLUE}Recent Logs:${NC}"
    
    # Check backend logs for errors
    backend_errors=$(docker-compose logs --tail=100 backend 2>/dev/null | grep -i "error\\|exception\\|critical" | wc -l)
    if [[ $backend_errors -eq 0 ]]; then
        echo -e "${GREEN}  ✅ Backend: No recent errors${NC}"
    else
        echo -e "${YELLOW}  ⚠️  Backend: $backend_errors errors in recent logs${NC}"
    fi
    
    # Check frontend logs for errors  
    frontend_errors=$(docker-compose logs --tail=100 frontend 2>/dev/null | grep -i "error\\|failed" | wc -l)
    if [[ $frontend_errors -eq 0 ]]; then
        echo -e "${GREEN}  ✅ Frontend: No recent errors${NC}"
    else
        echo -e "${YELLOW}  ⚠️  Frontend: $frontend_errors errors in recent logs${NC}"
    fi
}

# Main health check function
main() {
    local exit_code=0
    
    echo -e "${CYAN}Starting comprehensive health check...${NC}"
    echo
    
    # Core service checks
    check_containers || exit_code=1
    echo
    
    check_database || exit_code=1
    check_redis || exit_code=1
    echo
    
    check_api_endpoints || exit_code=1
    echo
    
    check_frontend || exit_code=1
    echo
    
    # Optional monitoring checks (don't fail main check)
    check_monitoring
    echo
    
    # System checks
    check_disk_space
    echo
    
    check_performance
    echo
    
    check_logs
    echo
    
    # Summary
    if [[ $exit_code -eq 0 ]]; then
        echo -e "${GREEN}🎉 Health check passed! All core services are healthy.${NC}"
    else
        echo -e "${RED}❌ Health check failed! Some services need attention.${NC}"
    fi
    
    echo -e "${BLUE}===============================${NC}"
    echo -e "${CYAN}Timestamp: $(date)${NC}"
    
    exit $exit_code
}

# Run main function
main "$@"
"""

print("📄 scripts/health-check.sh - Generated!")  
print(f"Length: {len(health_check_script_content)} characters")
print("✅ Features: API checks, database/Redis status, performance test, log analysis")
print()