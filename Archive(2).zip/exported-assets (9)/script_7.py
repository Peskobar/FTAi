# scripts/setup.sh - Initial setup script
setup_script_content = """#!/bin/bash
# SmartFix Core - Development Environment Setup Script

set -e  # Exit on any error

# Colors for output
RED='\\033[0;31m'
GREEN='\\033[0;32m'
YELLOW='\\033[1;33m'
BLUE='\\033[0;34m'
CYAN='\\033[0;36m'
NC='\\033[0m' # No Color

# Configuration
PROJECT_NAME="SmartFix Core"
REQUIRED_DOCKER_VERSION="20.10.0"
REQUIRED_DOCKER_COMPOSE_VERSION="2.0.0"

echo -e "${CYAN}🚀 ${PROJECT_NAME} - Development Setup${NC}"
echo -e "${BLUE}=====================================${NC}"

# Check if running on macOS, Linux, or WSL
detect_os() {
    if [[ "$OSTYPE" == "darwin"* ]]; then
        OS="macos"
    elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
        if grep -qi microsoft /proc/version; then
            OS="wsl"
        else
            OS="linux"
        fi
    else
        OS="unknown"
    fi
    echo -e "${BLUE}Detected OS: ${YELLOW}$OS${NC}"
}

# Function to compare versions
version_compare() {
    if [[ $1 == $2 ]]
    then
        return 0
    fi
    local IFS=.
    local i ver1=($1) ver2=($2)
    for ((i=${#ver1[@]}; i<${#ver2[@]}; i++))
    do
        ver1[i]=0
    done
    for ((i=0; i<${#ver1[@]}; i++))
    do
        if [[ -z ${ver2[i]} ]]
        then
            ver2[i]=0
        fi
        if ((10#${ver1[i]} > 10#${ver2[i]}))
        then
            return 1
        fi
        if ((10#${ver1[i]} < 10#${ver2[i]}))
        then
            return 2
        fi
    done
    return 0
}

# Check Docker installation
check_docker() {
    echo -e "${CYAN}🐳 Checking Docker installation...${NC}"
    
    if ! command -v docker &> /dev/null; then
        echo -e "${RED}❌ Docker is not installed!${NC}"
        echo -e "${YELLOW}Please install Docker Desktop or Docker Engine${NC}"
        echo -e "${BLUE}Visit: https://docs.docker.com/get-docker/${NC}"
        exit 1
    fi

    # Check Docker version
    DOCKER_VERSION=$(docker --version | grep -oE '[0-9]+\\.[0-9]+\\.[0-9]+')
    echo -e "${GREEN}✅ Docker version: $DOCKER_VERSION${NC}"
    
    # Check if Docker is running
    if ! docker info &> /dev/null; then
        echo -e "${RED}❌ Docker daemon is not running!${NC}"
        echo -e "${YELLOW}Please start Docker Desktop or Docker service${NC}"
        exit 1
    fi
}

# Check Docker Compose installation
check_docker_compose() {
    echo -e "${CYAN}🐙 Checking Docker Compose installation...${NC}"
    
    if ! command -v docker-compose &> /dev/null && ! docker compose version &> /dev/null; then
        echo -e "${RED}❌ Docker Compose is not installed!${NC}"
        echo -e "${YELLOW}Please install Docker Compose${NC}"
        exit 1
    fi

    # Try to get version from docker compose (newer) or docker-compose (legacy)
    if docker compose version &> /dev/null; then
        COMPOSE_VERSION=$(docker compose version --short)
        echo -e "${GREEN}✅ Docker Compose version: $COMPOSE_VERSION${NC}"
    else
        COMPOSE_VERSION=$(docker-compose --version | grep -oE '[0-9]+\\.[0-9]+\\.[0-9]+')
        echo -e "${GREEN}✅ Docker Compose version: $COMPOSE_VERSION${NC}"
    fi
}

# Create necessary directories
create_directories() {
    echo -e "${CYAN}📁 Creating project directories...${NC}"
    
    directories=(
        "backend/app"
        "backend/tests"
        "frontend/src"
        "models"
        "plugins/core"
        "plugins/external"
        "observability/monitoring/grafana/dashboards"
        "observability/otel"
        "k8s"
        "helm/smartfix-core/templates"
        "scripts"
        "docs"
        "logs"
        "uploads"
        "backups"
    )
    
    for dir in "${directories[@]}"; do
        mkdir -p "$dir"
        echo -e "${GREEN}  ✅ Created: $dir${NC}"
    done
}

# Setup environment files
setup_environment() {
    echo -e "${CYAN}🔧 Setting up environment files...${NC}"
    
    if [[ ! -f .env ]]; then
        cp .env.example .env
        echo -e "${GREEN}✅ Created .env from .env.example${NC}"
        echo -e "${YELLOW}⚠️  Please edit .env with your configuration${NC}"
    else
        echo -e "${YELLOW}⚠️  .env already exists, skipping...${NC}"
    fi
    
    if [[ ! -f .env.prod ]]; then
        cp .env.prod.example .env.prod
        echo -e "${GREEN}✅ Created .env.prod from .env.prod.example${NC}"
    fi
}

# Generate dummy models (if not exists)
setup_dummy_models() {
    echo -e "${CYAN}🤖 Setting up dummy AI models...${NC}"
    
    mkdir -p models
    
    # Create dummy TensorFlow Lite model (placeholder)
    if [[ ! -f models/apk_analyzer.tflite ]]; then
        echo "# Dummy TensorFlow Lite model - replace with actual model" > models/apk_analyzer.tflite
        echo -e "${GREEN}✅ Created dummy APK analyzer model${NC}"
    fi
    
    if [[ ! -f models/autoscaler_lstm.tflite ]]; then
        echo "# Dummy LSTM model - replace with actual model" > models/autoscaler_lstm.tflite
        echo -e "${GREEN}✅ Created dummy LSTM autoscaler model${NC}"
    fi
    
    # Create model metadata
    cat > models/model_metadata.json << EOF
{
    "apk_analyzer": {
        "version": "1.0.0",
        "size_mb": 8.5,
        "input_shape": [1, 224, 224, 3],
        "output_classes": 50,
        "accuracy": 0.92
    },
    "autoscaler_lstm": {
        "version": "1.0.0", 
        "size_mb": 2.3,
        "sequence_length": 168,
        "features": 8,
        "prediction_horizon": 15
    }
}
EOF
    echo -e "${GREEN}✅ Created model metadata${NC}"
}

# Setup Git hooks (if Git repository exists)
setup_git_hooks() {
    if [[ -d .git ]]; then
        echo -e "${CYAN}🔀 Setting up Git hooks...${NC}"
        
        # Pre-commit hook for code quality
        cat > .git/hooks/pre-commit << 'EOF'
#!/bin/bash
# Run linting before commit
echo "Running pre-commit checks..."

# Check if we're in a Docker environment or local
if command -v docker &> /dev/null && docker-compose ps | grep -q "smartfix-backend"; then
    # Run in Docker
    docker-compose exec -T backend black --check app/ || exit 1
    docker-compose exec -T backend isort --check-only app/ || exit 1
    docker-compose exec -T frontend npm run lint || exit 1
else
    echo "Docker environment not running - skipping checks"
fi

echo "Pre-commit checks passed!"
EOF
        
        chmod +x .git/hooks/pre-commit
        echo -e "${GREEN}✅ Git pre-commit hook installed${NC}"
    else
        echo -e "${YELLOW}⚠️  Not a Git repository - skipping Git hooks${NC}"
    fi
}

# Pull required Docker images
pull_docker_images() {
    echo -e "${CYAN}📥 Pulling required Docker images...${NC}"
    
    images=(
        "postgres:15-alpine"
        "redis:7-alpine"
        "python:3.11-slim"
        "node:20-alpine"
        "nginx:1.25-alpine"
        "otel/opentelemetry-collector-contrib:0.91.0"
        "prom/prometheus:v2.47.0"
        "grafana/grafana:10.2.0"
        "jaegertracing/all-in-one:1.51"
    )
    
    for image in "${images[@]}"; do
        echo -e "${BLUE}Pulling $image...${NC}"
        docker pull "$image" &
    done
    
    wait
    echo -e "${GREEN}✅ All images pulled successfully${NC}"
}

# Verify setup
verify_setup() {
    echo -e "${CYAN}✅ Verifying setup...${NC}"
    
    # Check if all required files exist
    required_files=(
        "docker-compose.yml"
        "Dockerfile.backend"
        "Dockerfile.frontend"
        "Makefile"
        ".env"
    )
    
    for file in "${required_files[@]}"; do
        if [[ -f "$file" ]]; then
            echo -e "${GREEN}  ✅ $file${NC}"
        else
            echo -e "${RED}  ❌ $file (missing)${NC}"
        fi
    done
    
    echo -e "${GREEN}✅ Setup verification completed${NC}"
}

# Main setup function
main() {
    echo -e "${BLUE}Starting ${PROJECT_NAME} development setup...${NC}"
    
    detect_os
    check_docker
    check_docker_compose
    create_directories
    setup_environment
    setup_dummy_models
    setup_git_hooks
    pull_docker_images
    verify_setup
    
    echo -e "${GREEN}🎉 Setup completed successfully!${NC}"
    echo -e "${BLUE}=====================================${NC}"
    echo -e "${CYAN}Next steps:${NC}"
    echo -e "${YELLOW}1. Edit .env file with your configuration${NC}"
    echo -e "${YELLOW}2. Run: make quick-start${NC}"
    echo -e "${YELLOW}3. Access: http://localhost:3000 (Frontend)${NC}"
    echo -e "${YELLOW}4. Access: http://localhost:8000/docs (API Docs)${NC}"
    echo -e "${BLUE}=====================================${NC}"
}

# Run main function
main "$@"
"""

print("📄 scripts/setup.sh - Generated!")
print(f"Length: {len(setup_script_content)} characters")
print("✅ Features: OS detection, Docker verification, directory setup, Git hooks")
print()