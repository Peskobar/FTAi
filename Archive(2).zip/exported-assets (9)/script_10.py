# pyproject.toml - Modern Python project configuration
pyproject_content = """[build-system]
requires = ["setuptools>=65.0", "wheel"]
build-backend = "setuptools.build_meta"

[project]
name = "smartfix-core"
version = "1.0.0"
description = "AI-powered Android patch management system with enterprise observability"
readme = "README.md"
license = { text = "MIT" }
authors = [
    { name = "SmartFix Team", email = "team@smartfix-core.dev" }
]
maintainers = [
    { name = "SmartFix Team", email = "team@smartfix-core.dev" }
]
keywords = [
    "android",
    "patch-management", 
    "ai",
    "tensorflow-lite",
    "fastapi",
    "observability",
    "microservices",
    "enterprise"
]
classifiers = [
    "Development Status :: 5 - Production/Stable",
    "Intended Audience :: Developers",
    "Intended Audience :: System Administrators",
    "License :: OSI Approved :: MIT License",
    "Operating System :: OS Independent",
    "Programming Language :: Python :: 3",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
    "Framework :: FastAPI",
    "Framework :: AsyncIO",
    "Topic :: Software Development :: Libraries :: Application Frameworks",
    "Topic :: System :: Software Distribution",
    "Topic :: System :: Monitoring",
    "Typing :: Typed",
]
requires-python = ">=3.11"
dependencies = [
    # Web Framework
    "fastapi==0.104.1",
    "uvicorn[standard]==0.24.0",
    "gunicorn==21.2.0",
    
    # Database & ORM
    "sqlalchemy==2.0.23",
    "alembic==1.12.1",
    "asyncpg==0.29.0",
    "psycopg2-binary==2.9.9",
    
    # Task Queue & Caching
    "celery==5.3.4",
    "redis==5.0.1",
    "kombu==5.3.4",
    
    # Authentication & Security  
    "python-jose[cryptography]==3.3.0",
    "passlib[bcrypt]==1.7.4",
    "python-multipart==0.0.6",
    "cryptography==41.0.8",
    
    # AI & ML
    "tensorflow==2.15.0",
    "tensorflow-lite==2.15.0",
    "scikit-learn==1.3.2",
    "numpy==1.24.4",
    "pandas==2.1.4",
    "transformers==4.36.2",
    
    # HTTP Client & Async
    "httpx==0.25.2",
    "aiohttp==3.9.1",
    "aiofiles==23.2.1",
    "asyncio-throttle==1.0.2",
    
    # Observability & Monitoring
    "opentelemetry-api==1.21.0",
    "opentelemetry-sdk==1.21.0",
    "opentelemetry-exporter-otlp==1.21.0",
    "opentelemetry-instrumentation-fastapi==0.42b0",
    "opentelemetry-instrumentation-sqlalchemy==0.42b0",
    "opentelemetry-instrumentation-redis==0.42b0",
    "opentelemetry-instrumentation-httpx==0.42b0",
    "prometheus-client==0.19.0",
    "structlog==23.2.0",
    
    # Configuration & Environment
    "pydantic==2.5.1",
    "pydantic-settings==2.1.0",
    "python-dotenv==1.0.0",
    "dynaconf==3.2.4",
    
    # Utilities
    "click==8.1.7",
    "rich==13.7.0",
    "typer==0.9.0",
    "jinja2==3.1.2",
    "markupsafe==2.1.3",
    
    # File Processing
    "pillow==10.1.0",
    "python-magic==0.4.27",
    "chardet==5.2.0",
    
    # Validation & Serialization
    "marshmallow==3.20.2",
    "cerberus==1.3.5",
    
    # Networking
    "urllib3==2.1.0",
    "requests==2.31.0",
    
    # Plugin System
    "pluggy==1.3.0",
    "importlib-metadata==6.8.0",
    
    # APK Processing (Android)
    "python-apk==0.1.1",
    "androguard==4.1.2",
]

[project.optional-dependencies]
dev = [
    # Testing
    "pytest==7.4.3",
    "pytest-asyncio==0.21.1", 
    "pytest-cov==4.1.0",
    "pytest-mock==3.12.0",
    "pytest-xdist==3.5.0",
    "pytest-benchmark==4.0.0",
    "factory-boy==3.3.0",
    "faker==20.1.0",
    
    # Code Quality
    "black==23.11.0",
    "isort==5.12.0",
    "flake8==6.1.0",
    "mypy==1.7.1",
    "pylint==3.0.3",
    "bandit==1.7.5",
    "safety==2.3.5",
    "pre-commit==3.6.0",
    
    # Documentation
    "sphinx==7.2.6",
    "sphinx-rtd-theme==1.3.0",
    "sphinx-autodoc-typehints==1.25.2",
    "myst-parser==2.0.0",
    
    # Development Tools
    "ipython==8.18.1",
    "ipdb==0.13.13",
    "watchdog==3.0.0",
    "python-dotenv==1.0.0",
]

test = [
    "pytest==7.4.3",
    "pytest-asyncio==0.21.1",
    "pytest-cov==4.1.0", 
    "pytest-mock==3.12.0",
    "pytest-xdist==3.5.0",
    "httpx==0.25.2",
    "factory-boy==3.3.0",
    "faker==20.1.0",
]

prod = [
    "gunicorn==21.2.0",
    "gevent==23.9.1",
    "psutil==5.9.6",
]

monitoring = [
    "grafana-client==3.5.0",
    "prometheus-client==0.19.0",
    "jaeger-client==4.8.0",
]

[project.urls]
Homepage = "https://github.com/smartfix-core/smartfix-core"
Documentation = "https://docs.smartfix-core.dev"
Repository = "https://github.com/smartfix-core/smartfix-core.git"
Changelog = "https://github.com/smartfix-core/smartfix-core/blob/main/CHANGELOG.md"
"Bug Tracker" = "https://github.com/smartfix-core/smartfix-core/issues"

[project.scripts]
smartfix = "smartfix_core.cli:main"
smartfix-server = "smartfix_core.server:main"
smartfix-worker = "smartfix_core.worker:main"
smartfix-migrate = "smartfix_core.database:migrate"

[tool.setuptools.packages.find]
where = ["backend"]
include = ["app*", "smartfix_core*"]
exclude = ["tests*", "docs*"]

[tool.setuptools.package-data]
"*" = ["*.yml", "*.yaml", "*.json", "*.sql", "*.html", "*.css", "*.js"]

#==============================================================================
# 🔧 Development Tools Configuration
#==============================================================================

[tool.black]
line-length = 100
target-version = ['py311']
include = '\\.pyi?$'
extend-exclude = '''
/(
  migrations
  | .venv
  | .env
  | node_modules
)/
'''

[tool.isort] 
profile = "black"
multi_line_output = 3
line_length = 100
known_first_party = ["app", "smartfix_core"]
known_third_party = ["fastapi", "sqlalchemy", "celery", "redis", "tensorflow"]
sections = ["FUTURE", "STDLIB", "THIRDPARTY", "FIRSTPARTY", "LOCALFOLDER"]

[tool.mypy]
python_version = "3.11"
check_untyped_defs = true
disallow_untyped_defs = true
disallow_incomplete_defs = true
disallow_untyped_decorators = true
warn_redundant_casts = true
warn_unused_ignores = true
warn_return_any = true
warn_unreachable = true
strict_equality = true
exclude = [
    "migrations/",
    "tests/",
    "build/",
    "dist/",
]

[[tool.mypy.overrides]]
module = [
    "celery.*",
    "redis.*", 
    "tensorflow.*",
    "androguard.*",
    "prometheus_client.*",
]
ignore_missing_imports = true

[tool.pytest.ini_options]
minversion = "6.0"
addopts = [
    "--cov=app",
    "--cov-report=html",
    "--cov-report=xml", 
    "--cov-report=term-missing",
    "--cov-fail-under=90",
    "--strict-markers",
    "--strict-config",
    "--disable-warnings",
]
testpaths = ["tests"]
python_files = ["test_*.py", "*_test.py"]
python_classes = ["Test*"]
python_functions = ["test_*"]
markers = [
    "slow: marks tests as slow (deselect with '-m \"not slow\"')",
    "integration: marks tests as integration tests",
    "unit: marks tests as unit tests",
    "e2e: marks tests as end-to-end tests",
    "ai: marks tests that require AI models",
    "plugins: marks tests for plugin system",
]
asyncio_mode = "auto"
filterwarnings = [
    "ignore::UserWarning",
    "ignore::DeprecationWarning",
]

[tool.coverage.run]
source = ["app", "smartfix_core"]
omit = [
    "*/tests/*",
    "*/migrations/*",
    "*/venv/*", 
    "*/__pycache__/*",
    "setup.py",
]

[tool.coverage.report]
exclude_lines = [
    "pragma: no cover",
    "def __repr__",
    "if self.debug:",
    "if settings.DEBUG",
    "raise AssertionError",
    "raise NotImplementedError", 
    "if 0:",
    "if __name__ == .__main__.:",
    "class .*\\bProtocol\\):",
    "@(abc\\.)?abstractmethod",
]

[tool.coverage.html]
directory = "htmlcov"

[tool.bandit]
exclude_dirs = ["tests", "migrations", "venv", ".venv"]
tests = ["B201", "B301", "B401", "B501", "B601", "B701"]

[tool.pylint.main]
load-plugins = [
    "pylint.extensions.code_style",
    "pylint.extensions.typing",
]
extension-pkg-whitelist = ["pydantic"]

[tool.pylint.messages_control]
disable = [
    "C0330", # Wrong hanging indentation
    "C0326", # Bad whitespace
    "R0903", # Too few public methods
    "R0913", # Too many arguments
]

[tool.pylint.format]
max-line-length = 100

[tool.pylint.design]
max-args = 8
max-locals = 20  
max-returns = 6
max-branches = 15
max-statements = 50

#==============================================================================
# 🚀 Build & Distribution
#==============================================================================

[tool.setuptools_scm]
write_to = "backend/app/_version.py"
version_scheme = "post-release"
local_scheme = "dirty-tag"

[tool.wheel]
universal = false

#==============================================================================
# 🔍 Security & Dependencies
#==============================================================================

[tool.safety]
ignore = [
    # Ignore specific vulnerabilities if needed
    # Example: 12345
]

[tool.pip-audit]
ignore-vuln = []
"""

print("📄 pyproject.toml - Generated!")
print(f"Length: {len(pyproject_content)} characters")
print("✅ Features: Modern packaging, dev tools config, testing, security, build system")
print()