# Makefile - Development and deployment commands
makefile_content = """# SmartFix Core - Development & Deployment Makefile
.PHONY: help dev prod test clean install lint format security docs deploy

# Default target
.DEFAULT_GOAL := help

# Colors for output
CYAN := \\033[0;36m
GREEN := \\033[0;32m
YELLOW := \\033[1;33m
RED := \\033[0;31m
NC := \\033[0m # No Color

# Project configuration
PROJECT_NAME := smartfix-core
DOCKER_COMPOSE_DEV := docker-compose.yml
DOCKER_COMPOSE_PROD := docker-compose.prod.yml
BACKEND_DIR := backend
FRONTEND_DIR := frontend

help: ## Show this help message
	@echo "$(CYAN)SmartFix Core - AI-Powered Patch Management$(NC)"
	@echo "$(YELLOW)Available commands:$(NC)"
	@awk 'BEGIN {FS = ":.*##"} /^[a-zA-Z_-]+:.*##/ { printf "  $(GREEN)%-15s$(NC) %s\\n", $$1, $$2 }' $(MAKEFILE_LIST)

# Development Environment
dev: ## Start development environment
	@echo "$(CYAN)🚀 Starting SmartFix Core development environment...$(NC)"
	docker-compose -f $(DOCKER_COMPOSE_DEV) up --build -d
	@echo "$(GREEN)✅ Development environment started!$(NC)"
	@echo "$(YELLOW)Frontend:$(NC) http://localhost:3000"
	@echo "$(YELLOW)Backend API:$(NC) http://localhost:8000"
	@echo "$(YELLOW)API Docs:$(NC) http://localhost:8000/docs"
	@echo "$(YELLOW)Grafana:$(NC) http://localhost:3001 (admin/admin)"
	@echo "$(YELLOW)Jaeger:$(NC) http://localhost:16686"

dev-logs: ## Follow development logs
	@docker-compose -f $(DOCKER_COMPOSE_DEV) logs -f

dev-restart: ## Restart development services
	@echo "$(CYAN)🔄 Restarting services...$(NC)"
	docker-compose -f $(DOCKER_COMPOSE_DEV) restart

dev-stop: ## Stop development environment
	@echo "$(YELLOW)🛑 Stopping development environment...$(NC)"
	docker-compose -f $(DOCKER_COMPOSE_DEV) down

# Production Environment  
prod: ## Start production environment
	@echo "$(CYAN)🏭 Starting SmartFix Core production environment...$(NC)"
	docker-compose -f $(DOCKER_COMPOSE_PROD) up --build -d
	@echo "$(GREEN)✅ Production environment started!$(NC)"

prod-logs: ## Follow production logs
	@docker-compose -f $(DOCKER_COMPOSE_PROD) logs -f

prod-stop: ## Stop production environment
	@echo "$(YELLOW)🛑 Stopping production environment...$(NC)"
	docker-compose -f $(DOCKER_COMPOSE_PROD) down

# Database Management
db-init: ## Initialize database with schema
	@echo "$(CYAN)🗄️ Initializing database...$(NC)"
	docker-compose -f $(DOCKER_COMPOSE_DEV) exec backend alembic upgrade head
	@echo "$(GREEN)✅ Database initialized!$(NC)"

db-migrate: ## Create new database migration
	@echo "$(CYAN)📝 Creating database migration...$(NC)"
	@read -p "Migration message: " message; \\
	docker-compose -f $(DOCKER_COMPOSE_DEV) exec backend alembic revision --autogenerate -m "$$message"

db-upgrade: ## Apply database migrations
	@echo "$(CYAN)⬆️ Applying database migrations...$(NC)"
	docker-compose -f $(DOCKER_COMPOSE_DEV) exec backend alembic upgrade head

db-shell: ## Access database shell
	@docker-compose -f $(DOCKER_COMPOSE_DEV) exec postgres psql -U smartfix -d smartfix_core

# Testing
test: ## Run all tests
	@echo "$(CYAN)🧪 Running all tests...$(NC)"
	$(MAKE) test-backend
	$(MAKE) test-frontend
	@echo "$(GREEN)✅ All tests completed!$(NC)"

test-backend: ## Run backend tests
	@echo "$(CYAN)🐍 Running backend tests...$(NC)"
	docker-compose -f $(DOCKER_COMPOSE_DEV) exec backend python -m pytest tests/ -v --cov=app --cov-report=html --cov-report=term-missing

test-frontend: ## Run frontend tests
	@echo "$(CYAN)⚛️ Running frontend tests...$(NC)"
	docker-compose -f $(DOCKER_COMPOSE_DEV) exec frontend npm run test

test-e2e: ## Run end-to-end tests
	@echo "$(CYAN)🎭 Running E2E tests...$(NC)"
	docker-compose -f $(DOCKER_COMPOSE_DEV) exec frontend npm run test:e2e

# Code Quality
lint: ## Run linters for all code
	@echo "$(CYAN)🔍 Running linters...$(NC)"
	$(MAKE) lint-backend
	$(MAKE) lint-frontend

lint-backend: ## Lint backend code
	@echo "$(CYAN)🐍 Linting backend code...$(NC)"
	docker-compose -f $(DOCKER_COMPOSE_DEV) exec backend black --check .
	docker-compose -f $(DOCKER_COMPOSE_DEV) exec backend isort --check-only .
	docker-compose -f $(DOCKER_COMPOSE_DEV) exec backend flake8 .
	docker-compose -f $(DOCKER_COMPOSE_DEV) exec backend mypy .

lint-frontend: ## Lint frontend code
	@echo "$(CYAN)⚛️ Linting frontend code...$(NC)"
	docker-compose -f $(DOCKER_COMPOSE_DEV) exec frontend npm run lint
	docker-compose -f $(DOCKER_COMPOSE_DEV) exec frontend npm run type-check

format: ## Format all code
	@echo "$(CYAN)💅 Formatting code...$(NC)"
	docker-compose -f $(DOCKER_COMPOSE_DEV) exec backend black .
	docker-compose -f $(DOCKER_COMPOSE_DEV) exec backend isort .
	docker-compose -f $(DOCKER_COMPOSE_DEV) exec frontend npm run format

security: ## Run security scans
	@echo "$(CYAN)🔒 Running security scans...$(NC)"
	docker-compose -f $(DOCKER_COMPOSE_DEV) exec backend bandit -r app/
	docker-compose -f $(DOCKER_COMPOSE_DEV) exec backend safety check
	docker-compose -f $(DOCKER_COMPOSE_DEV) exec frontend npm audit

# Installation and Setup
install: ## Install all dependencies
	@echo "$(CYAN)📦 Installing dependencies...$(NC)"
	$(MAKE) install-backend
	$(MAKE) install-frontend

install-backend: ## Install backend dependencies
	@echo "$(CYAN)🐍 Installing backend dependencies...$(NC)"
	cd $(BACKEND_DIR) && pip install -r requirements.txt -r requirements.dev.txt

install-frontend: ## Install frontend dependencies
	@echo "$(CYAN)⚛️ Installing frontend dependencies...$(NC)"
	cd $(FRONTEND_DIR) && npm ci

# Cleanup
clean: ## Clean up containers, images, and volumes
	@echo "$(YELLOW)🧹 Cleaning up Docker resources...$(NC)"
	docker-compose -f $(DOCKER_COMPOSE_DEV) down -v --remove-orphans
	docker-compose -f $(DOCKER_COMPOSE_PROD) down -v --remove-orphans || true
	docker system prune -f
	@echo "$(GREEN)✅ Cleanup completed!$(NC)"

clean-all: ## Deep clean (WARNING: removes all Docker data)
	@echo "$(RED)⚠️ This will remove ALL Docker containers, images, and volumes!$(NC)"
	@read -p "Are you sure? (y/N): " confirm; \\
	if [ "$$confirm" = "y" ] || [ "$$confirm" = "Y" ]; then \\
		docker system prune -a --volumes -f; \\
		echo "$(GREEN)✅ Deep cleanup completed!$(NC)"; \\
	else \\
		echo "$(YELLOW)Cleanup cancelled.$(NC)"; \\
	fi

# Health checks
health: ## Check service health
	@echo "$(CYAN)🏥 Checking service health...$(NC)"
	@echo "$(YELLOW)Backend:$(NC) $$(curl -s -o /dev/null -w '%{http_code}' http://localhost:8000/health)"
	@echo "$(YELLOW)Frontend:$(NC) $$(curl -s -o /dev/null -w '%{http_code}' http://localhost:3000)"
	@echo "$(YELLOW)Prometheus:$(NC) $$(curl -s -o /dev/null -w '%{http_code}' http://localhost:9090/-/healthy)"
	@echo "$(YELLOW)Grafana:$(NC) $$(curl -s -o /dev/null -w '%{http_code}' http://localhost:3001/api/health)"

# Monitoring
logs: ## View aggregated logs  
	@docker-compose -f $(DOCKER_COMPOSE_DEV) logs -f --tail=100

monitor: ## Open monitoring stack
	@echo "$(CYAN)📊 Opening monitoring dashboards...$(NC)"
	@echo "$(YELLOW)Grafana:$(NC) http://localhost:3001"
	@echo "$(YELLOW)Prometheus:$(NC) http://localhost:9090"  
	@echo "$(YELLOW)Jaeger:$(NC) http://localhost:16686"
	@open http://localhost:3001 2>/dev/null || true

# Deployment (for production)
deploy: ## Deploy to production (placeholder)
	@echo "$(CYAN)🚀 Deploying to production...$(NC)"
	@echo "$(YELLOW)This would deploy to Kubernetes cluster$(NC)"
	@echo "$(RED)Not implemented yet - use 'make prod' for local production$(NC)"

# Backup
backup: ## Backup database and important data
	@echo "$(CYAN)💾 Creating backup...$(NC)"
	@mkdir -p backups
	@docker-compose -f $(DOCKER_COMPOSE_DEV) exec -T postgres pg_dump -U smartfix smartfix_core > backups/smartfix_$$(date +%Y%m%d_%H%M%S).sql
	@echo "$(GREEN)✅ Backup created in backups/ directory$(NC)"

# Development utilities
shell-backend: ## Access backend container shell
	@docker-compose -f $(DOCKER_COMPOSE_DEV) exec backend /bin/bash

shell-frontend: ## Access frontend container shell  
	@docker-compose -f $(DOCKER_COMPOSE_DEV) exec frontend /bin/sh

shell-db: ## Access database container shell
	@docker-compose -f $(DOCKER_COMPOSE_DEV) exec postgres /bin/bash

# Quick development workflow
quick-start: ## Quick development start (build + migrate + seed)
	@echo "$(CYAN)⚡ Quick start - SmartFix Core$(NC)"
	$(MAKE) dev
	@sleep 30  # Wait for services to start
	$(MAKE) db-init
	@echo "$(GREEN)🎉 SmartFix Core is ready!$(NC)"
"""

print("📄 Makefile - Generated!")
print(f"Length: {len(makefile_content)} characters")
print("✅ Commands: dev, prod, test, clean, deploy, health, monitor")
print()