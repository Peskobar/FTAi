# docker-compose.yml - Multi-container development environment
docker_compose_content = """version: '3.8'

services:
  # PostgreSQL Database
  postgres:
    image: postgres:15-alpine
    container_name: smartfix-postgres
    environment:
      POSTGRES_DB: smartfix_core
      POSTGRES_USER: smartfix
      POSTGRES_PASSWORD: smartfix_dev_pass
      POSTGRES_INITDB_ARGS: "--encoding=UTF-8 --lc-collate=C --lc-ctype=C"
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./scripts/db-init.sql:/docker-entrypoint-initdb.d/init.sql:ro
    ports:
      - "5432:5432"
    networks:
      - smartfix-network
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U smartfix -d smartfix_core"]
      interval: 10s
      timeout: 5s
      retries: 5
    restart: unless-stopped

  # Redis for Celery Task Queue
  redis:
    image: redis:7-alpine
    container_name: smartfix-redis
    command: redis-server --appendonly yes --maxmemory 512mb --maxmemory-policy allkeys-lru
    volumes:
      - redis_data:/data
    ports:
      - "6379:6379"  
    networks:
      - smartfix-network
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 10s
      timeout: 3s
      retries: 3
    restart: unless-stopped

  # FastAPI Backend
  backend:
    build:
      context: .
      dockerfile: Dockerfile.backend
      target: development
    container_name: smartfix-backend
    environment:
      - DATABASE_URL=postgresql://smartfix:smartfix_dev_pass@postgres:5432/smartfix_core
      - REDIS_URL=redis://redis:6379/0
      - CELERY_BROKER_URL=redis://redis:6379/1
      - ENVIRONMENT=development
      - DEBUG=true
      - PPX_API_KEY=${PPX_API_KEY:-dummy_dev_key}
      - PPX_API_KEY_CI=${PPX_API_KEY_CI:-dummy_ci_key}
      - OTEL_EXPORTER_OTLP_ENDPOINT=http://otel-collector:4317
      - LOG_LEVEL=DEBUG
    volumes:
      - ./backend:/app:cached
      - ./models:/app/models:cached
      - ./plugins:/app/plugins:cached
    ports:
      - "8000:8000"
    networks:
      - smartfix-network
    depends_on:
      postgres:
        condition: service_healthy
      redis:
        condition: service_healthy
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 60s
    restart: unless-stopped
    develop:
      watch:
        - action: sync
          path: ./backend
          target: /app
          ignore:
            - __pycache__/
        - action: rebuild
          path: requirements.txt

  # Celery Worker
  worker:
    build:
      context: .
      dockerfile: Dockerfile.backend
      target: development
    container_name: smartfix-worker
    command: celery -A app.workers.celery_app worker --loglevel=info --concurrency=4
    environment:
      - DATABASE_URL=postgresql://smartfix:smartfix_dev_pass@postgres:5432/smartfix_core
      - REDIS_URL=redis://redis:6379/0
      - CELERY_BROKER_URL=redis://redis:6379/1
      - ENVIRONMENT=development
      - PPX_API_KEY=${PPX_API_KEY:-dummy_dev_key}
      - OTEL_EXPORTER_OTLP_ENDPOINT=http://otel-collector:4317
    volumes:
      - ./backend:/app:cached
      - ./models:/app/models:cached
      - ./plugins:/app/plugins:cached
    networks:
      - smartfix-network
    depends_on:
      postgres:
        condition: service_healthy
      redis:
        condition: service_healthy
      backend:
        condition: service_started
    restart: unless-stopped

  # React Frontend
  frontend:
    build:
      context: .
      dockerfile: Dockerfile.frontend
      target: development
    container_name: smartfix-frontend
    environment:
      - VITE_API_URL=http://localhost:8000
      - VITE_WS_URL=ws://localhost:8000
      - VITE_ENVIRONMENT=development
      - NODE_ENV=development
    volumes:
      - ./frontend:/app:cached
      - /app/node_modules
    ports:
      - "3000:3000"
    networks:
      - smartfix-network
    depends_on:
      - backend
    restart: unless-stopped
    develop:
      watch:
        - action: sync
          path: ./frontend/src
          target: /app/src
        - action: rebuild
          path: ./frontend/package.json

  # OpenTelemetry Collector
  otel-collector:
    image: otel/opentelemetry-collector-contrib:0.91.0
    container_name: smartfix-otel-collector
    command: ["--config=/etc/otel-collector-config.yaml"]
    volumes:
      - ./observability/otel/collector.yaml:/etc/otel-collector-config.yaml:ro
    ports:
      - "4317:4317"   # OTLP gRPC receiver
      - "4318:4318"   # OTLP HTTP receiver
      - "8888:8888"   # Prometheus metrics
    networks:
      - smartfix-network
    restart: unless-stopped

  # Prometheus Monitoring  
  prometheus:
    image: prom/prometheus:v2.47.0
    container_name: smartfix-prometheus
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'
      - '--storage.tsdb.path=/prometheus'
      - '--web.console.libraries=/etc/prometheus/console_libraries'
      - '--web.console.templates=/etc/prometheus/consoles'
      - '--storage.tsdb.retention.time=30d'
      - '--web.enable-lifecycle'
    volumes:
      - ./observability/monitoring/prometheus.yml:/etc/prometheus/prometheus.yml:ro
      - prometheus_data:/prometheus
    ports:
      - "9090:9090"
    networks:
      - smartfix-network
    restart: unless-stopped

  # Grafana Dashboards
  grafana:
    image: grafana/grafana:10.2.0
    container_name: smartfix-grafana
    environment:
      - GF_SECURITY_ADMIN_PASSWORD=admin
      - GF_USERS_ALLOW_SIGN_UP=false
      - GF_INSTALL_PLUGINS=grafana-clock-panel,grafana-simple-json-datasource
    volumes:
      - grafana_data:/var/lib/grafana
      - ./observability/monitoring/grafana/provisioning:/etc/grafana/provisioning:ro
      - ./observability/monitoring/grafana/dashboards:/var/lib/grafana/dashboards:ro
    ports:
      - "3001:3000"
    networks:
      - smartfix-network
    depends_on:
      - prometheus
    restart: unless-stopped

  # Jaeger Tracing
  jaeger:
    image: jaegertracing/all-in-one:1.51
    container_name: smartfix-jaeger
    environment:
      - COLLECTOR_OTLP_ENABLED=true
    ports:
      - "16686:16686"  # Jaeger UI
      - "14250:14250"  # gRPC
    networks:
      - smartfix-network
    restart: unless-stopped

volumes:
  postgres_data:
    driver: local
  redis_data:
    driver: local
  prometheus_data:
    driver: local
  grafana_data:
    driver: local

networks:
  smartfix-network:
    driver: bridge
    ipam:
      config:
        - subnet: 172.20.0.0/16
"""

print("📄 docker-compose.yml - Generated!")
print(f"Length: {len(docker_compose_content)} characters")
print("✅ Services: postgres, redis, backend, worker, frontend, otel-collector, prometheus, grafana, jaeger")
print()