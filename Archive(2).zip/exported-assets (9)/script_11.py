# requirements.txt - Production dependencies
requirements_content = """# SmartFix Core - Production Requirements
# Generated from pyproject.toml - DO NOT EDIT MANUALLY

# Core Web Framework
fastapi==0.104.1
uvicorn[standard]==0.24.0
gunicorn==21.2.0

# Database & ORM  
sqlalchemy==2.0.23
alembic==1.12.1
asyncpg==0.29.0
psycopg2-binary==2.9.9

# Task Queue & Caching
celery==5.3.4
redis==5.0.1
kombu==5.3.4

# Authentication & Security
python-jose[cryptography]==3.3.0
passlib[bcrypt]==1.7.4
python-multipart==0.0.6
cryptography==41.0.8

# AI & ML Stack
tensorflow==2.15.0
tensorflow-lite==2.15.0
scikit-learn==1.3.2
numpy==1.24.4
pandas==2.1.4
transformers==4.36.2

# HTTP & Async
httpx==0.25.2
aiohttp==3.9.1
aiofiles==23.2.1
asyncio-throttle==1.0.2

# Observability & Monitoring
opentelemetry-api==1.21.0
opentelemetry-sdk==1.21.0
opentelemetry-exporter-otlp==1.21.0
opentelemetry-instrumentation-fastapi==0.42b0
opentelemetry-instrumentation-sqlalchemy==0.42b0
opentelemetry-instrumentation-redis==0.42b0
opentelemetry-instrumentation-httpx==0.42b0
prometheus-client==0.19.0
structlog==23.2.0

# Configuration
pydantic==2.5.1
pydantic-settings==2.1.0
python-dotenv==1.0.0
dynaconf==3.2.4

# CLI & Utilities
click==8.1.7
rich==13.7.0
typer==0.9.0
jinja2==3.1.2
markupsafe==2.1.3

# File Processing
pillow==10.1.0
python-magic==0.4.27
chardet==5.2.0

# Validation
marshmallow==3.20.2
cerberus==1.3.5

# Networking
urllib3==2.1.0
requests==2.31.0

# Plugin System
pluggy==1.3.0
importlib-metadata==6.8.0

# APK Processing
python-apk==0.1.1
androguard==4.1.2

# Production Runtime
psutil==5.9.6
gevent==23.9.1
"""

# package.json for Frontend
package_json_content = """{
  "name": "smartfix-core-frontend",
  "version": "1.0.0",
  "description": "SmartFix Core - Modern React Dashboard for Android Patch Management",
  "type": "module",
  "scripts": {
    "dev": "vite --host 0.0.0.0 --port 3000",
    "build": "tsc && vite build",
    "build:prod": "tsc && vite build --mode production",
    "preview": "vite preview --host 0.0.0.0 --port 3000",
    "lint": "eslint . --ext ts,tsx --report-unused-disable-directives --max-warnings 0",
    "lint:fix": "eslint . --ext ts,tsx --fix",
    "type-check": "tsc --noEmit",
    "test": "vitest",
    "test:ui": "vitest --ui",
    "test:coverage": "vitest --coverage",
    "test:e2e": "playwright test",
    "format": "prettier --write \\\"src/**/*.{ts,tsx,js,jsx,json,css,md}\\\"",
    "format:check": "prettier --check \\\"src/**/*.{ts,tsx,js,jsx,json,css,md}\\\"",
    "analyze": "npm run build && npx vite-bundle-analyzer dist/stats.html",
    "clean": "rm -rf dist node_modules/.cache",
    "serve": "serve -s dist -l 3000"
  },
  "dependencies": {
    "react": "^19.0.0",
    "react-dom": "^19.0.0",
    "@tanstack/react-query": "^5.17.15",
    "@tanstack/react-router": "^1.12.4",
    "zustand": "^4.4.7",
    "@headlessui/react": "^1.7.17",
    "@heroicons/react": "^2.0.18",
    "framer-motion": "^10.16.16",
    "react-hot-toast": "^2.4.1",
    "react-hook-form": "^7.48.2",
    "@hookform/resolvers": "^3.3.2",
    "zod": "^3.22.4",
    "date-fns": "^2.30.0",
    "recharts": "^2.8.0",
    "d3": "^7.8.5",
    "vis-timeline": "^7.7.3",
    "socket.io-client": "^4.7.4",
    "axios": "^1.6.2",
    "clsx": "^2.0.0",
    "tailwind-merge": "^2.2.0",
    "@opentelemetry/api": "^1.7.0",
    "@opentelemetry/sdk-trace-web": "^1.18.1",
    "@opentelemetry/auto-instrumentations-web": "^0.34.0",
    "workbox-precaching": "^7.0.0",
    "workbox-routing": "^7.0.0",
    "workbox-strategies": "^7.0.0"
  },
  "devDependencies": {
    "@types/react": "^18.2.43",
    "@types/react-dom": "^18.2.17",
    "@types/d3": "^7.4.3",
    "@vitejs/plugin-react": "^4.2.1",
    "vite": "^5.0.8",
    "vite-plugin-pwa": "^0.17.4",
    "vite-bundle-analyzer": "^0.7.0",
    "typescript": "^5.3.3",
    "@typescript-eslint/eslint-plugin": "^6.14.0",
    "@typescript-eslint/parser": "^6.14.0",
    "eslint": "^8.55.0",
    "eslint-plugin-react": "^7.33.2",
    "eslint-plugin-react-hooks": "^4.6.0",
    "eslint-plugin-react-refresh": "^0.4.5",
    "eslint-plugin-jsx-a11y": "^6.8.0",
    "eslint-plugin-import": "^2.29.0",
    "eslint-config-prettier": "^9.1.0",
    "prettier": "^3.1.1",
    "prettier-plugin-tailwindcss": "^0.5.9",
    "tailwindcss": "^3.4.0",
    "postcss": "^8.4.32",
    "autoprefixer": "^10.4.16",
    "@tailwindcss/forms": "^0.5.7",
    "@tailwindcss/typography": "^0.5.10",
    "vitest": "^1.1.0",
    "jsdom": "^23.0.1",
    "@vitest/ui": "^1.1.0",
    "@vitest/coverage-v8": "^1.1.0",
    "@testing-library/react": "^14.1.2",
    "@testing-library/jest-dom": "^6.1.5",
    "@testing-library/user-event": "^14.5.1",
    "@playwright/test": "^1.40.1",
    "serve": "^14.2.1",
    "cross-env": "^7.0.3"
  },
  "browserslist": {
    "production": [
      ">0.2%",
      "not dead",
      "not op_mini all"
    ],
    "development": [
      "last 1 chrome version",
      "last 1 firefox version",
      "last 1 safari version"
    ]
  },
  "engines": {
    "node": ">=20.0.0",
    "npm": ">=10.0.0"
  },
  "author": "SmartFix Team <team@smartfix-core.dev>",
  "license": "MIT",
  "homepage": "https://smartfix-core.dev",
  "repository": {
    "type": "git",
    "url": "https://github.com/smartfix-core/smartfix-core.git"
  },
  "bugs": {
    "url": "https://github.com/smartfix-core/smartfix-core/issues"
  },
  "keywords": [
    "react",
    "typescript", 
    "vite",
    "tailwindcss",
    "dashboard",
    "patch-management",
    "android",
    "ai",
    "observability",
    "enterprise"
  ]
}"""

print("📄 requirements.txt - Generated!")
print(f"Length: {len(requirements_content)} characters")
print("✅ Contains: 40+ production dependencies with pinned versions")
print()

print("📄 package.json - Generated!")  
print(f"Length: {len(package_json_content)} characters")
print("✅ React 19, TypeScript, Vite, TailwindCSS, Testing, PWA support")
print()