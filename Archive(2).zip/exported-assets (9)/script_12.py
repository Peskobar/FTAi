# Makefile - Development and deployment commands
makefile_content = """# SmartFix Core - Makefile for Development & Deployment
# Usage: make <command>

.PHONY: help dev prod test clean deploy health build-backend build-frontend install-deps

# Default target
.DEFAULT_GOAL := help

#==============================================================================
# 📋 Configuration
#==============================================================================
COMPOSE_FILE := docker-compose.yml
COMPOSE_PROD_FILE := docker-compose.prod.yml
BACKEND_DIR := backend
FRONTEND_DIR := frontend
PYTHON := python3.11
NODE := node
NPM := npm

# Colors for output
CYAN := \\033[0;36m
GREEN := \\033[0;32m
YELLOW := \\033[1;33m
RED := \\033[0;31m
NC := \\033[0m

#==============================================================================
# 📖 Help
#==============================================================================
help: ## 📖 Show this help message
	@echo "$(CYAN)SmartFix Core - Available Commands$(NC)"
	@echo "$(CYAN)=================================$(NC)"
	@awk 'BEGIN {FS = ":.*##"; printf "\\n"} /^[a-zA-Z_-]+:.*?##/ { printf "  $(GREEN)%-20s$(NC) %s\\n", $$1, $$2 } /^##@/ { printf "\\n$(YELLOW)%s$(NC)\\n", substr($$0, 5) } ' $(MAKEFILE_LIST)
	@echo ""

##@ 🚀 Development
dev: ## 🚀 Start development environment
	@echo "$(CYAN)🚀 Starting SmartFix Core development environment...$(NC)"
	@docker-compose -f $(COMPOSE_FILE) up --build -d
	@echo "$(GREEN)✅ Development environment started!$(NC)"
	@echo "$(YELLOW)🌐 Frontend: http://localhost:3000$(NC)"
	@echo "$(YELLOW)🔧 Backend API: http://localhost:8000$(NC)"
	@echo "$(YELLOW)📖 API Docs: http://localhost:8000/docs$(NC)"
	@$(MAKE) health

dev-logs: ## 📄 Show development logs
	@docker-compose -f $(COMPOSE_FILE) logs -f

dev-stop: ## ⏹️ Stop development environment
	@echo "$(YELLOW)⏹️ Stopping development environment...$(NC)"
	@docker-compose -f $(COMPOSE_FILE) down
	@echo "$(GREEN)✅ Development environment stopped$(NC)"

##@ 🏭 Production
prod: ## 🏭 Start production environment
	@echo "$(CYAN)🏭 Starting SmartFix Core production environment...$(NC)"
	@docker-compose -f $(COMPOSE_PROD_FILE) up --build -d
	@echo "$(GREEN)✅ Production environment started!$(NC)"
	@$(MAKE) health

prod-logs: ## 📄 Show production logs
	@docker-compose -f $(COMPOSE_PROD_FILE) logs -f

prod-stop: ## ⏹️ Stop production environment
	@echo "$(YELLOW)⏹️ Stopping production environment...$(NC)"
	@docker-compose -f $(COMPOSE_PROD_FILE) down
	@echo "$(GREEN)✅ Production environment stopped$(NC)"

##@ 🔨 Build
build: ## 🔨 Build all containers
	@echo "$(CYAN)🔨 Building all containers...$(NC)"
	@docker-compose build --no-cache
	@echo "$(GREEN)✅ All containers built successfully!$(NC)"

build-backend: ## 🐍 Build backend container
	@echo "$(CYAN)🐍 Building backend container...$(NC)"
	@docker build -f Dockerfile.backend -t smartfix-core-backend .
	@echo "$(GREEN)✅ Backend container built!$(NC)"

build-frontend: ## ⚛️ Build frontend container
	@echo "$(CYAN)⚛️ Building frontend container...$(NC)"
	@docker build -f Dockerfile.frontend -t smartfix-core-frontend .
	@echo "$(GREEN)✅ Frontend container built!$(NC)"

##@ 🧪 Testing
test: ## 🧪 Run all tests
	@echo "$(CYAN)🧪 Running all tests...$(NC)"
	@$(MAKE) test-backend
	@$(MAKE) test-frontend
	@echo "$(GREEN)✅ All tests completed!$(NC)"

test-backend: ## 🐍 Run backend tests
	@echo "$(CYAN)🐍 Running backend tests...$(NC)"
	@cd $(BACKEND_DIR) && $(PYTHON) -m pytest --cov=app --cov-report=html --cov-report=term-missing
	@echo "$(GREEN)✅ Backend tests completed!$(NC)"

test-frontend: ## ⚛️ Run frontend tests
	@echo "$(CYAN)⚛️ Running frontend tests...$(NC)"
	@cd $(FRONTEND_DIR) && $(NPM) test
	@echo "$(GREEN)✅ Frontend tests completed!$(NC)"

test-e2e: ## 🎭 Run end-to-end tests
	@echo "$(CYAN)🎭 Running E2E tests...$(NC)"
	@cd $(FRONTEND_DIR) && $(NPM) run test:e2e
	@echo "$(GREEN)✅ E2E tests completed!$(NC)"

test-coverage: ## 📊 Generate test coverage reports
	@echo "$(CYAN)📊 Generating coverage reports...$(NC)"
	@cd $(BACKEND_DIR) && $(PYTHON) -m pytest --cov=app --cov-report=html
	@cd $(FRONTEND_DIR) && $(NPM) run test:coverage
	@echo "$(GREEN)✅ Coverage reports generated!$(NC)"
	@echo "$(YELLOW)🔍 Backend coverage: $(BACKEND_DIR)/htmlcov/index.html$(NC)"
	@echo "$(YELLOW)🔍 Frontend coverage: $(FRONTEND_DIR)/coverage/index.html$(NC)"

##@ 🔧 Development Tools
install-deps: ## 📦 Install all dependencies
	@echo "$(CYAN)📦 Installing dependencies...$(NC)"
	@echo "$(YELLOW)Installing backend dependencies...$(NC)"
	@cd $(BACKEND_DIR) && pip install -r requirements.txt
	@echo "$(YELLOW)Installing frontend dependencies...$(NC)"
	@cd $(FRONTEND_DIR) && $(NPM) install
	@echo "$(GREEN)✅ All dependencies installed!$(NC)"

lint: ## ✨ Run linting for all code
	@echo "$(CYAN)✨ Running linters...$(NC)"
	@$(MAKE) lint-backend
	@$(MAKE) lint-frontend
	@echo "$(GREEN)✅ Linting completed!$(NC)"

lint-backend: ## 🐍 Run backend linting
	@echo "$(YELLOW)🐍 Running backend linting...$(NC)"
	@cd $(BACKEND_DIR) && black --check .
	@cd $(BACKEND_DIR) && isort --check-only .
	@cd $(BACKEND_DIR) && flake8 .
	@cd $(BACKEND_DIR) && mypy .

lint-frontend: ## ⚛️ Run frontend linting
	@echo "$(YELLOW)⚛️ Running frontend linting...$(NC)"
	@cd $(FRONTEND_DIR) && $(NPM) run lint
	@cd $(FRONTEND_DIR) && $(NPM) run type-check

format: ## 🎨 Format all code
	@echo "$(CYAN)🎨 Formatting code...$(NC)"
	@$(MAKE) format-backend
	@$(MAKE) format-frontend
	@echo "$(GREEN)✅ Code formatting completed!$(NC)"

format-backend: ## 🐍 Format backend code
	@echo "$(YELLOW)🐍 Formatting backend code...$(NC)"
	@cd $(BACKEND_DIR) && black .
	@cd $(BACKEND_DIR) && isort .

format-frontend: ## ⚛️ Format frontend code
	@echo "$(YELLOW)⚛️ Formatting frontend code...$(NC)"
	@cd $(FRONTEND_DIR) && $(NPM) run format

##@ 🏥 Health & Monitoring
health: ## 🏥 Run comprehensive health check
	@echo "$(CYAN)🏥 Running health check...$(NC)"
	@chmod +x scripts/health-check.sh
	@./scripts/health-check.sh

status: ## 📊 Show system status
	@echo "$(CYAN)📊 SmartFix Core System Status$(NC)"
	@echo "$(CYAN)============================$(NC)"
	@docker ps --format "table {{.Names}}\\t{{.Status}}\\t{{.Ports}}" | grep smartfix || echo "$(YELLOW)No SmartFix containers running$(NC)"

logs: ## 📄 Show all logs
	@docker-compose logs -f

logs-backend: ## 🐍 Show backend logs
	@docker-compose logs -f backend

logs-frontend: ## ⚛️ Show frontend logs
	@docker-compose logs -f frontend

logs-db: ## 🗄️ Show database logs
	@docker-compose logs -f postgres

##@ 🗄️ Database
db-migrate: ## 🗄️ Run database migrations
	@echo "$(CYAN)🗄️ Running database migrations...$(NC)"
	@docker-compose exec backend alembic upgrade head
	@echo "$(GREEN)✅ Database migrations completed!$(NC)"

db-rollback: ## ↩️ Rollback last database migration
	@echo "$(YELLOW)↩️ Rolling back last migration...$(NC)"
	@docker-compose exec backend alembic downgrade -1
	@echo "$(GREEN)✅ Migration rolled back!$(NC)"

db-reset: ## 🔄 Reset database (WARNING: destroys all data)
	@echo "$(RED)⚠️ WARNING: This will destroy all database data!$(NC)"
	@echo "$(YELLOW)Press Ctrl+C to cancel, or wait 10 seconds to continue...$(NC)"
	@sleep 10
	@docker-compose down -v
	@docker volume rm smartfix-core_postgres_data || true
	@$(MAKE) dev
	@$(MAKE) db-migrate
	@echo "$(GREEN)✅ Database reset completed!$(NC)"

db-backup: ## 💾 Create database backup
	@echo "$(CYAN)💾 Creating database backup...$(NC)"
	@docker-compose exec postgres pg_dump -U smartfix smartfix_core > "backup_$(shell date +%Y%m%d_%H%M%S).sql"
	@echo "$(GREEN)✅ Database backup created!$(NC)"

db-shell: ## 🐚 Connect to database shell
	@docker-compose exec postgres psql -U smartfix -d smartfix_core

##@ 🚀 Deployment
deploy: ## 🚀 Deploy to Kubernetes
	@echo "$(CYAN)🚀 Deploying to Kubernetes...$(NC)"
	@kubectl apply -f k8s/
	@echo "$(GREEN)✅ Deployment completed!$(NC)"

deploy-staging: ## 🎭 Deploy to staging environment
	@echo "$(CYAN)🎭 Deploying to staging...$(NC)"
	@helm upgrade --install smartfix-staging helm/smartfix-core -f helm/values-staging.yaml
	@echo "$(GREEN)✅ Staging deployment completed!$(NC)"

deploy-prod: ## 🏭 Deploy to production
	@echo "$(RED)⚠️ PRODUCTION DEPLOYMENT$(NC)"
	@echo "$(YELLOW)Press Ctrl+C to cancel, or wait 10 seconds to continue...$(NC)"
	@sleep 10
	@echo "$(CYAN)🏭 Deploying to production...$(NC)"
	@helm upgrade --install smartfix-prod helm/smartfix-core -f helm/values-prod.yaml
	@echo "$(GREEN)✅ Production deployment completed!$(NC)"

rollback: ## ↩️ Rollback deployment
	@echo "$(YELLOW)↩️ Rolling back deployment...$(NC)"
	@helm rollback smartfix-prod
	@echo "$(GREEN)✅ Rollback completed!$(NC)"

##@ 🧹 Cleanup
clean: ## 🧹 Clean up containers and volumes
	@echo "$(CYAN)🧹 Cleaning up...$(NC)"
	@docker-compose down -v --remove-orphans
	@docker system prune -f
	@echo "$(GREEN)✅ Cleanup completed!$(NC)"

clean-all: ## 🧹 Clean everything (containers, volumes, images)
	@echo "$(RED)⚠️ WARNING: This will remove all Docker resources!$(NC)"
	@echo "$(YELLOW)Press Ctrl+C to cancel, or wait 10 seconds to continue...$(NC)"
	@sleep 10
	@docker-compose down -v --remove-orphans
	@docker system prune -af --volumes
	@echo "$(GREEN)✅ Complete cleanup finished!$(NC)"

purge: ## 💥 Complete purge (reset everything)
	@echo "$(RED)💥 DANGER: Complete system purge!$(NC)"
	@echo "$(YELLOW)Press Ctrl+C to cancel, or wait 15 seconds to continue...$(NC)"
	@sleep 15
	@$(MAKE) clean-all
	@rm -rf $(BACKEND_DIR)/__pycache__ $(BACKEND_DIR)/.pytest_cache $(BACKEND_DIR)/htmlcov
	@rm -rf $(FRONTEND_DIR)/node_modules $(FRONTEND_DIR)/dist $(FRONTEND_DIR)/coverage
	@echo "$(GREEN)✅ System purged!$(NC)"

##@ 📊 Analytics & Reports
security-scan: ## 🔒 Run security scans
	@echo "$(CYAN)🔒 Running security scans...$(NC)"
	@cd $(BACKEND_DIR) && bandit -r app/
	@cd $(BACKEND_DIR) && safety check
	@cd $(FRONTEND_DIR) && $(NPM) audit
	@echo "$(GREEN)✅ Security scan completed!$(NC)"

performance-test: ## ⚡ Run performance tests
	@echo "$(CYAN)⚡ Running performance tests...$(NC)"
	@cd $(BACKEND_DIR) && locust --headless -u 100 -r 10 -t 60s --host=http://localhost:8000
	@echo "$(GREEN)✅ Performance test completed!$(NC)"

##@ 📚 Documentation
docs: ## 📚 Generate documentation
	@echo "$(CYAN)📚 Generating documentation...$(NC)"
	@cd $(BACKEND_DIR) && sphinx-build -b html docs docs/_build
	@echo "$(GREEN)✅ Documentation generated!$(NC)"
	@echo "$(YELLOW)🔍 Documentation: $(BACKEND_DIR)/docs/_build/index.html$(NC)"

docs-serve: ## 🌐 Serve documentation locally
	@echo "$(CYAN)🌐 Serving documentation at http://localhost:8080$(NC)"
	@cd $(BACKEND_DIR)/docs/_build && $(PYTHON) -m http.server 8080

##@ ℹ️ Information
version: ## ℹ️ Show version information
	@echo "$(CYAN)SmartFix Core Version Information$(NC)"
	@echo "$(CYAN)================================$(NC)"
	@echo "SmartFix Core: $(shell grep version pyproject.toml | head -1 | cut -d'"' -f2)"
	@echo "Python: $(shell $(PYTHON) --version)"
	@echo "Node.js: $(shell $(NODE) --version)"
	@echo "Docker: $(shell docker --version)"
	@echo "Docker Compose: $(shell docker-compose --version)"

env: ## ℹ️ Show environment information
	@echo "$(CYAN)Environment Information$(NC)"
	@echo "$(CYAN)=====================$(NC)"
	@echo "COMPOSE_FILE: $(COMPOSE_FILE)"
	@echo "BACKEND_DIR: $(BACKEND_DIR)"
	@echo "FRONTEND_DIR: $(FRONTEND_DIR)"
	@echo "PYTHON: $(PYTHON)"
	@echo "NODE: $(NODE)"
	@echo "Current directory: $(PWD)"
"""

print("📄 Makefile - Generated!")
print(f"Length: {len(makefile_content)} characters")
print("✅ Features: 40+ commands for dev/prod/test/deploy/monitoring")
print()