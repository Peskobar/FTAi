# Dockerfile.backend - Multi-stage Python backend
dockerfile_backend_content = """# Multi-stage build dla FastAPI backend
FROM python:3.11-slim as base

# Metadata
LABEL maintainer="SmartFix Core Team"
LABEL version="1.0.0"
LABEL description="AI-Powered Patch Management Backend"

# System dependencies
RUN apt-get update && apt-get install -y \\
    build-essential \\
    curl \\
    git \\
    libpq-dev \\
    && rm -rf /var/lib/apt/lists/*

# Python environment
ENV PYTHONUNBUFFERED=1 \\
    PYTHONDONTWRITEBYTECODE=1 \\
    PIP_NO_CACHE_DIR=1 \\
    PIP_DISABLE_PIP_VERSION_CHECK=1

# Create non-root user
RUN groupadd --gid 1000 appuser && \\
    useradd --uid 1000 --gid appuser --create-home appuser

# Set working directory
WORKDIR /app

# Install Python dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Development stage
FROM base as development
ENV ENVIRONMENT=development
ENV DEBUG=true

# Install development dependencies
COPY requirements.dev.txt .
RUN pip install --no-cache-dir -r requirements.dev.txt

# Copy application code
COPY --chown=appuser:appuser backend/ ./
COPY --chown=appuser:appuser models/ ./models/
COPY --chown=appuser:appuser plugins/ ./plugins/

# Switch to non-root user
USER appuser

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=60s --retries=3 \\
    CMD curl -f http://localhost:8000/health || exit 1

# Default command
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000", "--reload"]

# Production stage
FROM base as production
ENV ENVIRONMENT=production
ENV DEBUG=false

# Copy application code
COPY --chown=appuser:appuser backend/ ./
COPY --chown=appuser:appuser models/ ./models/
COPY --chown=appuser:appuser plugins/ ./plugins/

# Switch to non-root user
USER appuser

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=60s --retries=3 \\
    CMD curl -f http://localhost:8000/health || exit 1

# Expose port
EXPOSE 8000

# Production command with Gunicorn
CMD ["gunicorn", "app.main:app", "-k", "uvicorn.workers.UvicornWorker", \\
     "--bind", "0.0.0.0:8000", "--workers", "4", "--worker-connections", "1000", \\
     "--max-requests", "10000", "--max-requests-jitter", "1000", \\
     "--preload", "--access-logfile", "-", "--error-logfile", "-"]
"""

# Dockerfile.frontend - Multi-stage Node.js frontend  
dockerfile_frontend_content = """# Multi-stage build dla React frontend
FROM node:20-alpine as base

# Metadata
LABEL maintainer="SmartFix Core Team"
LABEL version="1.0.0" 
LABEL description="SmartFix Core React Dashboard"

# Install system dependencies
RUN apk add --no-cache \\
    curl \\
    git

# Set working directory
WORKDIR /app

# Development stage
FROM base as development
ENV NODE_ENV=development

# Copy package files
COPY frontend/package*.json ./

# Install dependencies (including dev dependencies)
RUN npm ci --include=dev

# Copy source code
COPY frontend/ ./

# Create non-root user
RUN addgroup -g 1000 appuser && \\
    adduser -D -s /bin/sh -u 1000 -G appuser appuser && \\
    chown -R appuser:appuser /app

USER appuser

# Expose port
EXPOSE 3000

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=30s --retries=3 \\
    CMD curl -f http://localhost:3000 || exit 1

# Development command
CMD ["npm", "run", "dev", "--", "--host", "0.0.0.0"]

# Build stage
FROM base as build
ENV NODE_ENV=production

# Copy package files
COPY frontend/package*.json ./

# Install dependencies (production only)
RUN npm ci --only=production --ignore-scripts

# Copy source code  
COPY frontend/ ./

# Build application
RUN npm run build

# Production stage
FROM nginx:1.25-alpine as production

# Install curl for health checks
RUN apk add --no-cache curl

# Copy built application
COPY --from=build /app/dist /usr/share/nginx/html

# Copy Nginx configuration
COPY frontend/nginx.conf /etc/nginx/nginx.conf

# Create non-root user
RUN addgroup -g 1000 appuser && \\
    adduser -D -s /bin/sh -u 1000 -G appuser appuser

# Set correct permissions
RUN chown -R appuser:appuser /usr/share/nginx/html && \\
    chown -R appuser:appuser /var/cache/nginx && \\
    chown -R appuser:appuser /var/log/nginx && \\
    chown -R appuser:appuser /etc/nginx/conf.d

# Switch to non-root user
USER appuser

# Expose port
EXPOSE 3000

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=10s --retries=3 \\
    CMD curl -f http://localhost:3000 || exit 1

# Start Nginx
CMD ["nginx", "-g", "daemon off;"]
"""

print("📄 Dockerfile.backend - Generated!")
print(f"Length: {len(dockerfile_backend_content)} characters")
print("✅ Multi-stage: base → development → production")
print()

print("📄 Dockerfile.frontend - Generated!")  
print(f"Length: {len(dockerfile_frontend_content)} characters")
print("✅ Multi-stage: base → development → build → production")
print()