# requirements.txt - Python backend dependencies
requirements_content = """# FastAPI and ASGI server
fastapi==0.104.1
uvicorn[standard]==0.24.0
gunicorn==21.2.0

# Database and ORM
sqlalchemy==2.0.23
psycopg2-binary==2.9.9
alembic==1.12.1

# Redis and task queue
redis==5.0.1
celery==5.3.4

# Authentication and security
python-jose[cryptography]==3.3.0
passlib[bcrypt]==1.7.4
python-multipart==0.0.6

# Validation and serialization
pydantic==2.5.0
pydantic-settings==2.1.0
email-validator==2.1.0

# HTTP client
httpx==0.25.2
aiohttp==3.9.1

# Observability and monitoring
opentelemetry-api==1.21.0
opentelemetry-sdk==1.21.0
opentelemetry-exporter-otlp==1.21.0
opentelemetry-instrumentation-fastapi==0.42b0
opentelemetry-instrumentation-sqlalchemy==0.42b0
opentelemetry-instrumentation-redis==0.42b0
prometheus-client==0.19.0

# AI and ML
tensorflow==2.15.0
scikit-learn==1.3.2
numpy==1.24.4
pandas==2.1.4

# Plugin system and WASM
wasmtime-py==14.0.0

# Utilities
python-dotenv==1.0.0
structlog==23.2.0
typer==0.9.0
rich==13.7.0

# Development and testing (should be in requirements.dev.txt)
pytest==7.4.3
pytest-asyncio==0.21.1
pytest-cov==4.1.0
httpx==0.25.2
faker==20.1.0
"""

# requirements.dev.txt - Development dependencies  
requirements_dev_content = """# Testing
pytest==7.4.3
pytest-asyncio==0.21.1
pytest-cov==4.1.0
pytest-xdist==3.5.0
pytest-mock==3.12.0
faker==20.1.0

# Code quality
black==23.11.0
isort==5.12.0
flake8==6.1.0
mypy==1.7.1
bandit==1.7.5

# Development tools
pre-commit==3.6.0
watchdog==3.0.0
ipython==8.17.2

# Documentation
mkdocs==1.5.3
mkdocs-material==9.4.8
"""

# package.json - Frontend dependencies
package_json_content = """{
  "name": "smartfix-core-frontend",
  "version": "1.0.0",
  "description": "SmartFix Core React Dashboard - AI-Powered Patch Management",
  "type": "module",
  "scripts": {
    "dev": "vite --host 0.0.0.0",
    "build": "tsc && vite build",
    "preview": "vite preview --host 0.0.0.0",
    "lint": "eslint . --ext ts,tsx --report-unused-disable-directives --max-warnings 0",
    "lint:fix": "eslint . --ext ts,tsx --fix",
    "type-check": "tsc --noEmit",
    "test": "vitest",
    "test:coverage": "vitest --coverage",
    "test:e2e": "playwright test",
    "format": "prettier --write src/**/*.{ts,tsx,css,md}"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "@tanstack/react-router": "^1.58.3",
    "@tanstack/react-query": "^5.12.2",
    "zustand": "^4.4.7",
    "axios": "^1.6.2",
    "ws": "^8.14.2",
    "recharts": "^2.8.0",
    "lucide-react": "^0.294.0",
    "framer-motion": "^10.16.16",
    "@headlessui/react": "^1.7.17",
    "clsx": "^2.0.0",
    "react-hook-form": "^7.48.2",
    "@hookform/resolvers": "^3.3.2",
    "zod": "^3.22.4",
    "date-fns": "^2.30.0",
    "react-hot-toast": "^2.4.1"
  },
  "devDependencies": {
    "@types/react": "^18.2.43",
    "@types/react-dom": "^18.2.17",
    "@types/ws": "^8.5.10",
    "@vitejs/plugin-react": "^4.2.1",
    "vite": "^5.0.8",
    "typescript": "^5.2.2",
    "tailwindcss": "^3.3.6",
    "autoprefixer": "^10.4.16",
    "postcss": "^8.4.32",
    "@tailwindcss/forms": "^0.5.7",
    "@tailwindcss/typography": "^0.5.10",
    "@tailwindcss/aspect-ratio": "^0.4.2",
    "eslint": "^8.55.0",
    "@typescript-eslint/eslint-plugin": "^6.14.0",
    "@typescript-eslint/parser": "^6.14.0",
    "eslint-plugin-react-hooks": "^4.6.0",
    "eslint-plugin-react-refresh": "^0.4.5",
    "prettier": "^3.1.1",
    "prettier-plugin-tailwindcss": "^0.5.7",
    "vitest": "^1.0.4",
    "@testing-library/react": "^14.1.2",
    "@testing-library/jest-dom": "^6.1.5",
    "jsdom": "^23.0.1",
    "@playwright/test": "^1.40.1",
    "@types/node": "^20.10.4",
    "vite-plugin-pwa": "^0.17.4",
    "workbox-window": "^7.0.0"
  },
  "browserslist": {
    "production": [
      ">0.2%",
      "not dead",
      "not op_mini all"
    ],
    "development": [
      "last 1 chrome version",
      "last 1 firefox version",
      "last 1 safari version"
    ]
  },
  "engines": {
    "node": ">=20.0.0",
    "npm": ">=10.0.0"
  }
}"""

print("📄 requirements.txt - Generated!")
print(f"Length: {len(requirements_content)} characters")
print("✅ Dependencies: FastAPI, SQLAlchemy, Celery, OpenTelemetry, TensorFlow")
print()

print("📄 package.json - Generated!")
print(f"Length: {len(package_json_content)} characters") 
print("✅ Dependencies: React 19, TypeScript, TanStack, Zustand, Tailwind")
print()