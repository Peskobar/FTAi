# .env.example - Environment variables template
env_example_content = """# SmartFix Core - Environment Configuration
# Copy this file to .env and adjust values for your environment

#==============================================================================
# 🚀 APPLICATION SETTINGS
#==============================================================================
ENVIRONMENT=development
DEBUG=true
LOG_LEVEL=INFO
SECRET_KEY=your-super-secret-key-change-in-production
API_VERSION=v1

#==============================================================================
# 🗄️ DATABASE CONFIGURATION  
#==============================================================================
DATABASE_URL=postgresql://smartfix:smartfix_dev_pass@postgres:5432/smartfix_core
DB_HOST=postgres
DB_PORT=5432
DB_NAME=smartfix_core
DB_USER=smartfix
DB_PASSWORD=smartfix_dev_pass
DB_POOL_SIZE=10
DB_MAX_OVERFLOW=20

#==============================================================================
# 🔄 REDIS & CELERY CONFIGURATION
#==============================================================================
REDIS_URL=redis://redis:6379/0
CELERY_BROKER_URL=redis://redis:6379/1
CELERY_RESULT_BACKEND=redis://redis:6379/2
CELERY_WORKER_CONCURRENCY=4
CELERY_TASK_TIMEOUT=300

#==============================================================================
# 🔐 AUTHENTICATION & SECURITY
#==============================================================================
JWT_SECRET_KEY=your-jwt-secret-key
JWT_ALGORITHM=HS256
JWT_ACCESS_TOKEN_EXPIRE_MINUTES=30
JWT_REFRESH_TOKEN_EXPIRE_DAYS=7
BCRYPT_ROUNDS=12

# API Rate Limiting
RATE_LIMIT_PER_MINUTE=100
RATE_LIMIT_BURST=50

#==============================================================================
# 🤖 AI SERVICES CONFIGURATION
#==============================================================================
# Perplexity AI - Dual Key Setup
PPX_API_KEY=pplx-your-production-api-key
PPX_API_KEY_CI=pplx-your-ci-api-key
PPX_API_TIMEOUT=30
PPX_MAX_TOKENS=4000

# TensorFlow Lite Models
TFLITE_MODEL_PATH=./models/apk_analyzer.tflite
LSTM_MODEL_PATH=./models/autoscaler_lstm.tflite
MODEL_CACHE_SIZE=100
INFERENCE_TIMEOUT=10

# AI Processing
AI_QUEUE_SIZE=50
AI_WORKER_THREADS=2
AI_BATCH_SIZE=10

#==============================================================================
# 📡 OBSERVABILITY & MONITORING
#==============================================================================
# OpenTelemetry
OTEL_EXPORTER_OTLP_ENDPOINT=http://otel-collector:4317
OTEL_EXPORTER_OTLP_HEADERS=
OTEL_SERVICE_NAME=smartfix-core
OTEL_RESOURCE_ATTRIBUTES=service.version=1.0.0
OTEL_TRACES_EXPORTER=otlp
OTEL_METRICS_EXPORTER=otlp
OTEL_LOGS_EXPORTER=otlp

# Prometheus Metrics
PROMETHEUS_ENABLED=true
PROMETHEUS_PORT=8001
METRICS_ENDPOINT=/metrics

# Jaeger Tracing
JAEGER_AGENT_HOST=jaeger
JAEGER_AGENT_PORT=6831
JAEGER_SAMPLER_RATE=0.1

#==============================================================================
# 🔌 PLUGIN SYSTEM
#==============================================================================
PLUGIN_DIR=./plugins
PLUGIN_MARKETPLACE_URL=https://marketplace.smartfix.io
WASM_RUNTIME_MEMORY_MB=64
WASM_EXECUTION_TIMEOUT=30
PLUGIN_SIGNATURE_VALIDATION=true
PLUGIN_AUTO_UPDATE=false

#==============================================================================
# 📢 NOTIFICATIONS
#==============================================================================
# Slack Integration
SLACK_WEBHOOK_URL=https://hooks.slack.com/services/your/webhook/url
SLACK_CHANNEL=#smartfix-alerts
SLACK_USERNAME=SmartFix-Bot

# Email Notifications
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASSWORD=your-app-password
EMAIL_FROM=SmartFix Core <noreply@smartfix.io>

#==============================================================================
# ☁️ CLOUD & STORAGE
#==============================================================================
# File Storage
UPLOAD_DIR=./uploads
MAX_UPLOAD_SIZE=50MB
ALLOWED_EXTENSIONS=.apk,.aab
STORAGE_BACKEND=local

# AWS S3 (if using cloud storage)
AWS_ACCESS_KEY_ID=your-access-key
AWS_SECRET_ACCESS_KEY=your-secret-key
AWS_S3_BUCKET=smartfix-storage
AWS_REGION=us-east-1

#==============================================================================
# 🌐 NETWORK & CORS
#==============================================================================
# Frontend URL
FRONTEND_URL=http://localhost:3000
BACKEND_URL=http://localhost:8000

# CORS Settings
CORS_ORIGINS=["http://localhost:3000","http://127.0.0.1:3000"]
CORS_METHODS=["GET","POST","PUT","DELETE","OPTIONS","PATCH"]
CORS_HEADERS=["*"]

#==============================================================================
# 🔧 DEVELOPMENT SETTINGS
#==============================================================================
# Hot Reload
WATCHDOG_ENABLED=true
AUTO_RELOAD=true

# Testing
TEST_DATABASE_URL=postgresql://smartfix:smartfix_test_pass@postgres:5432/smartfix_test
PYTEST_WORKERS=4

# Mock Services (for testing)
MOCK_AI_SERVICES=false
MOCK_NOTIFICATIONS=true
MOCK_PLUGINS=false

#==============================================================================
# 🏭 PRODUCTION OVERRIDES
#==============================================================================
# Uncomment and modify for production deployment

# ENVIRONMENT=production
# DEBUG=false
# LOG_LEVEL=WARNING
# DATABASE_URL=postgresql://user:pass@prod-db:5432/smartfix
# REDIS_URL=redis://prod-redis:6379/0
# SECRET_KEY=super-secure-production-key
# JWT_SECRET_KEY=super-secure-jwt-key
# PPX_API_KEY=pplx-production-key
# OTEL_EXPORTER_OTLP_ENDPOINT=https://your-observability-backend.com
# CORS_ORIGINS=["https://app.smartfix.io"]
# FRONTEND_URL=https://app.smartfix.io
# BACKEND_URL=https://api.smartfix.io
"""

# .env.prod.example - Production environment template
env_prod_example_content = """# SmartFix Core - Production Environment Configuration

#==============================================================================
# 🚀 PRODUCTION APPLICATION SETTINGS
#==============================================================================
ENVIRONMENT=production
DEBUG=false
LOG_LEVEL=WARNING
SECRET_KEY=CHANGE-THIS-TO-A-SECURE-RANDOM-STRING
API_VERSION=v1

#==============================================================================
# 🗄️ PRODUCTION DATABASE
#==============================================================================
DATABASE_URL=postgresql://smartfix_prod:SECURE_PASSWORD@db-primary:5432/smartfix_core
DB_POOL_SIZE=20
DB_MAX_OVERFLOW=40
DB_ECHO=false

#==============================================================================
# 🔄 PRODUCTION REDIS & CELERY
#==============================================================================
REDIS_URL=redis://:REDIS_PASSWORD@redis-primary:6379/0
CELERY_BROKER_URL=redis://:REDIS_PASSWORD@redis-primary:6379/1
CELERY_WORKER_CONCURRENCY=8
CELERY_TASK_TIMEOUT=600

#==============================================================================
# 🔐 PRODUCTION SECURITY
#==============================================================================
JWT_SECRET_KEY=CHANGE-THIS-TO-A-SECURE-JWT-KEY
JWT_ACCESS_TOKEN_EXPIRE_MINUTES=15
BCRYPT_ROUNDS=14
RATE_LIMIT_PER_MINUTE=60

#==============================================================================
# 🤖 PRODUCTION AI SERVICES
#==============================================================================
PPX_API_KEY=pplx-your-actual-production-key
PPX_API_KEY_CI=pplx-your-actual-ci-key
AI_WORKER_THREADS=4

#==============================================================================
# 📡 PRODUCTION OBSERVABILITY
#==============================================================================
OTEL_EXPORTER_OTLP_ENDPOINT=https://your-observability-endpoint.com:4317
OTEL_EXPORTER_OTLP_HEADERS=api-key=your-observability-api-key
JAEGER_SAMPLER_RATE=0.01

#==============================================================================
# 🌐 PRODUCTION NETWORK
#==============================================================================
FRONTEND_URL=https://app.smartfix.io
BACKEND_URL=https://api.smartfix.io
CORS_ORIGINS=["https://app.smartfix.io"]

#==============================================================================
# 📢 PRODUCTION NOTIFICATIONS
#==============================================================================
SLACK_WEBHOOK_URL=https://hooks.slack.com/services/YOUR/ACTUAL/WEBHOOK
SMTP_HOST=smtp.company.com
SMTP_PORT=587
SMTP_USER=smartfix@company.com
SMTP_PASSWORD=SECURE_EMAIL_PASSWORD

#==============================================================================
# ☁️ PRODUCTION CLOUD STORAGE
#==============================================================================
STORAGE_BACKEND=s3
AWS_ACCESS_KEY_ID=YOUR_AWS_ACCESS_KEY
AWS_SECRET_ACCESS_KEY=YOUR_AWS_SECRET_KEY
AWS_S3_BUCKET=smartfix-prod-storage
MAX_UPLOAD_SIZE=100MB
"""

print("📄 .env.example - Generated!")
print(f"Length: {len(env_example_content)} characters")
print("✅ Sections: App, Database, Redis, Auth, AI, Observability, Plugins")
print()

print("📄 .env.prod.example - Generated!")
print(f"Length: {len(env_prod_example_content)} characters")
print("✅ Production-optimized settings")
print()