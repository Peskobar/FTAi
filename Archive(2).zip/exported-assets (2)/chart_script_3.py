import plotly.graph_objects as go
import json

# Load the data
data = {
    "current_metrics": {"latency_p95": 2.4, "success_rate": 95, "queue_avg": 15, "trace_coverage": 0}, 
    "target_metrics": {"latency_p95": 1.5, "success_rate": 99, "queue_avg": 5, "trace_coverage": 100}, 
    "otel_components": ["Traces", "Metrics", "Logs", "OTLP Exporter"], 
    "performance_timeline": [
        {"week": 1, "latency": 2.4, "success_rate": 95, "queue_size": 15}, 
        {"week": 12, "latency": 2.1, "success_rate": 96, "queue_size": 12}, 
        {"week": 24, "latency": 1.8, "success_rate": 98, "queue_size": 8}, 
        {"week": 36, "latency": 1.6, "success_rate": 98.5, "queue_size": 6}, 
        {"week": 43, "latency": 1.4, "success_rate": 99.2, "queue_size": 4}
    ], 
    "autoscaling_events": [
        {"week": 8, "action": "scale_up", "workers": 3}, 
        {"week": 16, "action": "scale_down", "workers": 2}, 
        {"week": 28, "action": "scale_up", "workers": 4}, 
        {"week": 35, "action": "scale_down", "workers": 3}
    ], 
    "circuit_breaker_states": ["Closed", "Half-Open", "Open"], 
    "lstm_accuracy": 87.5
}

# Extract timeline data
timeline = data['performance_timeline']
weeks = [item['week'] for item in timeline]
latency = [item['latency'] for item in timeline]
success_rate = [item['success_rate'] for item in timeline]

# Create figure
fig = go.Figure()

# Add latency trend with status colors
latency_colors = []
for lat in latency:
    if lat <= 1.5:
        latency_colors.append('#1FB8CD')  # Green - good
    elif lat <= 2.0:
        latency_colors.append('#FFC185')  # Yellow - warning  
    else:
        latency_colors.append('#B4413C')  # Red - critical

fig.add_trace(go.Scatter(
    x=weeks,
    y=latency,
    mode='lines+markers',
    name='Latency (s)',
    line=dict(color='#B4413C', width=3),
    marker=dict(
        size=12,
        color=latency_colors,
        line=dict(width=2, color='white')
    ),
    hovertemplate='<b>Week %{x}</b><br>' +
                  'Latency: %{y}s<br>' +
                  '<extra></extra>',
    cliponaxis=False
))

# Add success rate with status colors
success_colors = []
success_y_scaled = []  # Scale to fit same axis as latency
for rate in success_rate:
    success_y_scaled.append(rate / 40)  # Scale 95-100% to ~2.4-2.5 range
    if rate >= 99:
        success_colors.append('#1FB8CD')  # Green - good
    elif rate >= 97:
        success_colors.append('#FFC185')  # Yellow - warning
    else:
        success_colors.append('#B4413C')  # Red - critical

fig.add_trace(go.Scatter(
    x=weeks,
    y=success_y_scaled,
    mode='lines+markers',
    name='Success Rate',
    line=dict(color='#5D878F', width=3, dash='dash'),
    marker=dict(
        size=12,
        color=success_colors,
        symbol='square',
        line=dict(width=2, color='white')
    ),
    hovertemplate='<b>Week %{x}</b><br>' +
                  'Success Rate: ' + 
                  [f'{rate}%' for rate in success_rate][0] + '<br>' +
                  '<extra></extra>',
    customdata=success_rate,
    cliponaxis=False
))

# Add current vs target indicators as annotations
fig.add_annotation(
    x=2, y=2.3,
    text="Current: 2.4s",
    showarrow=False,
    bgcolor='#B4413C',
    bordercolor='white',
    font=dict(color='white', size=10)
)

fig.add_annotation(
    x=2, y=2.1,
    text="Target: ≤1.5s",
    showarrow=False,
    bgcolor='#1FB8CD',
    bordercolor='white',
    font=dict(color='white', size=10)
)

fig.add_annotation(
    x=38, y=2.3,
    text="Success: 95→99%",
    showarrow=False,
    bgcolor='#5D878F',
    bordercolor='white',
    font=dict(color='white', size=10)
)

fig.add_annotation(
    x=38, y=2.1,
    text="Coverage: 0→100%",
    showarrow=False,
    bgcolor='#D2BA4C',
    bordercolor='white',
    font=dict(color='white', size=10)
)

fig.add_annotation(
    x=20, y=0.9,
    text="LSTM Acc: 87.5%",
    showarrow=False,
    bgcolor='#ECEBD5',
    bordercolor='white',
    font=dict(color='black', size=10)
)

# Add target line
fig.add_hline(
    y=1.5,
    line=dict(color='#1FB8CD', width=2, dash="dot"),
    opacity=0.7,
    annotation_text="Target"
)

# Add autoscaling events
for event in data['autoscaling_events']:
    color = '#1FB8CD' if event['action'] == 'scale_up' else '#FFC185'
    fig.add_vline(
        x=event['week'],
        line=dict(color=color, width=1, dash="dash"),
        opacity=0.5
    )

# Update layout
fig.update_layout(
    title='TUI Performance Transform Dashboard',
    xaxis=dict(
        title='Week',
        range=[0, 45]
    ),
    yaxis=dict(
        title='Latency (s)',
        range=[0.8, 2.6]
    ),
    legend=dict(
        orientation='h', 
        yanchor='bottom', 
        y=1.02, 
        xanchor='center', 
        x=0.5
    ),
    showlegend=True
)

# Save the chart
fig.write_image("performance_dashboard.png")