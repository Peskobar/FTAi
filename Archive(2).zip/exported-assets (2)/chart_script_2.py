import plotly.graph_objects as go
import plotly.express as px
import json

# Data from the provided JSON
data = {
    "layers": [
        {"name": "Plugin Development", "level": 3, "components": ["Rust Source Code", "WIT Interfaces", "Capability Manifest", "Plugin Signing"], "security": "Code signing, SLSA L3"},
        {"name": "Marketplace Infrastructure", "level": 2, "components": ["Plugin Registry", "Version Control", "Security Scanner", "Access Control"], "security": "Capability validation, Supply chain security"},
        {"name": "Runtime Environment", "level": 1, "components": ["Wasmtime Host", "Sandbox Environment", "Resource Monitor", "Hot Reload"], "security": "Isolation, Resource limits"}
    ],
    "data_flows": [
        {"from": "Plugin Development", "to": "Marketplace Infrastructure", "type": "publish", "security": "Signed .wasm + manifest"},
        {"from": "Marketplace Infrastructure", "to": "Runtime Environment", "type": "install", "security": "Verified components only"},
        {"from": "Runtime Environment", "to": "Marketplace Infrastructure", "type": "telemetry", "security": "Usage metrics"}
    ],
    "capabilities": ["filesystem.read", "network.http", "compute.intensive", "storage.write"],
    "security_model": "Capability-based: Explicit permission grants, No ambient authority, Principle of least privilege"
}

# Create figure
fig = go.Figure()

# Colors for layers (using brand colors in order)
colors = ['#1FB8CD', '#FFC185', '#ECEBD5']

# Create layer rectangles and components
y_positions = [3, 2, 1]  # Top to bottom
layer_heights = [0.8, 0.8, 0.8]

for i, layer in enumerate(data["layers"]):
    y_pos = y_positions[i]
    color = colors[i]
    
    # Add layer background rectangle
    fig.add_shape(
        type="rect",
        x0=0, x1=10,
        y0=y_pos - layer_heights[i]/2, y1=y_pos + layer_heights[i]/2,
        fillcolor=color,
        opacity=0.3,
        line=dict(color=color, width=2),
    )
    
    # Add layer title
    fig.add_trace(go.Scatter(
        x=[5], y=[y_pos + 0.3],
        text=[layer["name"]],
        mode='text',
        textfont=dict(size=14, color='black'),
        showlegend=False,
        cliponaxis=False,
        hovertemplate=f'<b>{layer["name"]}</b><br>Security: {layer["security"]}<extra></extra>'
    ))
    
    # Add components as boxes
    x_positions = [2, 4, 6, 8]  # Spread components across the layer
    for j, component in enumerate(layer["components"]):
        if j < len(x_positions):
            # Shorten component names to fit 15 character limit
            short_name = component.replace("Source Code", "Code").replace("Environment", "Env").replace("Security", "Sec")
            if len(short_name) > 15:
                short_name = short_name[:12] + "..."
            
            fig.add_trace(go.Scatter(
                x=[x_positions[j]], y=[y_pos - 0.1],
                text=[short_name],
                mode='markers+text',
                marker=dict(size=20, color=color, symbol='square'),
                textposition='middle center',
                textfont=dict(size=8, color='white'),
                showlegend=False,
                cliponaxis=False,
                hovertemplate=f'<b>{component}</b><br>Layer: {layer["name"]}<br>Security: {layer["security"]}<extra></extra>'
            ))

# Add data flow arrows
arrow_colors = ['#5D878F', '#D2BA4C', '#B4413C']
for idx, flow in enumerate(data["data_flows"]):
    from_layer = next(l for l in data["layers"] if l["name"] == flow["from"])
    to_layer = next(l for l in data["layers"] if l["name"] == flow["to"])
    
    from_y = y_positions[data["layers"].index(from_layer)]
    to_y = y_positions[data["layers"].index(to_layer)]
    
    # Offset arrows horizontally to avoid overlap
    x_offset = 8.5 + (idx * 0.3)
    
    # Add arrow line
    fig.add_trace(go.Scatter(
        x=[x_offset, x_offset], y=[from_y - 0.35, to_y + 0.35],
        mode='lines',
        line=dict(color=arrow_colors[idx % len(arrow_colors)], width=3),
        showlegend=False,
        cliponaxis=False,
        hovertemplate=f'<b>{flow["type"].capitalize()}</b><br>From: {flow["from"]}<br>To: {flow["to"]}<br>Security: {flow["security"]}<extra></extra>'
    ))
    
    # Add arrow head
    fig.add_trace(go.Scatter(
        x=[x_offset], y=[to_y + 0.35],
        mode='markers',
        marker=dict(size=10, symbol='triangle-up', color=arrow_colors[idx % len(arrow_colors)]),
        showlegend=False,
        cliponaxis=False,
        hovertemplate=f'<b>{flow["type"].capitalize()}</b><br>From: {flow["from"]}<br>To: {flow["to"]}<br>Security: {flow["security"]}<extra></extra>'
    ))

# Add capabilities info
cap_text = "Cap: " + ", ".join(data["capabilities"][:2]) + "..."
fig.add_trace(go.Scatter(
    x=[1], y=[0.3],
    text=[cap_text],
    mode='text',
    textfont=dict(size=10, color='#13343B'),
    showlegend=False,
    cliponaxis=False,
    hovertemplate=f'<b>Available Capabilities:</b><br>' + '<br>'.join(data["capabilities"]) + '<extra></extra>'
))

# Add security model info
fig.add_trace(go.Scatter(
    x=[1], y=[4.1],
    text=["Sec: Cap-based"],
    mode='text',
    textfont=dict(size=10, color='#13343B'),
    showlegend=False,
    cliponaxis=False,
    hovertemplate=f'<b>Security Model:</b><br>{data["security_model"]}<extra></extra>'
))

# Add security boundaries as dashed lines
for i in range(len(y_positions)):
    y_boundary = y_positions[i] - 0.5
    if i < len(y_positions) - 1:  # Don't add boundary below last layer
        fig.add_shape(
            type="line",
            x0=0, x1=10,
            y0=y_boundary, y1=y_boundary,
            line=dict(color="#964325", width=2, dash="dash"),
        )

# Update layout
fig.update_layout(
    title="WASM Plugin Marketplace Architecture",
    xaxis=dict(range=[-0.5, 10.5], showgrid=False, showticklabels=False, zeroline=False),
    yaxis=dict(range=[0, 4.5], showgrid=False, showticklabels=False, zeroline=False),
    plot_bgcolor='white'
)

# Save the chart
fig.write_image("wasm_marketplace_architecture.png")