import plotly.graph_objects as go
import plotly.express as px
import json

# Load the data
data = {
    "components": [
        {"category": "Current_0_3_0", "name": "Axum HTTP API", "x": 1, "y": 8},
        {"category": "Current_0_3_0", "name": "Prometheus Metrics", "x": 1, "y": 7},
        {"category": "Current_0_3_0", "name": "Queue Manager", "x": 1, "y": 6},
        {"category": "Current_0_3_0", "name": "Rust Patching Engine", "x": 1, "y": 5},
        {"category": "Current_0_3_0", "name": "File Storage", "x": 1, "y": 4},
        {"category": "Target_2025_2026", "name": "Axum + OTEL Middleware", "x": 3.2, "y": 8},
        {"category": "Target_2025_2026", "name": "OTEL OTLP Exporter", "x": 3.2, "y": 7},
        {"category": "Target_2025_2026", "name": "LSTM Autoscaler", "x": 3.2, "y": 6},
        {"category": "Target_2025_2026", "name": "Circuit Breaker", "x": 3.2, "y": 5.5},
        {"category": "Target_2025_2026", "name": "SBOM Generator", "x": 3.2, "y": 5},
        {"category": "Target_2025_2026", "name": "On-device AI (TFLite)", "x": 3.2, "y": 4.5},
        {"category": "Target_2025_2026", "name": "Edge Runtime", "x": 3.2, "y": 4},
        {"category": "Target_2025_2026", "name": "WASM Marketplace", "x": 3.2, "y": 3.5},
        {"category": "Target_2025_2026", "name": "Gemini Assistant", "x": 3.2, "y": 3}
    ],
    "migrations": [
        {"from": "Prometheus Metrics", "to": "OTEL OTLP Exporter", "phase": "Q3 2025"},
        {"from": "Queue Manager", "to": "LSTM Autoscaler", "phase": "Q4 2025"},
        {"from": "Rust Patching Engine", "to": "On-device AI (TFLite)", "phase": "Q4 2025"},
        {"from": "File Storage", "to": "Edge Runtime", "phase": "H1 2026"}
    ],
    "metrics": {
        "current_latency": "2.4s",
        "target_latency": "≤1.5s", 
        "current_success": "95%",
        "target_success": "≥99%",
        "target_trace_coverage": "100%"
    }
}

# Create figure
fig = go.Figure()

# Define colors for current vs target
colors = {"Current_0_3_0": "#1FB8CD", "Target_2025_2026": "#FFC185"}

# Add current components with better text handling
current_components = [c for c in data["components"] if c["category"] == "Current_0_3_0"]
current_names = []
for comp in current_components:
    name = comp["name"]
    # Better abbreviations for current components
    if "HTTP" in name:
        name = "Axum HTTP API"
    elif "Prometheus" in name:
        name = "Prometheus"
    elif "Queue" in name:
        name = "Queue Mgr"
    elif "Rust" in name:
        name = "Rust Engine"
    elif "File" in name:
        name = "File Storage"
    current_names.append(name)

current_x = [c["x"] for c in current_components]
current_y = [c["y"] for c in current_components]

fig.add_trace(go.Scatter(
    x=current_x,
    y=current_y,
    mode='markers+text',
    marker=dict(size=50, symbol='square', color=colors["Current_0_3_0"]),
    text=current_names,
    textposition='middle center',
    textfont=dict(size=9, color='white'),
    name="Current v0.3.0",
    cliponaxis=False,
    hovertemplate='%{text}<br>Current Architecture<extra></extra>'
))

# Add target components with better text handling
target_components = [c for c in data["components"] if c["category"] == "Target_2025_2026"]
target_names = []
for comp in target_components:
    name = comp["name"]
    # Better abbreviations for target components
    if "Axum + OTEL" in name:
        name = "Axum+OTEL"
    elif "OTEL OTLP" in name:
        name = "OTLP Export"
    elif "LSTM" in name:
        name = "LSTM Scale"
    elif "Circuit" in name:
        name = "Circuit Brk"
    elif "SBOM" in name:
        name = "SBOM Gen"
    elif "On-device" in name:
        name = "AI (TFLite)"
    elif "Edge" in name:
        name = "Edge Runtime"
    elif "WASM" in name:
        name = "WASM Market"
    elif "Gemini" in name:
        name = "Gemini AI"
    target_names.append(name)

target_x = [c["x"] for c in target_components]
target_y = [c["y"] for c in target_components]

fig.add_trace(go.Scatter(
    x=target_x,
    y=target_y,
    mode='markers+text',
    marker=dict(size=50, symbol='square', color=colors["Target_2025_2026"]),
    text=target_names,
    textposition='middle center',
    textfont=dict(size=9, color='black'),
    name="Target 2025-26",
    cliponaxis=False,
    hovertemplate='%{text}<br>Target Architecture<extra></extra>'
))

# Create mapping for component positions (updated with new x positions)
comp_pos = {}
for i, comp in enumerate(data["components"]):
    if comp["category"] == "Target_2025_2026":
        comp_pos[comp["name"]] = (3.2, comp["y"])
    else:
        comp_pos[comp["name"]] = (comp["x"], comp["y"])

# Add migration arrows with more prominent phase labels
phase_colors = {"Q3 2025": "#B4413C", "Q4 2025": "#964325", "H1 2026": "#944454"}

for i, migration in enumerate(data["migrations"]):
    from_pos = comp_pos[migration["from"]]
    to_pos = comp_pos[migration["to"]]
    
    # Add arrow line
    fig.add_shape(
        type="line",
        x0=from_pos[0] + 0.25, y0=from_pos[1],
        x1=to_pos[0] - 0.25, y1=to_pos[1],
        line=dict(color="#5D878F", width=2),
    )
    
    # Add arrowhead
    fig.add_shape(
        type="line",
        x0=to_pos[0] - 0.25, y0=to_pos[1],
        x1=to_pos[0] - 0.35, y1=to_pos[1] + 0.08,
        line=dict(color="#5D878F", width=2),
    )
    fig.add_shape(
        type="line", 
        x0=to_pos[0] - 0.25, y0=to_pos[1],
        x1=to_pos[0] - 0.35, y1=to_pos[1] - 0.08,
        line=dict(color="#5D878F", width=2),
    )
    
    # Add more prominent phase label on arrow
    mid_x = (from_pos[0] + to_pos[0]) / 2
    mid_y = from_pos[1] + 0.15 + (i * 0.05)  # Slight offset to avoid overlap
    
    fig.add_trace(go.Scatter(
        x=[mid_x],
        y=[mid_y], 
        mode='text',
        text=[migration["phase"]],
        textfont=dict(size=11, color=phase_colors.get(migration["phase"], "#5D878F"), family="Arial Black"),
        showlegend=False,
        cliponaxis=False,
        hovertemplate='Migration Phase: %{text}<extra></extra>'
    ))

# Update layout
fig.update_layout(
    title="TUI-Patcher Refactor: ≤1.5s, ≥99%, 100%",
    showlegend=True,
    legend=dict(orientation='h', yanchor='bottom', y=1.05, xanchor='center', x=0.5),
    xaxis=dict(
        range=[0.5, 3.7],
        tickmode='array',
        tickvals=[1, 3.2],
        ticktext=['Current v0.3.0', 'Target 2025-26'],
        showgrid=False
    ),
    yaxis=dict(
        range=[2.5, 8.5],
        showgrid=False,
        showticklabels=False
    ),
    plot_bgcolor='white'
)

# Save the chart
fig.write_image("tui_patcher_roadmap.png")