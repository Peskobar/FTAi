import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
from datetime import datetime, timedelta

# Load the data
data = {
    "tasks": [
        {"task": "OTEL OTLP Refactor", "category": "Infrastructure", "start_week": 1, "duration": 2, "story_points": 8, "status": "planned"},
        {"task": "Traceparent Middleware", "category": "Monitoring", "start_week": 3, "duration": 2, "story_points": 5, "status": "planned", "depends_on": ["OTEL OTLP Refactor"]},
        {"task": "Slack Alert System", "category": "Monitoring", "start_week": 5, "duration": 2, "story_points": 3, "status": "planned", "depends_on": ["Traceparent Middleware"]},
        {"task": "SBOM Pipeline", "category": "Security", "start_week": 7, "duration": 2, "story_points": 6, "status": "planned", "depends_on": ["Slack Alert System"]},
        {"task": "Circuit Breaker", "category": "Infrastructure", "start_week": 9, "duration": 2, "story_points": 7, "status": "planned", "depends_on": ["SBOM Pipeline"]},
        {"task": "Performance Test", "category": "Testing", "start_week": 11, "duration": 2, "story_points": 4, "status": "planned", "depends_on": ["Circuit Breaker"]}
    ]
}

# Create a base date (July 1, 2025) and calculate start and end dates for each task
base_date = datetime(2025, 7, 1)

# Prepare data for Gantt chart
gantt_data = []
task_positions = {}  # To track task positions for dependencies

for i, task in enumerate(data["tasks"]):
    start_date = base_date + timedelta(weeks=task["start_week"]-1)
    end_date = start_date + timedelta(weeks=task["duration"])
    task_name = task["task"]
    
    gantt_data.append({
        "Task": task_name,
        "Start": start_date,
        "Finish": end_date,
        "Category": task["category"],
        "Story Points": task["story_points"],
        "Status": task["status"],
        "Duration": f"{task['duration']}w",
        "TaskIndex": i
    })
    
    # Store task position for dependency arrows
    task_positions[task_name] = {
        "index": i,
        "start": start_date,
        "end": end_date,
        "start_week": task["start_week"]
    }

df = pd.DataFrame(gantt_data)

# Create the Gantt chart
fig = px.timeline(df, x_start="Start", x_end="Finish", y="Task", 
                  color="Category",
                  hover_data=["Story Points", "Duration", "Status"],
                  color_discrete_map={
                      "Infrastructure": "#1FB8CD",
                      "Monitoring": "#FFC185", 
                      "Security": "#ECEBD5",
                      "Testing": "#5D878F"
                  })

# Add story points as text annotations on each bar
for i, row in df.iterrows():
    # Calculate middle point of the bar for text placement
    start_ts = row['Start'].timestamp() * 1000  # Convert to milliseconds
    end_ts = row['Finish'].timestamp() * 1000
    mid_point = datetime.fromtimestamp((start_ts + end_ts) / 2 / 1000)
    
    fig.add_annotation(
        x=mid_point,
        y=i,
        text=f"{row['Story Points']}pts",
        showarrow=False,
        font=dict(color="white", size=10, family="Arial Black"),
        bgcolor="rgba(0,0,0,0.7)",
        bordercolor="white",
        borderwidth=1
    )

# Add dependency arrows
dependency_pairs = [
    ("OTEL OTLP Refactor", "Traceparent Middleware"),
    ("Traceparent Middleware", "Slack Alert System"),
    ("Slack Alert System", "SBOM Pipeline"),
    ("SBOM Pipeline", "Circuit Breaker"),
    ("Circuit Breaker", "Performance Test")
]

for from_task, to_task in dependency_pairs:
    from_pos = task_positions[from_task]
    to_pos = task_positions[to_task]
    
    # Add arrow line from end of first task to start of second task
    fig.add_annotation(
        x=to_pos['start'],
        y=to_pos['index'],
        ax=from_pos['end'],
        ay=from_pos['index'],
        arrowhead=2,
        arrowsize=1,
        arrowwidth=2,
        arrowcolor="#13343B",
        showarrow=True
    )

# Update layout
fig.update_layout(
    title="Q3 2025 Hardening & Visibility Sprint",
    xaxis_title="Weeks",
    yaxis_title="Tasks",
    legend=dict(orientation='h', yanchor='bottom', y=1.05, xanchor='center', x=0.5)
)

# Update x-axis to show weeks
fig.update_xaxes(
    dtick=604800000,  # 1 week in milliseconds
    tickformat="%b %d",
    tickangle=45
)

# Update hover template
fig.update_traces(
    hovertemplate="<b>%{y}</b><br>" +
                  "Start: %{x}<br>" +
                  "End: %{base}<br>" +
                  "Story Pts: %{customdata[0]}<br>" +
                  "Duration: %{customdata[1]}<br>" +
                  "Status: %{customdata[2]}<br>" +
                  "<extra></extra>"
)

# Save the chart
fig.write_image("gantt_chart.png")