import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
import numpy as np

# Simplified and better spaced component layout
components = [
    # FastAPI Application Layer (Blue)
    {"name": "FastAPI App", "type": "FastAPI", "color": "#0066CC", "x": 5, "y": 6, "size": 35},
    {"name": "Auth Router", "type": "FastAPI", "color": "#0066CC", "x": 2, "y": 8, "size": 25},
    {"name": "Queue Router", "type": "FastAPI", "color": "#0066CC", "x": 4, "y": 8, "size": 25},
    {"name": "Patch Router", "type": "FastAPI", "color": "#0066CC", "x": 6, "y": 8, "size": 25},
    {"name": "Health Router", "type": "FastAPI", "color": "#0066CC", "x": 8, "y": 8, "size": 25},
    
    # Middleware (Blue)
    {"name": "CORS Mid", "type": "FastAPI", "color": "#0066CC", "x": 3, "y": 7, "size": 20},
    {"name": "Auth Mid", "type": "FastAPI", "color": "#0066CC", "x": 5, "y": 7, "size": 20},
    {"name": "Error Mid", "type": "FastAPI", "color": "#0066CC", "x": 7, "y": 7, "size": 20},
    
    # Database Layer (Green)
    {"name": "PostgreSQL", "type": "Database", "color": "#28A745", "x": 2, "y": 4, "size": 35},
    {"name": "SQLAlchemy", "type": "Database", "color": "#28A745", "x": 4, "y": 4, "size": 25},
    {"name": "User Model", "type": "Database", "color": "#28A745", "x": 1, "y": 3, "size": 20},
    {"name": "Job Model", "type": "Database", "color": "#28A745", "x": 3, "y": 3, "size": 20},
    {"name": "Alembic", "type": "Database", "color": "#28A745", "x": 5, "y": 3, "size": 20},
    
    # Background Processing (Red)
    {"name": "Redis", "type": "Redis/Celery", "color": "#DC3545", "x": 8, "y": 4, "size": 35},
    {"name": "Celery Work", "type": "Redis/Celery", "color": "#DC3545", "x": 10, "y": 4, "size": 25},
    {"name": "Task Queue", "type": "Redis/Celery", "color": "#DC3545", "x": 9, "y": 3, "size": 20},
    {"name": "Job Status", "type": "Redis/Celery", "color": "#DC3545", "x": 9, "y": 5, "size": 20},
    
    # Security Layer (Orange)
    {"name": "JWT Auth", "type": "Security", "color": "#FFC107", "x": 1, "y": 6, "size": 25},
    {"name": "RBAC", "type": "Security", "color": "#FFC107", "x": 1, "y": 5, "size": 20},
    {"name": "Rate Limit", "type": "Security", "color": "#FFC107", "x": 2, "y": 5.5, "size": 20},
    
    # External Services (Purple)
    {"name": "OpenTelem", "type": "External", "color": "#6610F2", "x": 9, "y": 6, "size": 25},
    {"name": "Prometheus", "type": "External", "color": "#6610F2", "x": 11, "y": 6, "size": 25},
    {"name": "TensorFlow", "type": "External", "color": "#6610F2", "x": 10, "y": 7, "size": 20},
    {"name": "Notifications", "type": "External", "color": "#6610F2", "x": 11, "y": 5, "size": 20}
]

# Create the figure
fig = go.Figure()

# Add components with larger, more readable text
for comp in components:
    fig.add_trace(go.Scatter(
        x=[comp["x"]], 
        y=[comp["y"]],
        mode='markers+text',
        marker=dict(
            size=comp["size"],
            color=comp["color"],
            line=dict(width=2, color='white'),
            symbol='circle'
        ),
        text=comp["name"],
        textposition="middle center",
        textfont=dict(size=11, color='white', family='Arial Black'),
        name=comp["type"],
        showlegend=True,
        hovertemplate=f"<b>{comp['name']}</b><br>Layer: {comp['type']}<br><extra></extra>"
    ))

# Key connections with thicker lines for better visibility
key_connections = [
    # FastAPI to main routers
    {"from": (5, 6), "to": (2, 8), "color": "#0066CC", "width": 3},
    {"from": (5, 6), "to": (4, 8), "color": "#0066CC", "width": 3},
    {"from": (5, 6), "to": (6, 8), "color": "#0066CC", "width": 3},
    {"from": (5, 6), "to": (8, 8), "color": "#0066CC", "width": 3},
    
    # Database connections
    {"from": (5, 6), "to": (2, 4), "color": "#28A745", "width": 4},
    {"from": (2, 4), "to": (4, 4), "color": "#28A745", "width": 3},
    
    # Redis/Celery connections
    {"from": (4, 8), "to": (8, 4), "color": "#DC3545", "width": 4},
    {"from": (8, 4), "to": (10, 4), "color": "#DC3545", "width": 3},
    
    # Security connections
    {"from": (1, 6), "to": (5, 6), "color": "#FFC107", "width": 4},
    {"from": (1, 5), "to": (5, 6), "color": "#FFC107", "width": 3},
    
    # External services connections
    {"from": (9, 6), "to": (5, 6), "color": "#6610F2", "width": 3},
    {"from": (11, 6), "to": (9, 6), "color": "#6610F2", "width": 3}
]

# Add connection lines with better visibility
for conn in key_connections:
    fig.add_trace(go.Scatter(
        x=[conn["from"][0], conn["to"][0]], 
        y=[conn["from"][1], conn["to"][1]],
        mode='lines',
        line=dict(
            color=conn["color"], 
            width=conn["width"],
            dash='solid'
        ),
        opacity=0.7,
        showlegend=False,
        hoverinfo='skip'
    ))

# Add section labels as annotations with larger text
fig.add_annotation(
    x=5, y=8.7,
    text="API Routers",
    showarrow=False,
    font=dict(size=14, color="#0066CC", family="Arial Black"),
    bgcolor="rgba(255,255,255,0.8)",
    bordercolor="#0066CC",
    borderwidth=1
)

fig.add_annotation(
    x=3, y=2.3,
    text="Database Layer",
    showarrow=False,
    font=dict(size=14, color="#28A745", family="Arial Black"),
    bgcolor="rgba(255,255,255,0.8)",
    bordercolor="#28A745",
    borderwidth=1
)

fig.add_annotation(
    x=9, y=2.3,
    text="Background Proc",
    showarrow=False,
    font=dict(size=14, color="#DC3545", family="Arial Black"),
    bgcolor="rgba(255,255,255,0.8)",
    bordercolor="#DC3545",
    borderwidth=1
)

fig.add_annotation(
    x=1.5, y=4.3,
    text="Security",
    showarrow=False,
    font=dict(size=14, color="#FFC107", family="Arial Black"),
    bgcolor="rgba(255,255,255,0.8)",
    bordercolor="#FFC107",
    borderwidth=1
)

fig.add_annotation(
    x=10.5, y=7.7,
    text="External Svcs",
    showarrow=False,
    font=dict(size=14, color="#6610F2", family="Arial Black"),
    bgcolor="rgba(255,255,255,0.8)",
    bordercolor="#6610F2",
    borderwidth=1
)

# Update layout with better spacing
fig.update_layout(
    title=dict(
        text="SmartFix Core API Architecture",
        font=dict(size=18, family="Arial Black"),
        x=0.5
    ),
    xaxis=dict(
        showgrid=False,
        showticklabels=False,
        zeroline=False,
        range=[0, 12]
    ),
    yaxis=dict(
        showgrid=False,
        showticklabels=False,
        zeroline=False,
        range=[2, 9]
    ),
    plot_bgcolor='rgba(248,249,250,0.3)',
    paper_bgcolor='white',
    legend=dict(
        orientation='h', 
        yanchor='bottom', 
        y=1.02, 
        xanchor='center', 
        x=0.5,
        font=dict(size=12)
    ),
    showlegend=True
)

# Remove duplicate legend entries
seen_names = set()
for trace in fig.data:
    if hasattr(trace, 'name') and trace.name in seen_names:
        trace.showlegend = False
    elif hasattr(trace, 'name'):
        seen_names.add(trace.name)

fig.write_image("smartfix_architecture_clean.png", width=1200, height=800, scale=2)