// Application data from backend
const API_DATA = {
  endpoints: [
    {
      id: "auth_login",
      method: "POST",
      path: "/api/v1/auth/login",
      description: "JWT Authentication",
      parameters: ["username", "password"],
      response: {"access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ1c2VybmFtZSIsInJvbGUiOiJhZG1pbiIsImV4cCI6MTY0MzY3MzAwMH0.sample", "token_type": "bearer", "expires_in": 3600}
    },
    {
      id: "queue_enqueue",
      method: "POST", 
      path: "/api/v1/queue/enqueue",
      description: "Dodaj zadanie do kolejki patchy",
      parameters: ["apk_path", "patch_type", "priority"],
      response: {"job_id": "job-" + Math.random().toString(36).substr(2, 9), "status": "queued", "estimated_time": 120}
    },
    {
      id: "queue_status",
      method: "GET",
      path: "/api/v1/queue/status/{job_id}",
      description: "Sprawdź status zadania",
      parameters: ["job_id"],
      response: {"job_id": "job-001", "status": "processing", "progress": 65, "eta": 75}
    },
    {
      id: "patches_list",
      method: "GET",
      path: "/api/v1/patches/",
      description: "Lista wszystkich patchy",
      parameters: ["page", "limit", "status"],
      response: {"patches": [{"id": 1, "filename": "security-fix.apk", "status": "completed"}, {"id": 2, "filename": "ui-update.aab", "status": "processing"}], "total": 156, "page": 1, "pages": 8}
    },
    {
      id: "patches_upload",
      method: "POST",
      path: "/api/v1/patches/upload",
      description: "Upload pliku APK/AAB",
      parameters: ["file", "metadata"],
      response: {"patch_id": "patch-" + Math.random().toString(36).substr(2, 9), "filename": "app.apk", "size": 12456789, "status": "uploaded"}
    },
    {
      id: "plugins_marketplace",
      method: "GET",
      path: "/api/v1/plugins/marketplace",
      description: "Przeglądaj marketplace pluginów",
      parameters: ["category", "search"],
      response: {"plugins": [{"name": "Security Scanner", "version": "1.2.0", "category": "security"}, {"name": "UI Fixer", "version": "2.1.0", "category": "ui"}], "categories": ["security", "performance", "ui"], "total": 42}
    },
    {
      id: "health",
      method: "GET", 
      path: "/api/v1/health",
      description: "Kontrola stanu systemu",
      parameters: [],
      response: {"status": "healthy", "database": "connected", "redis": "connected", "workers": 3}
    },
    {
      id: "metrics",
      method: "GET",
      path: "/api/v1/metrics", 
      description: "Metryki Prometheus",
      parameters: [],
      response: {"queue_size": 7, "success_rate": 0.95, "avg_latency": 2.1, "active_workers": 3}
    }
  ],
  users: [
    {"id": 1, "username": "admin", "role": "administrator", "status": "active"},
    {"id": 2, "username": "developer", "role": "developer", "status": "active"}, 
    {"id": 3, "username": "viewer", "role": "viewer", "status": "active"}
  ],
  queueJobs: [
    {"id": "job-001", "patch": "security-fix.apk", "status": "processing", "progress": 65, "eta": "2min"},
    {"id": "job-002", "patch": "ui-update.aab", "status": "queued", "progress": 0, "eta": "5min"},
    {"id": "job-003", "patch": "performance.apk", "status": "completed", "progress": 100, "eta": "0min"},
    {"id": "job-004", "patch": "hotfix.apk", "status": "failed", "progress": 25, "eta": "N/A"}
  ]
};

// Application state
let currentUser = null;
let jwtToken = null;
let tokenExpiry = null;

// Tab management
function initTabNavigation() {
  console.log('Initializing tab navigation...');
  const tabButtons = document.querySelectorAll('.nav__tab');
  const tabContents = document.querySelectorAll('.tab-content');

  console.log('Found tabs:', tabButtons.length);
  console.log('Found content sections:', tabContents.length);

  tabButtons.forEach((button, index) => {
    console.log(`Setting up tab ${index}:`, button.getAttribute('data-tab'));
    
    button.addEventListener('click', function(e) {
      e.preventDefault();
      const tabId = this.getAttribute('data-tab');
      console.log('Tab clicked:', tabId);
      
      // Remove active class from all tabs
      tabButtons.forEach(tab => {
        tab.classList.remove('nav__tab--active');
      });
      
      // Add active class to clicked tab
      this.classList.add('nav__tab--active');
      
      // Hide all content
      tabContents.forEach(content => {
        content.classList.remove('tab-content--active');
      });
      
      // Show selected content
      const targetContent = document.getElementById(tabId);
      if (targetContent) {
        targetContent.classList.add('tab-content--active');
        console.log('Activated content for:', tabId);
      } else {
        console.error('No content found for tab:', tabId);
      }
      
      // Trigger tab-specific updates
      onTabSwitch(tabId);
    });
  });
}

function onTabSwitch(tabId) {
  console.log('Switched to tab:', tabId);
  
  switch(tabId) {
    case 'queue-management':
      updateQueueDisplay();
      break;
    case 'system-monitoring':
      updateSystemMetrics();
      break;
    case 'auth-demo':
      updateAuthDisplay();
      break;
  }
}

// API Explorer functionality
function initApiExplorer() {
  console.log('Initializing API Explorer...');
  
  const endpointSelector = document.getElementById('endpoint-selector');
  const executeBtn = document.getElementById('execute-btn');
  
  if (!endpointSelector || !executeBtn) {
    console.error('API Explorer elements not found');
    return;
  }

  endpointSelector.addEventListener('change', function(e) {
    console.log('Endpoint selected:', e.target.value);
    selectEndpoint(e.target.value);
  });

  executeBtn.addEventListener('click', function() {
    console.log('Execute button clicked');
    executeRequest();
  });
  
  console.log('API Explorer initialized');
}

function selectEndpoint(endpointId) {
  console.log('Selecting endpoint:', endpointId);
  
  if (!endpointId) {
    clearEndpointDetails();
    return;
  }

  const endpoint = API_DATA.endpoints.find(ep => ep.id === endpointId);
  if (endpoint) {
    displayEndpointDetails(endpoint);
  }
}

function clearEndpointDetails() {
  const requestInfo = document.getElementById('request-info');
  const requestParams = document.getElementById('request-params');
  const executeBtn = document.getElementById('execute-btn');
  const responseStatus = document.getElementById('response-status');
  const responseBody = document.getElementById('response-body');
  const curlCommand = document.getElementById('curl-command');
  
  if (requestInfo) requestInfo.innerHTML = '<p>Wybierz endpoint aby zobaczyć szczegóły</p>';
  if (requestParams) requestParams.classList.add('hidden');
  if (executeBtn) executeBtn.classList.add('hidden');
  if (responseStatus) responseStatus.classList.add('hidden');
  if (responseBody) responseBody.classList.add('hidden');
  if (curlCommand) curlCommand.classList.add('hidden');
}

function displayEndpointDetails(endpoint) {
  const requestInfo = document.getElementById('request-info');
  const requestParams = document.getElementById('request-params');
  const paramsForm = document.getElementById('params-form');
  const executeBtn = document.getElementById('execute-btn');

  // Show endpoint details
  requestInfo.innerHTML = `
    <div class="endpoint-details">
      <p><strong>Metoda:</strong> <span class="method-badge method-badge--${endpoint.method.toLowerCase()}">${endpoint.method}</span></p>
      <p><strong>Ścieżka:</strong> <code>${endpoint.path}</code></p>
      <p><strong>Opis:</strong> ${endpoint.description}</p>
    </div>
  `;

  // Show parameters if any
  if (endpoint.parameters && endpoint.parameters.length > 0) {
    let paramsHtml = '';
    endpoint.parameters.forEach(param => {
      const placeholder = getParameterPlaceholder(param);
      paramsHtml += `
        <div class="param-input">
          <label class="form-label">${param}:</label>
          <input type="text" class="form-control" name="${param}" placeholder="${placeholder}">
        </div>
      `;
    });
    paramsForm.innerHTML = paramsHtml;
    requestParams.classList.remove('hidden');
  } else {
    requestParams.classList.add('hidden');
  }

  executeBtn.classList.remove('hidden');
  
  // Store current endpoint for execution
  window.currentEndpoint = endpoint;
}

function getParameterPlaceholder(param) {
  const placeholders = {
    'username': 'admin',
    'password': 'demo123',
    'apk_path': '/uploads/app.apk',
    'patch_type': 'security',
    'priority': 'high',
    'job_id': 'job-001',
    'page': '1',
    'limit': '20',
    'status': 'completed',
    'file': 'app.apk',
    'metadata': '{"version": "1.0.0"}',
    'category': 'security',
    'search': 'scanner'
  };
  return placeholders[param] || `Enter ${param}`;
}

function executeRequest() {
  if (!window.currentEndpoint) {
    console.error('No endpoint selected');
    return;
  }

  console.log('Executing request for:', window.currentEndpoint.path);

  // Show loading state
  const executeBtn = document.getElementById('execute-btn');
  const originalText = executeBtn.textContent;
  executeBtn.textContent = 'Wykonywanie...';
  executeBtn.disabled = true;

  // Collect parameters
  const paramInputs = document.querySelectorAll('#params-form input');
  const params = {};
  
  paramInputs.forEach(input => {
    params[input.name] = input.value || input.placeholder;
  });

  // Simulate API call delay
  setTimeout(() => {
    displayResponse(params);
    executeBtn.textContent = originalText;
    executeBtn.disabled = false;
  }, 500 + Math.random() * 1000);
}

function displayResponse(params) {
  const responseStatus = document.getElementById('response-status');
  const statusCode = document.getElementById('status-code');
  const statusText = document.getElementById('status-text');
  const responseBody = document.getElementById('response-body');
  const curlCommand = document.getElementById('curl-command');
  const curlText = document.getElementById('curl-text');

  if (!window.currentEndpoint) return;

  // Simulate response
  let statusCodes = [200, 201];
  let isError = false;

  // Special case for auth without proper credentials
  if (window.currentEndpoint.id === 'auth_login' && 
      (!params.username || !['admin', 'developer', 'viewer'].includes(params.username))) {
    statusCodes = [401];
    isError = true;
  }

  const responseCode = statusCodes[Math.floor(Math.random() * statusCodes.length)];
  const responseData = isError ? 
    {"error": "Invalid credentials", "message": "Username or password incorrect"} :
    window.currentEndpoint.response;

  // Update response display
  statusCode.textContent = responseCode;
  statusCode.className = `status-code status-code--${isError ? 'error' : 'success'}`;
  statusText.textContent = isError ? 'Unauthorized' : 'OK';

  responseBody.textContent = JSON.stringify(responseData, null, 2);

  // Generate curl command
  const curlCmd = generateCurlCommand(params);
  curlText.textContent = curlCmd;

  // Show response elements
  responseStatus.classList.remove('hidden');
  responseBody.classList.remove('hidden');
  curlCommand.classList.remove('hidden');

  // Handle special responses
  if (window.currentEndpoint.id === 'auth_login' && !isError) {
    handleLoginResponse(responseData, params.username);
  }
}

function generateCurlCommand(params) {
  let cmd = `curl -X ${window.currentEndpoint.method} \\\n`;
  cmd += `  "https://api.smartfix.core${window.currentEndpoint.path}" \\\n`;
  cmd += `  -H "Content-Type: application/json" \\\n`;
  
  if (jwtToken) {
    cmd += `  -H "Authorization: Bearer ${jwtToken.substring(0, 20)}..." \\\n`;
  }
  
  if (window.currentEndpoint.method !== 'GET' && Object.keys(params).length > 0) {
    cmd += `  -d '${JSON.stringify(params)}'`;
  }
  
  return cmd;
}

function handleLoginResponse(responseData, username) {
  // Set JWT token and user info
  jwtToken = responseData.access_token;
  tokenExpiry = Date.now() + (responseData.expires_in * 1000);
  currentUser = API_DATA.users.find(u => u.username === username);
  
  console.log('Login successful for:', username);
  
  // Update UI
  updateAuthenticationStatus();
  
  // Show success message
  setTimeout(() => {
    alert('Logowanie pomyślne! Sprawdź zakładkę Autoryzacja dla szczegółów tokenu.');
  }, 500);
}

function updateAuthenticationStatus() {
  const jwtStatus = document.getElementById('jwt-status');
  const userBadge = document.querySelector('.user-badge');
  
  if (currentUser && jwtToken) {
    jwtStatus.textContent = 'Token aktywny';
    jwtStatus.style.color = 'var(--color-success)';
    userBadge.textContent = `${currentUser.username} (${currentUser.role})`;
    userBadge.style.background = 'var(--color-success)';
    userBadge.style.color = 'white';
  } else {
    jwtStatus.textContent = 'Brak tokenu';
    jwtStatus.style.color = '';
    userBadge.textContent = 'Niezalogowany';
    userBadge.style.background = '';
    userBadge.style.color = '';
  }
}

// Authentication Demo functionality
function initAuthDemo() {
  console.log('Initializing Auth Demo...');
  
  const loginForm = document.getElementById('login-form');
  const refreshTokenBtn = document.getElementById('refresh-token-btn');
  const logoutBtn = document.getElementById('logout-btn');

  if (loginForm) {
    loginForm.addEventListener('submit', function(e) {
      e.preventDefault();
      handleLogin();
    });
  }

  if (refreshTokenBtn) {
    refreshTokenBtn.addEventListener('click', function() {
      refreshToken();
    });
  }

  if (logoutBtn) {
    logoutBtn.addEventListener('click', function() {
      logout();
    });
  }

  // Update initial state
  updateTokenDisplay();
  updateRBACTests();
}

function handleLogin() {
  const username = document.getElementById('username-select').value;
  const password = document.getElementById('password-input').value;

  console.log('Attempting login for:', username);

  if (!username) {
    alert('Wybierz użytkownika');
    return;
  }

  // Simulate login
  const user = API_DATA.users.find(u => u.username === username);
  if (user && password === 'demo123') {
    // Generate JWT token
    jwtToken = `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.${btoa(JSON.stringify({
      sub: username,
      role: user.role,
      exp: Math.floor(Date.now() / 1000) + 3600
    }))}.signature`;
    
    tokenExpiry = Date.now() + 3600000; // 1 hour
    currentUser = user;

    console.log('Login successful:', currentUser);

    updateTokenDisplay();
    updateRBACTests();
    updateAuthenticationStatus();

    // Show success feedback
    const loginForm = document.getElementById('login-form');
    loginForm.style.background = 'rgba(var(--color-success-rgb), 0.1)';
    setTimeout(() => {
      loginForm.style.background = '';
    }, 2000);
  } else {
    alert('Nieprawidłowe hasło. Użyj: demo123');
  }
}

function updateTokenDisplay() {
  const tokenDisplay = document.getElementById('token-display');
  const noToken = document.getElementById('no-token');
  const jwtTokenTextarea = document.getElementById('jwt-token');
  const tokenExpires = document.getElementById('token-expires');
  const userRole = document.getElementById('user-role');

  if (currentUser && jwtToken) {
    tokenDisplay.classList.remove('hidden');
    noToken.classList.add('hidden');
    
    jwtTokenTextarea.value = jwtToken;
    tokenExpires.textContent = Math.floor((tokenExpiry - Date.now()) / 1000) + 's';
    userRole.textContent = currentUser.role;

    // Start countdown
    startTokenCountdown();
  } else {
    tokenDisplay.classList.add('hidden');
    noToken.classList.remove('hidden');
  }
}

function updateRBACTests() {
  const healthAccess = document.getElementById('health-access');
  const uploadAccess = document.getElementById('upload-access');
  const metricsAccess = document.getElementById('metrics-access');

  if (!currentUser) {
    healthAccess.textContent = '✓ Dostęp';
    healthAccess.className = 'status status--success';
    uploadAccess.textContent = '✗ Brak tokenu';
    uploadAccess.className = 'status status--error';
    metricsAccess.textContent = '✗ Brak tokenu';
    metricsAccess.className = 'status status--error';
    return;
  }

  // Health - wszyscy
  healthAccess.textContent = '✓ Dostęp';
  healthAccess.className = 'status status--success';

  // Upload - developer+
  if (['developer', 'administrator'].includes(currentUser.role)) {
    uploadAccess.textContent = '✓ Dostęp';
    uploadAccess.className = 'status status--success';
  } else {
    uploadAccess.textContent = '✗ Brak uprawnień';
    uploadAccess.className = 'status status--error';
  }

  // Metrics - tylko admin
  if (currentUser.role === 'administrator') {
    metricsAccess.textContent = '✓ Dostęp';
    metricsAccess.className = 'status status--success';
  } else {
    metricsAccess.textContent = '✗ Brak uprawnień';
    metricsAccess.className = 'status status--error';
  }
}

function startTokenCountdown() {
  const tokenExpires = document.getElementById('token-expires');
  const updateCountdown = () => {
    if (tokenExpiry && tokenExpiry > Date.now()) {
      const seconds = Math.floor((tokenExpiry - Date.now()) / 1000);
      tokenExpires.textContent = seconds + 's';
      
      if (seconds < 300) { // Less than 5 minutes
        tokenExpires.style.color = 'var(--color-warning)';
      }
      if (seconds < 60) { // Less than 1 minute
        tokenExpires.style.color = 'var(--color-error)';
      }
      
      setTimeout(updateCountdown, 1000);
    } else {
      logout();
    }
  };
  updateCountdown();
}

function refreshToken() {
  if (!currentUser) return;

  // Simulate token refresh
  tokenExpiry = Date.now() + 3600000; // Another hour
  updateTokenDisplay();
  
  // Visual feedback
  const refreshBtn = document.getElementById('refresh-token-btn');
  const originalText = refreshBtn.textContent;
  refreshBtn.textContent = 'Odświeżono!';
  refreshBtn.style.background = 'var(--color-success)';
  setTimeout(() => {
    refreshBtn.textContent = originalText;
    refreshBtn.style.background = '';
  }, 2000);
}

function logout() {
  currentUser = null;
  jwtToken = null;
  tokenExpiry = null;

  updateTokenDisplay();
  updateRBACTests();
  updateAuthenticationStatus();

  // Reset form
  const usernameSelect = document.getElementById('username-select');
  const passwordInput = document.getElementById('password-input');
  if (usernameSelect) usernameSelect.value = '';
  if (passwordInput) passwordInput.value = 'demo123';
}

function updateAuthDisplay() {
  updateTokenDisplay();
  updateRBACTests();
}

// Queue management functions
function updateQueueDisplay() {
  console.log('Updating queue display...');
  // Additional queue-specific updates can be added here
}

// System monitoring functions
function updateSystemMetrics() {
  console.log('Updating system metrics...');
  const metricBars = document.querySelectorAll('.metric-fill');
  metricBars.forEach(bar => {
    const currentWidth = parseInt(bar.style.width || '20');
    const variation = (Math.random() - 0.5) * 8;
    const newWidth = Math.max(5, Math.min(95, currentWidth + variation));
    bar.style.width = newWidth + '%';
    
    // Update corresponding value
    const valueElement = bar.parentElement.parentElement.querySelector('.metric-value');
    if (valueElement && valueElement.textContent.includes('%')) {
      valueElement.textContent = Math.round(newWidth) + '%';
    }
  });
}

// Real-time updates simulation
function startRealTimeUpdates() {
  // Update queue every 3 seconds
  setInterval(() => {
    if (document.getElementById('queue-management').classList.contains('tab-content--active')) {
      updateQueueProgress();
    }
  }, 3000);

  // Update metrics every 5 seconds
  setInterval(() => {
    if (document.getElementById('system-monitoring').classList.contains('tab-content--active')) {
      updateSystemMetrics();
    }
  }, 5000);
}

function updateQueueProgress() {
  const progressBars = document.querySelectorAll('.progress-fill');
  progressBars.forEach((bar) => {
    const progressText = bar.parentElement.querySelector('.progress-text');
    if (progressText && !progressText.textContent.includes('100%') && !progressText.textContent.includes('0%')) {
      let currentProgress = parseInt(progressText.textContent);
      if (currentProgress < 100 && Math.random() > 0.3) {
        currentProgress = Math.min(100, currentProgress + Math.floor(Math.random() * 8) + 1);
        bar.style.width = currentProgress + '%';
        progressText.textContent = currentProgress + '%';
        
        if (currentProgress >= 100) {
          // Update status to completed
          const statusSpan = bar.parentElement.parentElement.querySelector('.status');
          if (statusSpan && statusSpan.textContent === 'Przetwarzanie') {
            statusSpan.textContent = 'Ukończone';
            statusSpan.className = 'status status--success';
          }
        }
      }
    }
  });
}

// Initialize application when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
  console.log('🚀 SmartFix Core - Moduł 2: Backend API Demo inicjalizacja...');
  
  // Add method badge styles dynamically
  const style = document.createElement('style');
  style.textContent = `
    .method-badge {
      padding: 2px 6px;
      border-radius: 4px;
      font-size: 10px;
      font-weight: bold;
      text-transform: uppercase;
    }
    .method-badge--get { background: var(--color-success); color: white; }
    .method-badge--post { background: var(--color-primary); color: white; }
    .method-badge--put { background: var(--color-warning); color: white; }
    .method-badge--delete { background: var(--color-error); color: white; }
    
    .endpoint-details {
      background: var(--color-bg-1);
      padding: var(--space-12);
      border-radius: var(--radius-base);
      border-left: 3px solid var(--color-primary);
    }
    
    .endpoint-details p {
      margin: var(--space-6) 0;
    }
  `;
  document.head.appendChild(style);

  // Initialize all components
  initTabNavigation();
  initApiExplorer();
  initAuthDemo();
  
  // Start real-time updates
  startRealTimeUpdates();

  // Add interactive polish
  document.querySelectorAll('.btn').forEach(btn => {
    btn.addEventListener('mouseenter', () => {
      btn.style.transform = 'translateY(-1px)';
    });
    btn.addEventListener('mouseleave', () => {
      btn.style.transform = '';
    });
  });

  console.log('✅ Aplikacja gotowa do użycia!');
  console.log('🔑 Dane logowania: admin/developer/viewer, hasło: demo123');
});