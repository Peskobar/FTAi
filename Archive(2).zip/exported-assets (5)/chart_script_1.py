import plotly.graph_objects as go
import json

# Load the data with abbreviated component names to fit 15 char limit
data = {
    "layers": [
        {
            "name": "Edge & External", 
            "components": ["Termux/IoT", "Perplexity AI", "WASM Market", "Mobile App"]
        }, 
        {
            "name": "Core Services", 
            "components": ["API Gateway", "LSTM Scale", "Circuit Break", "Self-heal Q", "On-device AI", "Frontend UI"]
        }, 
        {
            "name": "Infrastructure", 
            "components": ["OTEL Collect", "SBOM Gen", "SLSA L3", "Kubernetes", "CI/CD Pipeline"]
        }
    ]
}

# Use distinct brand colors for layers
layer_colors = ["#1FB8CD", "#FFC185", "#5D878F"]  # Strong cyan, light orange, cyan

# Create figure
fig = go.Figure()

# Layer positions (y-coordinates from top to bottom)
layer_y_positions = [0.8, 0.5, 0.2]
layer_height = 0.22
component_height = 0.08

shapes = []
annotations = []

# Store component positions for connections
component_positions = []

for i, layer in enumerate(data["layers"]):
    layer_y = layer_y_positions[i]
    layer_color = layer_colors[i]
    
    # Create layer background rectangle
    shapes.append(dict(
        type="rect",
        x0=0.02, y0=layer_y - layer_height/2,
        x1=0.98, y1=layer_y + layer_height/2,
        line=dict(color="#333333", width=2),
        fillcolor=layer_color,
        opacity=0.15,
        layer="below"
    ))
    
    # Add layer title
    annotations.append(dict(
        x=0.5, y=layer_y + layer_height/2 - 0.01,
        text=f"<b>{layer['name']}</b>",
        showarrow=False,
        font=dict(size=16, color="#000000"),
        xanchor="center",
        yanchor="top"
    ))
    
    # Calculate component positions
    num_components = len(layer["components"])
    total_width = 0.92
    component_width = total_width / num_components
    start_x = 0.04
    
    layer_positions = []
    
    for j, component in enumerate(layer["components"]):
        comp_x = start_x + j * component_width
        comp_y = layer_y - 0.02
        
        # Create component box with more width
        box_width = component_width * 0.95
        shapes.append(dict(
            type="rect",
            x0=comp_x, y0=comp_y - component_height/2,
            x1=comp_x + box_width, y1=comp_y + component_height/2,
            line=dict(color="#333333", width=1.5),
            fillcolor=layer_color,
            opacity=0.9
        ))
        
        # Add component text
        annotations.append(dict(
            x=comp_x + box_width/2, y=comp_y,
            text=f"<b>{component}</b>",
            showarrow=False,
            font=dict(size=11, color="#000000"),
            xanchor="center",
            yanchor="middle"
        ))
        
        # Store position for connections
        layer_positions.append(comp_x + box_width/2)
    
    component_positions.append(layer_positions)

# Add connection arrows between layers
for i in range(len(layer_y_positions) - 1):
    current_layer_y = layer_y_positions[i] - layer_height/2 - 0.01
    next_layer_y = layer_y_positions[i+1] + layer_height/2 + 0.01
    
    # Add arrows from each component in current layer to multiple components in next layer
    current_positions = component_positions[i]
    next_positions = component_positions[i+1]
    
    # Create connections with arrows
    for j, current_x in enumerate(current_positions):
        # Connect to 2-3 components in next layer
        target_indices = [k for k in range(len(next_positions)) if k % len(current_positions) == j % len(next_positions)][:2]
        
        for target_idx in target_indices:
            if target_idx < len(next_positions):
                target_x = next_positions[target_idx]
                
                # Add arrow line
                shapes.append(dict(
                    type="line",
                    x0=current_x, y0=current_layer_y,
                    x1=target_x, y1=next_layer_y,
                    line=dict(color="#666666", width=2)
                ))
                
                # Add arrowhead
                annotations.append(dict(
                    x=target_x, y=next_layer_y + 0.01,
                    text="▼",
                    showarrow=False,
                    font=dict(size=12, color="#666666"),
                    xanchor="center",
                    yanchor="bottom"
                ))

# Update layout
fig.update_layout(
    title="TUI-Patcher v1.0 Architecture",
    xaxis=dict(
        range=[0, 1],
        showgrid=False,
        showticklabels=False,
        zeroline=False
    ),
    yaxis=dict(
        range=[0, 1],
        showgrid=False,
        showticklabels=False,
        zeroline=False
    ),
    shapes=shapes,
    annotations=annotations,
    showlegend=False,
    plot_bgcolor="white",
    paper_bgcolor="white"
)

fig.write_image("architecture_diagram.png", width=1400, height=900)