import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime

# Load the data
data = {
    "tasks": [
        {"Task": "OTEL OTLP Integration", "Start": "2025-07-01", "End": "2025-07-15", "Phase": "Q3 2025 - Hardening & Visibility", "SP": 8},
        {"Task": "Traceparent Middleware", "Start": "2025-07-16", "End": "2025-07-29", "Phase": "Q3 2025 - Hardening & Visibility", "SP": 5},
        {"Task": "Slack Alert System", "Start": "2025-07-30", "End": "2025-08-12", "Phase": "Q3 2025 - Hardening & Visibility", "SP": 3},
        {"Task": "SBOM Pipeline", "Start": "2025-08-13", "End": "2025-08-26", "Phase": "Q3 2025 - Hardening & Visibility", "SP": 6},
        {"Task": "LSTM Autoscaler", "Start": "2025-09-01", "End": "2025-09-23", "Phase": "Q4 2025 - Intelligent Patching", "SP": 13},
        {"Task": "On-device AI (TFLite)", "Start": "2025-10-01", "End": "2025-11-04", "Phase": "Q4 2025 - Intelligent Patching", "SP": 21},
        {"Task": "Self-healing Queue", "Start": "2025-11-05", "End": "2025-11-25", "Phase": "Q4 2025 - Intelligent Patching", "SP": 8},
        {"Task": "Circuit Breaker", "Start": "2025-11-26", "End": "2025-12-16", "Phase": "Q4 2025 - Intelligent Patching", "SP": 7},
        {"Task": "Edge Runtime Build", "Start": "2026-01-01", "End": "2026-01-20", "Phase": "H1 2026 - Ecosystem & Plugins", "SP": 15},
        {"Task": "WASM Marketplace", "Start": "2026-02-01", "End": "2026-03-03", "Phase": "H1 2026 - Ecosystem & Plugins", "SP": 18},
        {"Task": "Perplexity AI Dev Assistant", "Start": "2026-03-04", "End": "2026-03-31", "Phase": "H1 2026 - Ecosystem & Plugins", "SP": 12},
        {"Task": "Final Integration", "Start": "2026-04-01", "End": "2026-04-28", "Phase": "H1 2026 - Ecosystem & Plugins", "SP": 10}
    ]
}

# Convert to DataFrame
df = pd.DataFrame(data["tasks"])

# Convert dates to datetime
df['Start'] = pd.to_datetime(df['Start'])
df['End'] = pd.to_datetime(df['End'])

# Create shorter phase names for display
phase_short = {
    "Q3 2025 - Hardening & Visibility": "Q3 2025 Hard",
    "Q4 2025 - Intelligent Patching": "Q4 2025 Intel",
    "H1 2026 - Ecosystem & Plugins": "H1 2026 Eco"
}
df['Phase_Short'] = df['Phase'].map(phase_short)

# Create shorter task names (15 char limit)
task_short = {
    "OTEL OTLP Integration": "OTEL OTLP",
    "Traceparent Middleware": "Traceparent",
    "Slack Alert System": "Slack Alerts",
    "SBOM Pipeline": "SBOM Pipeline",
    "LSTM Autoscaler": "LSTM Scale",
    "On-device AI (TFLite)": "On-device AI",
    "Self-healing Queue": "Self-heal Que",
    "Circuit Breaker": "Circuit Break",
    "Edge Runtime Build": "Edge Runtime",
    "WASM Marketplace": "WASM Market",
    "Perplexity AI Dev Assistant": "Perplexity AI",
    "Final Integration": "Final Integr"
}
df['Task_Short'] = df['Task'].map(task_short)

# Define colors for phases
colors = {
    "Q3 2025 Hard": "#1FB8CD",  # Strong cyan
    "Q4 2025 Intel": "#FFC185",  # Light orange
    "H1 2026 Eco": "#ECEBD5"  # Light green
}

# Create Gantt chart
fig = px.timeline(
    df, 
    x_start="Start", 
    x_end="End", 
    y="Task_Short",
    color="Phase_Short",
    color_discrete_map=colors,
    hover_data={"SP": True, "Task": True},
    title="TUI-Patcher-Agent Roadmap 2025-2026"
)

# Update layout
fig.update_layout(
    xaxis_title="Timeline",
    yaxis_title="Tasks",
    legend=dict(
        orientation='h', 
        yanchor='bottom', 
        y=1.05, 
        xanchor='center', 
        x=0.5,
        title="Phase"
    )
)

# Update traces for better hover info
fig.update_traces(
    cliponaxis=False,
    hovertemplate="<b>%{customdata[1]}</b><br>" +
                  "Start: %{base|%Y-%m-%d}<br>" +
                  "End: %{x|%Y-%m-%d}<br>" +
                  "Story Points: %{customdata[0]}<extra></extra>"
)

# Save the chart
fig.write_image("gantt_roadmap.png")