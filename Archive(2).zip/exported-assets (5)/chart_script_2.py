import pandas as pd
import plotly.graph_objects as go
import json

# Load the data
data_json = {"metrics": [{"Metric": "Success Rate", "Current": 95, "Target": 99, "Current_Label": "95%", "Target_Label": "≥99%", "Unit": "%"}, {"Metric": "Latency p95", "Current": 2.4, "Target": 1.5, "Current_Label": "2.4s", "Target_Label": "≤1.5s", "Unit": "seconds", "Reverse": True}, {"Metric": "Trace Coverage", "Current": 0, "Target": 100, "Current_Label": "0%", "Target_Label": "100%", "Unit": "%"}, {"Metric": "MTTR", "Current": 15, "Target": 5, "Current_Label": "15min", "Target_Label": "<5min", "Unit": "minutes", "Reverse": True}, {"Metric": "Queue Management", "Current": 1, "Target": 4, "Current_Label": "Manual (~15 tasks)", "Target_Label": "Auto-scaling", "Unit": "capability"}, {"Metric": "Security Compliance", "Current": 1, "Target": 3, "Current_Label": "Basic", "Target_Label": "SLSA Level 3", "Unit": "level"}]}

df = pd.DataFrame(data_json['metrics'])

# Shorten metric names to fit character limit (15 chars max)
metric_names = {
    'Success Rate': 'Success Rate',
    'Latency p95': 'Latency p95', 
    'Trace Coverage': 'Trace Cov',
    'MTTR': 'MTTR',
    'Queue Management': 'Queue Mgmt',
    'Security Compliance': 'Security'
}

df['Short_Metric'] = df['Metric'].map(metric_names)

# For better visualization, normalize all metrics to 0-100 scale
normalized_df = df.copy()

# Normalize values for consistent visualization while keeping original labels
for idx, row in normalized_df.iterrows():
    if row['Unit'] == 'seconds':
        # For latency, invert and scale (lower is better) - convert to performance score
        max_val = max(row['Current'], row['Target'])
        normalized_df.at[idx, 'Current_Norm'] = (max_val - row['Current']) / max_val * 100
        normalized_df.at[idx, 'Target_Norm'] = (max_val - row['Target']) / max_val * 100
    elif row['Unit'] == 'minutes':
        # For MTTR, invert and scale (lower is better) - convert to performance score
        max_val = max(row['Current'], row['Target'])
        normalized_df.at[idx, 'Current_Norm'] = (max_val - row['Current']) / max_val * 100
        normalized_df.at[idx, 'Target_Norm'] = (max_val - row['Target']) / max_val * 100
    elif row['Unit'] in ['capability', 'level']:
        # Scale to percentage of maximum
        max_val = max(row['Current'], row['Target'])
        normalized_df.at[idx, 'Current_Norm'] = (row['Current'] / max_val) * 100
        normalized_df.at[idx, 'Target_Norm'] = (row['Target'] / max_val) * 100
    else:
        # For percentages, use as is
        normalized_df.at[idx, 'Current_Norm'] = row['Current']
        normalized_df.at[idx, 'Target_Norm'] = row['Target']

# Create the horizontal bar chart
fig = go.Figure()

# Add current state bars (red color from palette)
fig.add_trace(go.Bar(
    name='Current v0.3.0',
    y=normalized_df['Short_Metric'],
    x=normalized_df['Current_Norm'],
    orientation='h',
    marker_color='#B4413C',  # Red color from the palette
    text=[f"{label}" for label in normalized_df['Current_Label']],
    textposition='auto',
    hovertemplate='<b>%{y}</b><br>Current: %{text}<extra></extra>'
))

# Add target state bars (cyan color from palette as green alternative)  
fig.add_trace(go.Bar(
    name='Target v1.0',
    y=normalized_df['Short_Metric'],
    x=normalized_df['Target_Norm'],
    orientation='h',
    marker_color='#1FB8CD',  # Cyan color from the palette
    text=[f"{label}" for label in normalized_df['Target_Label']],
    textposition='auto',
    hovertemplate='<b>%{y}</b><br>Target: %{text}<extra></extra>'
))

# Update layout
fig.update_layout(
    title='TUI-Patcher Performance Goals',
    xaxis_title='Performance',
    yaxis_title='Metrics',
    barmode='group',
    legend=dict(orientation='h', yanchor='bottom', y=1.05, xanchor='center', x=0.5),
    yaxis=dict(autorange='reversed'),  # Reverse y-axis for better reading order
    uniformtext_minsize=10,
    uniformtext_mode='hide'
)

# Update axes without cliponaxis parameter
fig.update_xaxes(showticklabels=False)  # Hide x-axis labels since we show text on bars
fig.update_yaxes()

# Save the chart
fig.write_image('performance_dashboard.png')